import React from 'react';

const RadioSample = () => {
  const [gender, setGender] = React.useState('Male');

  const handleChange = (event) => {
    setGender(event.target.value)
  }
  return (
    <form>
      <p>Gender</p>
      <div>
        <input
          type="radio"
          value="Male"
          checked={gender === 'Male'}
          onChange={handleChange}
        /> Male
      </div>
      <div>
        <input
          type="radio"
          value="Female"
          checked={gender === 'Female'}
          onChange={handleChange}
        /> Female
      </div>
      <div>
        <input
          type="radio"
          value="Transgender"
          checked={gender === 'Transgender'}
          onChange={handleChange}
        /> Transgender
      </div>
    </form>
  )
}
export default RadioSample;