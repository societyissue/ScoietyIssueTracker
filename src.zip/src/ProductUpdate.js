import React, { useEffect } from 'react';
//  import { useHistory } from "react-router-dom";
import { useState } from "react";
import { useLocation,useNavigate }from 'react-router-dom';
import axios from 'axios';
 


const ProductUpdate = () => {
  const { pathname } = useLocation();
  const id = pathname.replace("/ProductUpdate/", "");

   
  const [name, setName] = useState("");
  const [price, setAge] = useState("");
  
  // const [image, setImage] = useState();
  // const [imageName, setImageName] = useState("");

  const navigate = useNavigate(); 
  
  function getData()
  {
   var url="http://localhost:3001/Products/"+id;
   axios.get(url)
   .then(response => {
     const record = response.data;
     setName(record.pname)
     setAge(record.age)
    //  setImageName(record.photo)
     console.log(record);
//alert('sd');
    })
  }
   useEffect(() => {
    getData()},[] );


 
  const handleName = (e) => setName(e.target.value);
  const handlePrice = (e) => setAge(e.target.value);
  
//   const Changephoto =( event) => {
// //    alert(event.target.files[0].name);
//     setImage(event.target.files[0] );
//     setImageName(event.target.files[0].name);
//   };

  const submitStateRecord=(e)=>
  {
    e.preventDefault();

  //alert(image);
    console.log( name + " " +age );
    const formData = new FormData();
    formData.append( "name", name);
    formData.append( "age", age);
    //data.append( "photo", imageName);
    // formData.append( "file", image);
   //http://localhost:3001/tasks
   //http://127.0.0.1:3001/Products
   //var res= axios.post("http://localhost:3001/Products", data);
  var res= axios({
    method: "put",
    url: "http://localhost:3001/Products/"+id,
    data: formData,
    headers: { "Content-Type": "multipart/form-data" },
  }); 
   
   alert("Data Updated" +res);
    alert(formData);
    console.log(Object.fromEntries(formData))
    
   
   navigate('/ProductList'); 
  }
    return (

      <div>
        <div className="wrapper">
          <div>
       
          </div>

          
          <div className="content-wrapper">

            <section className="content-header">
              <div className="container-fluid">
                <div className="row mb-2">
                  <div className="col-sm-6">
                    <h1>Update Product</h1>
                  </div>
                  
                </div>
              </div>
            </section>

            <section className="content">
              <div className="container-fluid">
                <div className="row">
                  <div className="col-md-12">
                    <div className="card-primary dark-mode">
                      <form id="quickForm" method="post" encType='multipart/form-data' onSubmit={submitStateRecord} >
                        <div className="card-body">
                          <div className="form-group">
                            <label  >Product Name:</label>
                            <input type="text" name="name"  className="form-control form-control-border"  id="categorynm" 
                            placeholder="Enter Product name" required 
                            onChange={handleName}
                            value={name} />
                          </div>

                          <div className="form-group">
                            <label  >Product Price:</label>
                            <input type="text" name="price"  className="form-control form-control-border"  id="categorynm" 
                            placeholder="Enter Product price" required 
                            onChange={handlePrice}
                            value={price} />
                          </div>
                          {/* <div className="form-group">
                            Image   <input type="file" name="photo" id="photo" className="form-control form-control-border" 
                             required  onChange={Changephoto} /> <br />
                        <img src={`http://localhost:3001/uploads/${imageName}`}  width="50px" height="50px" /> 
                          </div>*/}
                        </div> 

                        <div className="card-footer dark-mode">
                          <button type="submit" className="btn btn-primary">Submit</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
       

      </div>
    )
  }
export default ProductUpdate;