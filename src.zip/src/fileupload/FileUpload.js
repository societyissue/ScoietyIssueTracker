import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const FileUploadForm = () => {
  const [formData, setFormData] = useState({ p_id: '', p_name: '', p_price: '', p_photo:'' });
  const navigate = useNavigate();
  const { p_id } = useParams(); // ✅ get from route param
  const editMode = Boolean(p_id);

  useEffect(() => {
    if (editMode) {
      axios.get(`http://localhost:4000/products/${p_id}`)
        .then(res => {
          console.log('Fetched data:', res.data);
          setFormData(res.data);
        })
        .catch(err => {
          console.error('Error fetching product details:', err);
          alert('Failed to fetch product');
        });
    }
  }, [p_id, editMode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  
    const data = new FormData();
    data.append('p_id', formData.p_id);
    data.append('p_name', formData.p_name);
    data.append('p_price', formData.p_price);
    data.append('p_photo', formData.p_photo); // this is a file
  
    if (editMode) {
      axios.put(`http://localhost:4000/products/${p_id}`, data)
        .then(() => {
          alert('Product updated successfully');
          navigate('/');
        })
        .catch(err => {
          console.error('Update error:', err);
          alert('Failed to update');
        });
    } else {
      axios.post('http://localhost:4000/products', data)
        .then(() => {
          alert('Product inserted successfully');
          navigate('/');
        })
        .catch(err => {
          console.error('Insert error:', err);
          alert('Failed to insert');
        });
    }
  };

  return (
    <div className="container mt-4">
      <h2>{editMode ? 'Edit Product' : 'Add Product'}</h2>
      <form onSubmit={handleSubmit}>

        <div className="mb-3">
          <input
            type="hidden"
            name="p_id"
            value={formData.p_id}
            onChange={handleChange}
            className="form-control"
            required
            disabled={editMode}
          />
        </div>

        <div className="mb-3">
          <label>Name</label>
          <input
            type="text"
            name="p_name"
            value={formData.p_name}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label>Price</label>
          <input
            type="number"
            name="p_price"
            value={formData.p_price}
            onChange={handleChange}
            className="form-control"
            required
          />
          </div>

            <div>
                <label>Photo</label>
            <input
            type="file"
            name="p_photo"
            onChange={(e) => setFormData(prev => ({ ...prev, p_photo: e.target.files[0] }))}
            className="form-control"
            required={!editMode}
            />
            </div>
        <button type="submit" className="btn btn-success">
          {editMode ? 'Update' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default FileUploadForm;