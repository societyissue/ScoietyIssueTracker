import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SampleJSONAxios = () => {
  const [result, setResult] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    axios.get("http://localhost:8000/employee")
      .then(response => {
        setResult(response.data);
      })
      .catch(error => {
        console.error("Error fetching API data:", error);
      });
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this record?")) {
      axios.delete(`http://localhost:8000/emp/${id}`)
        .then(() => {
          alert("Record deleted successfully");
          fetchData();
        })
        .catch(error => {
          alert("Delete error: " + (error.response?.data?.message || error.message));
        });
    }
  };

  const handleUpdate = (employee) => {
    navigate(`/emp/${employee.id}`, { state: { employee } });
  };
  

  const handleAdd = () => {
    navigate('/emp');
  };

  return (
    <center>
      <div className='col-sm-10'>
        <h2>Employee List</h2>
        <button onClick={handleAdd}>Add New Employee</button>
        <br /><br />
        <table className="table table-striped" border="1">
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>Employee Name</th>
              <th>Age</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {result.length > 0 ? (
              result.map((person) => (
                <tr key={person.id}>
                  <td>{person.id}</td>
                  <td>{person.name}</td>
                  <td>{person.age}</td>
                  <td>
                    <button onClick={() => handleUpdate(person.id)}>Update</button>{" "}
                    <button onClick={() => handleDelete(person.id)}>Delete</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="4">Loading or no data found...</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </center>
  );
};

export default SampleJSONAxios;