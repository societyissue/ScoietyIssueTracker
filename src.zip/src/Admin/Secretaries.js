import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminSecretaries = () => {
  const [secretaries, setSecretaries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchSecretaries();
  }, []);

  const fetchSecretaries = async () => {
    setLoading(true);
    setError(null);

    const token = localStorage.getItem("token");
    if (!token) {
      setLoading(false);
      return setError("No authentication token found. Please login.");
    }

    try {
      const res = await axios.get("http://localhost:5000/secretaries", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSecretaries(Array.isArray(res.data) ? res.data : res.data.secretaries || []);
    } catch (err) {
      setError(
        err.response?.data?.message || "Failed to fetch secretaries. Try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this secretary?")) return;

    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/secretaries/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Refresh list after delete
      setSecretaries(secretaries.filter((sec) => sec.secretary_id !== id && sec.id !== id));
    } catch (err) {
      alert(err.response?.data?.message || "Failed to delete secretary");
    }
  };

  const handleEdit = (id) => {
    // Redirect to edit page (make sure you have a route for it)
    window.location.href = `/admin/secretaries/edit/${id}`;
  };

  if (loading) return <div>Loading secretaries...</div>;
  if (error) return <div className="text-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Secretaries</h2>
      {secretaries.length === 0 ? (
        <p>No secretaries found.</p>
      ) : (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Building</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {secretaries.map((sec) => (
              <tr key={sec.id || sec.secretary_id}>
                <td>{sec.id || sec.secretary_id}</td>
                <td>{sec.sname}</td>
                <td>{sec.semail}</td>
                <td>{sec.building_name}</td>
                <td>
                  <button
                    className="btn btn-primary btn-sm me-2"
                    onClick={() => handleEdit(sec.id || sec.secretary_id)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(sec.id || sec.secretary_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AdminSecretaries;