import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminSecretaries = () => {
  const [secretaries, setSecretaries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const secretariesPerPage = 10; // ✅ Show 10 secretaries per page

  useEffect(() => {
    fetchSecretaries();
  }, []);

  const fetchSecretaries = async () => {
    setLoading(true);
    setError(null);

    const token = localStorage.getItem("token");
    if (!token) {
      setLoading(false);
      return setError("No authentication token found. Please login.");
    }

    try {
      const res = await axios.get("http://localhost:5000/secretaries", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSecretaries(
        Array.isArray(res.data) ? res.data : res.data.secretaries || []
      );
    } catch (err) {
      setError(
        err.response?.data?.message || "Failed to fetch secretaries. Try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this secretary?")) return;

    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/secretaries/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Refresh list after delete
      setSecretaries(
        secretaries.filter((sec) => sec.secretary_id !== id && sec.id !== id)
      );
    } catch (err) {
      alert(err.response?.data?.message || "Failed to delete secretary");
    }
  };

  const handleEdit = (id) => {
    window.location.href = `/admin/secretaries/edit/${id}`;
  };

  const handleAdd = () => {
    window.location.href = "/admin/secretaries/add";
  };

  // ✅ Pagination logic
  const indexOfLastSecretary = currentPage * secretariesPerPage;
  const indexOfFirstSecretary = indexOfLastSecretary - secretariesPerPage;
  const currentSecretaries = secretaries.slice(
    indexOfFirstSecretary,
    indexOfLastSecretary
  );
  const totalPages = Math.ceil(secretaries.length / secretariesPerPage);

  if (loading) return <div>Loading secretaries...</div>;
  if (error) return <div className="text-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Secretaries</h2>
        <button className="btn btn-success" onClick={handleAdd}>
          + Add Secretary
        </button>
      </div>

      {secretaries.length === 0 ? (
        <p>No secretaries found.</p>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-striped">
              <thead className="table-dark">
                <tr>
                  <th>Sr. No</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Building</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentSecretaries.map((sec, index) => (
                  <tr key={sec.id || sec.secretary_id}>
                    <td>{indexOfFirstSecretary + index + 1}</td>
                    <td>{sec.sname}</td>
                    <td>{sec.semail}</td>
                    <td>{sec.building_name}</td>
                    <td>
                      <button
                        className="btn btn-primary btn-sm me-2"
                        onClick={() =>
                          handleEdit(sec.id || sec.secretary_id)
                        }
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() =>
                          handleDelete(sec.id || sec.secretary_id)
                        }
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* ✅ Pagination controls */}
          <div className="d-flex justify-content-center mt-3">
            <button
              className="btn btn-secondary me-2"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Previous
            </button>
            <span className="align-self-center">
              Page {currentPage} of {totalPages}
            </span>
            <button
              className="btn btn-secondary ms-2"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default AdminSecretaries;