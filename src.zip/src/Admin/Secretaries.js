import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";

const Secretaries = () => {
  const [secretaries, setSecretaries] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  // Load secretaries
  const loadSecretaries = async () => {
    try {
      const res = await axios.get("http://localhost:5000/secretaries", { withCredentials: true });
      setSecretaries(res.data);
    } catch (err) {
      console.error("Error loading secretaries:", err);
    }
  };

  // Reload when visiting /admin/secretaries
  useEffect(() => {
    if (location.pathname === "/admin/secretaries") {
      loadSecretaries();
    }
  }, [location.pathname]);

  return (
    <div className="container mt-3">
      <h3>Secretaries</h3>

      <button
        className="btn btn-success mb-3"
        onClick={() => navigate("/admin/secretaries/new")}
      >
        Add New Secretary
      </button>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Building</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {secretaries.map((s) => (
            <tr key={s.secretary_id}>
              <td>{s.secretary_id}</td>
              <td>{s.sname}</td>
              <td>{s.semail}</td>
              <td>{s.building_name}</td>
              <td>
                <button
                  className="btn btn-sm btn-primary me-1"
                  onClick={() => navigate(`/admin/secretaries/edit/${s.secretary_id}`)}
                >
                  Edit
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={async () => {
                    if (window.confirm("Are you sure you want to delete this secretary?")) {
                      await axios.delete(`http://localhost:5000/secretaries/${s.secretary_id}`, { withCredentials: true });
                      loadSecretaries();
                    }
                  }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
          {secretaries.length === 0 && (
            <tr>
              <td colSpan="5" className="text-center">No secretaries found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Secretaries;