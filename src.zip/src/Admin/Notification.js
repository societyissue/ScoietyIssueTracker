import React, { useEffect, useState, useCallback } from "react";
import { useOutletContext } from "react-router-dom";
import axios from "axios";

const AdminNotifications = () => {
  const [notifications, setNotifications] = useState([]);
  const { refreshNotifications } = useOutletContext(); // get badge refresh function
  const token = localStorage.getItem("token");

  // Fetch all notifications (memoized)
  const fetchNotifications = useCallback(async () => {
    try {
      const res = await axios.get("http://localhost:5000/notifications", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setNotifications(res.data);
    } catch (err) {
      console.error("Error fetching notifications:", err);
    }
  }, [token]); // token is the only dependency

  // Mark notification as read
  const markAsRead = async (id) => {
    try {
      await axios.patch(`http://localhost:5000/notifications/${id}/read`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Update local state
      setNotifications((prev) =>
        prev.map((n) =>
          n.notification_id === id ? { ...n, is_read: 1 } : n
        )
      );

      // Refresh badge count in AdminLayout
      if (refreshNotifications) refreshNotifications();
    } catch (err) {
      console.error("Error marking notification as read:", err);
    }
  };

  // UseEffect now safe: fetchNotifications is memoized
  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  return (
    <div>
      <h2>Notifications</h2>
      {notifications.length === 0 && <p>No notifications found.</p>}
      <ul className="list-group">
        {notifications.map((n) => (
          <li
            key={n.notification_id}
            className={`list-group-item d-flex justify-content-between align-items-center ${
              n.is_read ? "" : "list-group-item-warning"
            }`}
          >
            <span>{n.message}</span>
            {!n.is_read && (
              <button
                className="btn btn-sm btn-primary"
                onClick={() => markAsRead(n.notification_id)}
              >
                Mark as Read
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminNotifications;