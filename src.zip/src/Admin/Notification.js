// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Bell, CheckCircle } from "lucide-react";

// const AdminNotifications = () => {
//   const [notifications, setNotifications] = useState([]);
//   const [unreadCount, setUnreadCount] = useState(0);
//   const [loading, setLoading] = useState(true);

//   const fetchNotifications = async () => {
//     try {
//       setLoading(true);
//       const res = await axios.get("/admin/notifications");
//       setNotifications(res.data);

//       const countRes = await axios.get("/admin/notifications/unread/count");
//       setUnreadCount(countRes.data.unreadCount);
//     } catch (err) {
//       console.error("Error fetching admin notifications:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const markAsRead = async (id) => {
//     try {
//       const res = await axios.patch(`/admin/notifications/${id}/read`);
//       setUnreadCount(res.data.unreadCount);
//       setNotifications((prev) =>
//         prev.map((n) =>
//           n.notification_id === id ? { ...n, is_read: 1 } : n
//         )
//       );
//     } catch (err) {
//       console.error("Error marking admin notification as read:", err);
//     }
//   };

//   useEffect(() => {
//     fetchNotifications();
//   }, []);

//   return (
//     <div className="p-4">
//       <h2 className="text-xl font-bold flex items-center gap-2">
//         <Bell /> Admin Notifications ({unreadCount} Unread)
//       </h2>
//       {loading ? (
//         <p>Loading...</p>
//       ) : notifications.length === 0 ? (
//         <p>No notifications</p>
//       ) : (
//         <ul className="mt-4 space-y-2">
//           {notifications.map((n) => (
//             <li
//               key={n.notification_id}
//               className={`p-3 rounded shadow ${
//                 n.is_read ? "bg-gray-100" : "bg-yellow-100"
//               }`}
//             >
//               <p>{n.message}</p>
//               <small className="text-sm text-gray-600">
//                 {new Date(n.created_at).toLocaleString()}
//               </small>
//               {!n.is_read && (
//                 <button
//                   className="ml-3 text-green-600 flex items-center gap-1"
//                   onClick={() => markAsRead(n.notification_id)}
//                 >
//                   <CheckCircle size={16} /> Mark as Read
//                 </button>
//               )}
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// };

// export default AdminNotifications;