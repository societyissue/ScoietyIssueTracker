import React, { useEffect, useState } from "react";
import axios from "axios";

const Notification = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/notifications", { withCredentials: true })
      .then(res => setData(res.data));
  }, []);

  return (
    <div>
      <h3>Notifications</h3>
      <ul className="list-group">
        {data.map(n => (
          <li key={n.notification_id} className="list-group-item">
            {n.message}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Notification;