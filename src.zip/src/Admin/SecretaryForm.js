import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SecretaryForm = ({ isEdit = false }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    sname: "",
    semail: "",
    spassword: "",
    confirmPassword: "",
    wing: "",
    house_no: "",
    building_name: ""
  });

  const [passwordMessage, setPasswordMessage] = useState("");
  const [passwordValid, setPasswordValid] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState("");

  // Load secretary data if editing
  useEffect(() => {
    if (isEdit && id) {
      axios
        .get("http://localhost:5000/secretaries", { withCredentials: true })
        .then(res => {
          const secretary = res.data.find(s => String(s.secretary_id) === String(id));
          if (secretary) {
            setForm({ ...secretary, spassword: "", confirmPassword: "" });
          }
        })
        .catch(err => console.error("Error fetching secretary", err));
    }
  }, [isEdit, id]);

  // Password strength checker
  const checkPasswordStrength = (password) => {
    if (!password) return "";
    const regexWeak = /.{6,}/;
    const regexMedium = /^(?=.*[A-Z])(?=.*\d).{6,}$/;
    const regexStrong = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;

    if (regexStrong.test(password)) return "Strong";
    if (regexMedium.test(password)) return "Medium";
    if (regexWeak.test(password)) return "Weak";
    return "Too Short";
  };

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (name === "spassword") setPasswordStrength(checkPasswordStrength(value));

    if (name === "spassword" || name === "confirmPassword") {
      if (
        (name === "spassword" && value !== form.confirmPassword) ||
        (name === "confirmPassword" && value !== form.spassword)
      ) {
        setPasswordMessage("❌ Passwords do not match");
        setPasswordValid(false);
      } else if (form.spassword || value) {
        setPasswordMessage("✅ Passwords match");
        setPasswordValid(true);
      } else {
        setPasswordMessage("");
        setPasswordValid(false);
      }
    }
  };

  // Submit
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!isEdit && form.spassword !== form.confirmPassword) {
      toast.error("Passwords do not match!");
      return;
    }

    const request = isEdit
      ? axios.put(`http://localhost:5000/secretaries/${id}`, form, { withCredentials: true })
      : axios.post("http://localhost:5000/secretaries", form, { withCredentials: true });

    request
      .then(() => {
        toast.success(`✅ Secretary ${isEdit ? "updated" : "added"} successfully!`);
        setTimeout(() => navigate("/secretaries", { replace: true }), 1500);
      })
      .catch(() => toast.error("Failed to save secretary"));
  };

  // Cancel confirmation
  const handleCancel = () => {
    toast.info(
      <div>
        Are you sure you want to cancel? Changes will be lost.
        <div className="mt-2">
          <button
            className="btn btn-sm btn-danger me-2"
            onClick={() => {
              toast.dismiss();
              navigate("/secretaries", { replace: true });
            }}
          >
            Yes, Cancel
          </button>
          <button className="btn btn-sm btn-secondary" onClick={() => toast.dismiss()}>
            No
          </button>
        </div>
      </div>,
      { autoClose: false, closeButton: false }
    );
  };

  const getStrengthColor = () => {
    switch (passwordStrength) {
      case "Strong":
        return "text-success";
      case "Medium":
        return "text-warning";
      case "Weak":
      case "Too Short":
        return "text-danger";
      default:
        return "";
    }
  };

  const disableSubmit =
    !isEdit && (!passwordValid || passwordStrength === "Weak" || passwordStrength === "Too Short");

  return (
    <div className="container mt-4">
      <div className="card shadow-lg border-0">
        <div className="card-header bg-primary text-white d-flex align-items-center">
          <i className="fas fa-user-tie me-2"></i>
          <h4 className="mb-0">{isEdit ? "Edit Secretary" : "Add Secretary"}</h4>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              {/* Left Column */}
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Name</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="fas fa-user"></i></span>
                    <input
                      type="text"
                      name="sname"
                      value={form.sname}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter full name"
                      required
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Email</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="fas fa-envelope"></i></span>
                    <input
                      type="email"
                      name="semail"
                      value={form.semail}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter email"
                      required
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Password</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="fas fa-lock"></i></span>
                    <input
                      type="password"
                      name="spassword"
                      placeholder={isEdit ? "Leave blank to keep current password" : "Enter password"}
                      value={form.spassword}
                      onChange={handleChange}
                      className="form-control"
                      required={!isEdit}
                    />
                  </div>
                  {form.spassword && (
                    <small className={`mt-1 d-block ${getStrengthColor()}`}>
                      Password Strength: {passwordStrength}
                    </small>
                  )}
                </div>

                {!isEdit && (
                  <div className="mb-3">
                    <label className="form-label">Confirm Password</label>
                    <div className="input-group">
                      <span className="input-group-text"><i className="fas fa-check-circle"></i></span>
                      <input
                        type="password"
                        name="confirmPassword"
                        placeholder="Re-enter password"
                        value={form.confirmPassword}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    {passwordMessage && (
                      <small className={`mt-1 d-block ${passwordValid ? "text-success" : "text-danger"}`}>
                        {passwordMessage}
                      </small>
                    )}
                  </div>
                )}
              </div>

              {/* Right Column */}
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Wing</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="fas fa-building"></i></span>
                    <input
                      type="text"
                      name="wing"
                      value={form.wing}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter wing"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">House No</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="fas fa-home"></i></span>
                    <input
                      type="text"
                      name="house_no"
                      value={form.house_no}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter house number"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Building Name</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="fas fa-city"></i></span>
                    <input
                      type="text"
                      name="building_name"
                      value={form.building_name}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter building name"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="mt-4 d-flex justify-content-between">
              <button type="button" className="btn btn-outline-danger" onClick={handleCancel}>
                <i className="fas fa-times me-2"></i> Cancel
              </button>
              <button type="submit" disabled={disableSubmit} className={`btn ${disableSubmit ? "btn-secondary" : "btn-primary"}`}>
                <i className={`me-2 ${isEdit ? "fas fa-save" : "fas fa-plus-circle"}`}></i>
                {isEdit ? "Update Secretary" : "Add Secretary"}
              </button>
            </div>
          </form>
        </div>
      </div>
      <ToastContainer position="top-right" autoClose={2000}
      hideProgressBar />
      </div>
    );
  };
  
export default SecretaryForm;  