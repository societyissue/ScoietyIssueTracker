import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { FaUser, FaEnvelope, FaKey, FaHome, FaBuilding } from "react-icons/fa";

const SecretaryForm = ({ isEdit = false }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    sname: "",
    semail: "",
    spassword: "",
    confirmPassword: "",
    wing: "",
    house_no: "",
    building_name: "",
  });

  const [passwordError, setPasswordError] = useState("");
  const [confirmError, setConfirmError] = useState("");
  const [secretaries, setSecretaries] = useState([]);

  // Load all secretaries (for potential future use, e.g., assigning assistant secretaries)
  useEffect(() => {
    axios
      .get("http://localhost:5000/secretaries")
      .then((res) => setSecretaries(res.data))
      .catch(() => toast.error("Failed to load secretaries"));
  }, []);

  // Load secretary if editing
  useEffect(() => {
    if (isEdit && id) {
      axios
        .get(`http://localhost:5000/secretaries/${id}`)
        .then((res) =>
          setForm({
            ...res.data,
            spassword: "",
            confirmPassword: "",
          })
        )
        .catch(() => toast.error("Failed to load secretary details"));
    }
  }, [id, isEdit]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (name === "spassword") validatePassword(value);
    if (name === "confirmPassword") validateConfirmPassword(form.spassword, value);
  };

  // Password validation
  const validatePassword = (password) => {
    if (!isEdit || password) {
      const strongPassword = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{6,}$/;
      setPasswordError(
        strongPassword.test(password)
          ? ""
          : "Password must be at least 6 chars, include 1 uppercase, 1 number, and 1 special character."
      );
    } else {
      setPasswordError("");
    }
  };

  const validateConfirmPassword = (password, confirmPassword) => {
    setConfirmError(password !== confirmPassword ? "Passwords do not match." : "");
  };

  // Submit handler
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!isEdit && (passwordError || confirmError)) {
      toast.error("Fix password errors before submitting");
      return;
    }

    const request = isEdit
      ? axios.put(`http://localhost:5000/secretaries/${id}`, form)
      : axios.post("http://localhost:5000/secretaries", form);

    request
      .then(() => {
        toast.success(`✅ Secretary ${isEdit ? "updated" : "added"} successfully!`);
        setTimeout(() => navigate("/secretaries", { replace: true }), 1500);
      })
      .catch(() => toast.error("Failed to save secretary"));
  };

  const handleCancel = () => {
    navigate("/secretaries", { replace: true });
  };

  // Filter secretaries by building (optional feature similar to UserForm)
  const filteredSecretaries = secretaries.filter(
    (s) =>
      form.building_name &&
      s.building_name?.toLowerCase() === form.building_name.toLowerCase()
  );

  return (
    <div className="container mt-3">
      <h3>{isEdit ? "Edit Secretary" : "Add Secretary"}</h3>
      <form onSubmit={handleSubmit}>
        <div className="row">
          {/* Left Column */}
          <div className="col-md-6">
            <div className="mb-3">
              <label>Name</label>
              <div className="input-group">
                <span className="input-group-text"><FaUser /></span>
                <input
                  type="text"
                  name="sname"
                  value={form.sname}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <label>Email</label>
              <div className="input-group">
                <span className="input-group-text"><FaEnvelope /></span>
                <input
                  type="email"
                  name="semail"
                  value={form.semail}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
            </div>

            {!isEdit && (
              <>
                <div className="mb-3">
                  <label>Password</label>
                  <div className="input-group">
                    <span className="input-group-text"><FaKey /></span>
                    <input
                      type="password"
                      name="spassword"
                      value={form.spassword}
                      onChange={handleChange}
                      className={`form-control ${passwordError ? "is-invalid" : ""}`}
                      required
                    />
                  </div>
                  {passwordError && <div className="text-danger small">{passwordError}</div>}
                </div>

                <div className="mb-3">
                  <label>Confirm Password</label>
                  <div className="input-group">
                    <span className="input-group-text"><FaKey /></span>
                    <input
                      type="password"
                      name="confirmPassword"
                      value={form.confirmPassword}
                      onChange={handleChange}
                      className={`form-control ${confirmError ? "is-invalid" : ""}`}
                      required
                    />
                  </div>
                  {confirmError && <div className="text-danger small">{confirmError}</div>}
                </div>
              </>
            )}
          </div>

          {/* Right Column */}
          <div className="col-md-6">
            <div className="mb-3">
              <label>Wing</label>
              <div className="input-group">
                <span className="input-group-text"><FaBuilding /></span>
                <input
                  type="text"
                  name="wing"
                  value={form.wing}
                  onChange={handleChange}
                  className="form-control"
                />
              </div>
            </div>

            <div className="mb-3">
              <label>House No</label>
              <div className="input-group">
                <span className="input-group-text"><FaHome /></span>
                <input
                  type="text"
                  name="house_no"
                  value={form.house_no}
                  onChange={handleChange}
                  className="form-control"
                />
              </div>
            </div>

            <div className="mb-3">
              <label>Building Name</label>
              <div className="input-group">
                <span className="input-group-text"><FaBuilding /></span>
                <input
                  type="text"
                  name="building_name"
                  value={form.building_name}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
            </div>

            {/* Optional: Show other secretaries for same building */}
            {filteredSecretaries.length > 0 && (
              <div className="mb-3">
                <label>Other Secretaries in this Building</label>
                <ul className="list-group">
                  {filteredSecretaries.map((s) => (
                    <li key={s.secretary_id} className="list-group-item">
                      {s.sname} ({s.semail})
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Buttons */}
        <button type="submit" className="btn btn-primary me-2">
          {isEdit ? "Update Secretary" : "Add Secretary"}
        </button>
        <button type="button" className="btn btn-secondary" onClick={handleCancel}>
          Cancel
        </button>
      </form>

      <ToastContainer position="top-right" autoClose={2000} hideProgressBar />
    </div>
  );
};

export default SecretaryForm;