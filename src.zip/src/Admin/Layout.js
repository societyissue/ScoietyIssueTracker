import React, { useEffect, useState } from "react";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import {
  FaTachometerAlt,
  FaUsers,
  FaUserTie,
  FaExclamationTriangle,
  FaClipboardList,
  FaComments,
  FaFileAlt,
  FaSignOutAlt,
  FaUserCircle,
} from "react-icons/fa";
import "bootstrap/dist/css/bootstrap.min.css";

const AdminLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState({ name: "Admin", avatar: null });

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser({
        name: storedUser.name || "Admin",
        avatar: storedUser.avatar || null,
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  };

  // Fix: exact match for /admin (Dashboard)
  const isActive = (path) => {
    if (path === "/admin") {
      return location.pathname === "/admin";
    }
    return location.pathname.startsWith(path);
  };

  const links = [
    { path: "/admin/profile", label: "Profile", icon: <FaUserCircle /> }, // Profile first
    { path: "/admin", label: "Dashboard", icon: <FaTachometerAlt /> },
    { path: "/admin/users", label: "Users", icon: <FaUsers /> },
    { path: "/admin/secretaries", label: "Secretaries", icon: <FaUserTie /> },
    { path: "/admin/issues", label: "Issues", icon: <FaExclamationTriangle /> },
    { path: "/admin/issue-log", label: "Issue Log", icon: <FaClipboardList /> },
    { path: "/admin/feedback", label: "Feedback", icon: <FaComments /> },
    { path: "/admin/reports", label: "Reports", icon: <FaFileAlt /> },
    { path: "/logout", label: "Logout", icon: <FaSignOutAlt />, logout: true },
  ];

  return (
    <div className="container-fluid p-0">
      <div className="row g-0">
        {/* Sidebar */}
        <aside className="col-md-2 vh-100 bg-dark text-white d-flex flex-column p-0">
          {/* Profile Section with background */}
          <div
            className="text-center p-4 border-bottom"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?fit=crop&w=600&q=80')",
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          >
            {user.avatar ? (
              <img
                src={user.avatar}
                alt="Avatar"
                className="rounded-circle mb-2 border border-white"
                style={{ width: "80px", height: "80px", objectFit: "cover" }}
              />
            ) : (
              <FaUserCircle size={80} className="mb-2 text-white" />
            )}
            <h6 className="mb-0 text-white">{user.name}</h6>
          </div>

          {/* Nav Links */}
          <nav className="nav flex-column mt-3">
            {links.map((item) =>
              item.logout ? (
                <button
                  key={item.label}
                  className="nav-link d-flex align-items-center py-3 px-4 text-light border-0 bg-transparent text-start"
                  onClick={handleLogout}
                >
                  {item.icon} <span className="ms-2">{item.label}</span>
                </button>
              ) : (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`nav-link d-flex align-items-center py-3 px-4 ${
                    isActive(item.path) ? "bg-primary text-white" : "text-light"
                  }`}
                  style={{ transition: "0.3s" }}
                  onMouseEnter={(e) => {
                    if (!isActive(item.path))
                      e.currentTarget.style.backgroundColor = "#343a40";
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive(item.path))
                      e.currentTarget.style.backgroundColor = "transparent";
                  }}
                >
                  {item.icon} <span className="ms-2">{item.label}</span>
                </Link>
              )
            )}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="col-md-10 bg-light p-4 min-vh-100">
          <div className="container-fluid">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;