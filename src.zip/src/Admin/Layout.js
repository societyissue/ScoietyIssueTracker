import React from "react";
import { Link, Outlet, useNavigate, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const AdminLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const admin = JSON.parse(localStorage.getItem("admin"));

  const handleLogout = () => {
    localStorage.removeItem("admin");
    navigate("/login");
  };

  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <div className="d-flex" style={{ minHeight: "100vh" }}>
      <aside className="bg-dark text-white d-flex flex-column p-3" style={{ width: "250px" }}>
        <div className="text-center mb-4 border-bottom pb-3">
          <i className="fas fa-user-circle fa-4x mb-2"></i>
          <h5 className="mb-0">{admin?.name || "Admin"}</h5>
        </div>

        <nav className="flex-grow-1">
          <ul className="nav flex-column">
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin") ? "active text-warning" : "text-white"}`} to="/admin">
                <i className="fas fa-home me-2"></i> Dashboard
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/users") ? "active text-warning" : "text-white"}`} to="/admin/users">
                <i className="fas fa-users me-2"></i> Users
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/secretaries") ? "active text-warning" : "text-white"}`} to="/admin/secretaries">
                <i className="fas fa-user-tie me-2"></i> Secretaries
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/issues") ? "active text-warning" : "text-white"}`} to="/admin/issues">
                <i className="fas fa-exclamation-circle me-2"></i> Issues
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/feedback") ? "active text-warning" : "text-white"}`} to="/admin/feedback">
                <i className="fas fa-comments me-2"></i> Feedback
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/notifications") ? "active text-warning" : "text-white"}`} to="/admin/notifications">
                <i className="fas fa-bell me-2"></i> Notifications
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/issue-log") ? "active text-warning" : "text-white"}`} to="/admin/issue-log">
                <i className="fas fa-history me-2"></i> Logs
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link className={`nav-link ${isActive("/admin/reports") ? "active text-warning" : "text-white"}`} to="/admin/reports">
                <i className="fas fa-file-export me-2"></i> Reports / Export
              </Link>
            </li>
          </ul>
        </nav>
      </aside>

      <main className="flex-grow-1 d-flex flex-column">
        <header className="navbar navbar-light bg-light shadow-sm px-3 d-flex justify-content-between align-items-center">
          <div className="d-flex align-items-center">
            <span className="navbar-brand mb-0 h5 me-3">Admin Panel</span>
            <span className="fw-bold text-dark">{admin?.name || "Admin"}</span>
          </div>
          <button className="btn btn-outline-danger btn-sm" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt me-1"></i> Logout
          </button>
        </header>

        <section className="flex-grow-1 p-4 bg-light">
          <Outlet />
        </section>
      </main>
    </div>
  );
};

export default AdminLayout;