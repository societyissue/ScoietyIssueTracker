import React, { useState, useEffect, useRef } from "react";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import { 
  FaTachometerAlt, FaUsers, FaUserTie, FaExclamationTriangle, 
  FaClipboardList, FaComments, FaBell, FaFileAlt, FaSignOutAlt, FaUserCircle
} from "react-icons/fa";
import axios from "axios";

const AdminLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [notificationCount, setNotificationCount] = useState(0);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const [user, setUser] = useState({ name: "Admin", avatar: null });
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser({
        name: storedUser.name || "Admin",
        avatar: storedUser.avatar || null,
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  };

  const fetchNotificationCount = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/notifications/unread/count", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setNotificationCount(res.data.unreadCount);
    } catch (err) {
      console.error("Error fetching notifications count:", err);
    }
  };

  useEffect(() => {
    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 30000);
    return () => clearInterval(interval);
  }, []);

  const isActive = (path) => {
    if (path === "/admin") return location.pathname === "/admin";
    return location.pathname.startsWith(path);
  };

  const links = [
    { path: "/admin", label: "Dashboard", icon: <FaTachometerAlt /> },
    { path: "/admin/users", label: "Users", icon: <FaUsers /> },
    { path: "/admin/secretaries", label: "Secretaries", icon: <FaUserTie /> },
    { path: "/admin/issues", label: "Issues", icon: <FaExclamationTriangle /> },
    { path: "/admin/issue-log", label: "Issue Log", icon: <FaClipboardList /> },
    { path: "/admin/feedback", label: "Feedback", icon: <FaComments /> },
    { path: "/admin/reports", label: "Reports", icon: <FaFileAlt /> },
  ];

  const dropdownRef = useRef();
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="container-fluid p-0">
      {/* Top Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark w-100" style={{ backgroundColor: "#6c757d" }}>
        <div className="d-flex justify-content-between align-items-center px-3 w-100">
          <span className="navbar-brand mb-0 h1 text-white">{user.name}</span>

          <div className="d-flex align-items-center">
            {/* Notifications */}
            <button 
              className="btn btn-outline-light position-relative me-3" 
              onClick={() => navigate("/admin/notifications")}
            >
              <FaBell />
              {notificationCount > 0 && (
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  {notificationCount}
                </span>
              )}
            </button>

            {/* Profile Dropdown */}
            <div className="dropdown" ref={dropdownRef}>
              <button
                className="btn btn-outline-light d-flex align-items-center"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                style={{ transition: "background 0.3s" }}
              >
                {user.avatar ? (
                  <img
                    src={user.avatar}
                    alt="Avatar"
                    className="rounded-circle me-2"
                    style={{ width: "30px", height: "30px", objectFit: "cover" }}
                  />
                ) : (
                  <FaUserCircle className="me-2" size={24} />
                )}
                <span>{user.name}</span>
              </button>

              <div
                className={`dropdown-menu dropdown-menu-end mt-2 shadow ${
                  dropdownOpen ? "show animate__animated animate__fadeIn" : ""
                }`}
                style={{ minWidth: "200px" }}
              >
                <button
                  className="dropdown-item"
                  onClick={() => { navigate("/admin/profile"); setDropdownOpen(false); }}
                >
                  Profile
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="row m-0">
        {/* Sidebar */}
        <aside
          className="col-md-2 vh-100 p-0"
          style={{ backgroundColor: "#212529", display: "flex", flexDirection: "column", justifyContent: "flex-start" }}
        >
          <nav className="nav flex-column">
            {links.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link d-flex align-items-center p-3 ${
                  isActive(item.path) ? "bg-black text-white" : "text-light"
                }`}
                style={{ transition: "background 0.3s, color 0.3s" }}
                onMouseEnter={(e) => {
                  if (!isActive(item.path)) e.currentTarget.style.backgroundColor = "#343a40";
                }}
                onMouseLeave={(e) => {
                  if (!isActive(item.path)) e.currentTarget.style.backgroundColor = "transparent";
                }}
              >
                {item.icon} <span className="ms-2">{item.label}</span>
              </Link>
            ))}

            {/* Divider line before Logout */}
            <hr className="text-secondary my-2" />

            {/* Sidebar Logout Button */}
            <div className="p-3">
              <button
                className="btn btn-danger w-100 d-flex align-items-center justify-content-center"
                onClick={handleLogout}
              >
                <FaSignOutAlt className="me-2" /> Logout
              </button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="col-md-10 p-4" style={{ backgroundColor: "#f8f9fa", minHeight: "100vh" }}>
          <Outlet context={{ refreshNotifications: fetchNotificationCount }} />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;