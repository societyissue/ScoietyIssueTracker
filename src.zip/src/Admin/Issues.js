import axios from "axios";
import React, { useEffect, useState } from "react";

export default function Issues() {
  const [issues, setIssues] = useState([]);

  const load = async () => {
    try {
      const res = await axios.get("http://localhost:5000/issues", {
        withCredentials: true
      });
      setIssues(res.data);
    } catch (err) {
      console.error(err);
      alert("Failed to fetch issues");
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div>
      <h3>Issues</h3>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th><th>Title</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          {issues.map((i) => (
            <tr key={i.issue_id}>
              <td>{i.issue_id}</td>
              <td>{i.title}</td>
              <td>{i.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}