import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminIssues = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const issuesPerPage = 10;

  useEffect(() => {
    fetchIssues();
  }, []);

  const fetchIssues = async () => {
    setLoading(true);
    setError(null);

    const token = localStorage.getItem("token");
    if (!token) {
      setLoading(false);
      return setError("No authentication token found. Please login.");
    }

    try {
      const res = await axios.get("http://localhost:5000/issues", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setIssues(Array.isArray(res.data) ? res.data : res.data.issues || []);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to fetch issues. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this issue?")) return;

    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/issues/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setIssues(issues.filter((issue) => issue.issue_id !== id && issue.id !== id));
      alert("Issue deleted successfully!");
    } catch (err) {
      alert(err.response?.data?.message || "Failed to delete issue");
    }
  };

  const indexOfLastIssue = currentPage * issuesPerPage;
  const indexOfFirstIssue = indexOfLastIssue - issuesPerPage;
  const currentIssues = issues.slice(indexOfFirstIssue, indexOfLastIssue);
  const totalPages = Math.ceil(issues.length / issuesPerPage);

  if (loading) return <div className="text-center mt-5">Loading issues...</div>;
  if (error) return <div className="text-danger text-center mt-5">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Issues</h2>
      {issues.length === 0 ? (
        <p>No issues found.</p>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead className="table-dark">
                <tr>
                  <th>Sr. No</th>
                  <th>Title</th>
                  <th>Status</th>
                  <th>Submitted By</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentIssues.map((issue, index) => (
                  <tr key={issue.id || issue.issue_id}>
                    <td>{indexOfFirstIssue + index + 1}</td>
                    <td>{issue.title}</td>
                    <td>
                      {issue.status === "Pending" && (
                        <span className="badge bg-warning text-dark">{issue.status}</span>
                      )}
                      {issue.status === "In Progress" && (
                        <span className="badge bg-info text-dark">{issue.status}</span>
                      )}
                      {issue.status === "Resolved" && (
                        <span className="badge bg-success">{issue.status}</span>
                      )}
                      {!["Pending", "In Progress", "Resolved"].includes(issue.status) && (
                        <span className="badge bg-secondary">{issue.status}</span>
                      )}
                    </td>
                    <td>{issue.reporter_name}</td>
                    <td>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(issue.issue_id || issue.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="d-flex justify-content-center mt-3">
            <button
              className="btn btn-secondary me-2"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Previous
            </button>
            <span className="align-self-center">
              Page {currentPage} of {totalPages}
            </span>
            <button
              className="btn btn-secondary ms-2"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default AdminIssues;