import React, { useEffect, useState } from "react";
import axios from "axios";

const IssueLog = () => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/issue-logs", { withCredentials: true })
      .then(res => setLogs(res.data));
  }, []);

  return (
    <div>
      <h3>Issue Logs</h3>
      <table className="table table-bordered">
        <thead>
          <tr><th>ID</th><th>Issue</th><th>Action</th><th>Old</th><th>New</th><th>By</th></tr>
        </thead>
        <tbody>
          {logs.map(l => (
            <tr key={l.log_id}>
              <td>{l.log_id}</td>
              <td>{l.issue_id}</td>
              <td>{l.action}</td>
              <td>{l.old_value}</td>
              <td>{l.new_value}</td>
              <td>{l.updated_by_type} #{l.updated_by_id}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default IssueLog;
