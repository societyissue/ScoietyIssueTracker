import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminIssueLog = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchLogs = async () => {
      setLoading(true);
      setError(null);

      const token = localStorage.getItem("token");
      if (!token) {
        setLoading(false);
        return setError("No authentication token found. Please login.");
      }

      try {
        const res = await axios.get("http://localhost:5000/issue-logs", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setLogs(Array.isArray(res.data) ? res.data : []);
      } catch (err) {
        setError(
          err.response?.data?.message || "Failed to fetch logs. Try again."
        );
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
  }, []);

  if (loading) return <div>Loading issue logs...</div>;
  if (error) return <div className="text-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Issue Logs</h2>
      {logs.length === 0 ? (
        <p>No logs found.</p>
      ) : (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Issue ID</th>
              <th>Action</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.log_id || log.id}>
                <td>{log.log_id || log.id}</td>
                <td>{log.issue_id}</td>
                <td>{log.action}</td>
                <td>
                  {log.created_at
                    ? new Date(log.created_at).toLocaleString()
                    : ""}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AdminIssueLog;