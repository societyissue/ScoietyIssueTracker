import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminIssueLog = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchLogs = async () => {
    setLoading(true);
    setError(null);

    const token = localStorage.getItem("token");
    if (!token) {
      setLoading(false);
      return setError("No authentication token found. Please login.");
    }

    try {
      const res = await axios.get("http://localhost:5000/issue-logs", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const fetchedLogs = Array.isArray(res.data) ? res.data : [];

      const sortedLogs = fetchedLogs.sort(
        (a, b) => new Date(b.created_at) - new Date(a.created_at)
      );

      setLogs(sortedLogs);
    } catch (err) {
      setError(
        err.response?.data?.message || "Failed to fetch logs. Try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (logId) => {
    if (!window.confirm("Are you sure you want to delete this log?")) return;

    const token = localStorage.getItem("token");
    if (!token) return setError("No authentication token found. Please login.");

    try {
      await axios.delete(`http://localhost:5000/issue-logs/${logId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLogs((prev) => prev.filter((log) => log.log_id !== logId && log.id !== logId));
    } catch (err) {
      setError(err.response?.data?.message || "Failed to delete log.");
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  if (loading) return <div>Loading issue logs...</div>;
  if (error) return <div className="text-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Issue Logs</h2>
      {logs.length === 0 ? (
        <p>No logs found.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Issue ID</th>
                <th>Action</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={log.log_id || log.id}>
                  <td>{log.issue_id}</td>
                  <td>{log.action}</td>
                  <td>
                    {log.created_at
                      ? new Date(log.created_at).toLocaleString()
                      : ""}
                  </td>
                  <td>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(log.log_id || log.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminIssueLog;