import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UserForm = ({ isEdit = false }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    uname: "",
    uemail: "",
    upassword: "",
    confirmPassword: "",
    wing: "",
    house_no: "",
    building_name: "",
    secretary_id: "",
  });

  const [secretaries, setSecretaries] = useState([]);
  const [passwordMessage, setPasswordMessage] = useState("");
  const [passwordValid, setPasswordValid] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState("");

  // Load secretaries
  useEffect(() => {
    axios
      .get("http://localhost:5000/secretaries", { withCredentials: true })
      .then((res) => setSecretaries(res.data))
      .catch((err) => console.error("Error fetching secretaries", err));
  }, []);

  // Load user data if editing
  useEffect(() => {
    if (isEdit && id) {
      axios
        .get(`http://localhost:5000/users`, { withCredentials: true })
        .then((res) => {
          const user = res.data.find((u) => String(u.user_id) === String(id));
          if (user) {
            setForm({
              uname: user.uname,
              uemail: user.uemail,
              upassword: "",
              confirmPassword: "",
              wing: user.wing || "",
              house_no: user.house_no || "",
              building_name: user.building_name || "",
              secretary_id: user.secretary_id || "",
            });
          }
        })
        .catch((err) => console.error("Error fetching user", err));
    }
  }, [isEdit, id]);

  // Check password strength
  const checkPasswordStrength = (password) => {
    if (!password) return "";
    const regexWeak = /.{6,}/;
    const regexMedium = /^(?=.*[A-Z])(?=.*\d).{6,}$/;
    const regexStrong = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;

    if (regexStrong.test(password)) return "Strong";
    if (regexMedium.test(password)) return "Medium";
    if (regexWeak.test(password)) return "Weak";
    return "Too Short";
  };

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (name === "upassword") setPasswordStrength(checkPasswordStrength(value));

    if (name === "upassword" || name === "confirmPassword") {
      if (
        (name === "upassword" && value !== form.confirmPassword) ||
        (name === "confirmPassword" && value !== form.upassword)
      ) {
        setPasswordMessage("❌ Passwords do not match");
        setPasswordValid(false);
      } else if (form.upassword || value) {
        setPasswordMessage("✅ Passwords match");
        setPasswordValid(true);
      } else {
        setPasswordMessage("");
        setPasswordValid(false);
      }
    }
  };

  // Filter secretaries by building
  const filteredSecretaries = secretaries.filter(
    (sec) =>
      form.building_name &&
      sec.building_name?.toLowerCase() === form.building_name.toLowerCase()
  );

  useEffect(() => {
    if (filteredSecretaries.length === 1) {
      setForm((prev) => ({
        ...prev,
        secretary_id: filteredSecretaries[0].secretary_id,
      }));
    } else {
      setForm((prev) => ({ ...prev, secretary_id: "" }));
    }
  }, [form.building_name, filteredSecretaries]);

  // Submit
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!isEdit && form.upassword !== form.confirmPassword) {
      toast.error("Passwords do not match!");
      return;
    }

    if (isEdit) {
      axios
        .put(`http://localhost:5000/users/${id}`, form, { withCredentials: true })
        .then(() => {
          toast.success("✅ User updated successfully!");
          setTimeout(() => navigate("/users", { replace: true }), 2000);
        })
        .catch(() => toast.error("Failed to update user"));
    } else {
      axios
        .post("http://localhost:5000/users", form, { withCredentials: true })
        .then(() => {
          toast.success("✅ User added successfully!");
          setTimeout(() => navigate("/users", { replace: true }), 2000);
        })
        .catch(() => toast.error("Failed to add user"));
    }
  };

  // Cancel with toast confirmation
  const handleCancel = () => {
    toast.info(
      <div>
        Are you sure you want to cancel? Changes will be lost.
        <div className="mt-2">
          <button
            className="btn btn-sm btn-danger me-2"
            onClick={() => {
              toast.dismiss();
              navigate("/users", { replace: true });
            }}
          >
            Yes, Cancel
          </button>
          <button className="btn btn-sm btn-secondary" onClick={() => toast.dismiss()}>
            No
          </button>
        </div>
      </div>,
      { autoClose: false, closeButton: false }
    );
  };

  const disableSubmit =
    form.building_name && (!form.secretary_id || filteredSecretaries.length === 0);

  const getStrengthColor = () => {
    switch (passwordStrength) {
      case "Strong":
        return "text-success";
      case "Medium":
        return "text-warning";
      case "Weak":
      case "Too Short":
        return "text-danger";
      default:
        return "";
    }
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-lg border-0">
        <div className="card-header bg-primary text-white d-flex align-items-center">
          <i className="fas fa-user-plus me-2"></i>
          <h4 className="mb-0">{isEdit ? "Edit User" : "Add User"}</h4>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="row g-4">
              {/* Left Column */}
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Name</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fas fa-user"></i>
                    </span>
                    <input
                      type="text"
                      name="uname"
                      value={form.uname}
                      onChange={handleChange}
                      required
                      className="form-control"
                      placeholder="Enter full name"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Email</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fas fa-envelope"></i>
                    </span>
                    <input
                      type="email"
                      name="uemail"
                      value={form.uemail}
                      onChange={handleChange}
                      required
                      className="form-control"
                      placeholder="Enter email address"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Password</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fas fa-lock"></i>
                    </span>
                    <input
                      type="password"
                      name="upassword"
                      placeholder={
                        isEdit
                          ? "Leave blank to keep current password"
                          : "Enter password"
                      }
                      value={form.upassword}
                      onChange={handleChange}
                      className="form-control"
                    />
                  </div>
                  {form.upassword && (
                    <small className={`mt-1 d-block ${getStrengthColor()}`}>
                      Password Strength: {passwordStrength}
                    </small>
                  )}
                </div>

                {!isEdit && (
                  <div className="mb-3">
                    <label className="form-label">Confirm Password</label>
                    <div className="input-group">
                      <span className="input-group-text">
                        <i className="fas fa-check-circle"></i>
                      </span>
                      <input
                        type="password"
                        name="confirmPassword"
                        placeholder="Re-enter password"
                        value={form.confirmPassword}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    {passwordMessage && (
                      <small
                        className={`mt-1 d-block ${
                          passwordValid ? "text-success" : "text-danger"
                        }`}
                      >
                        {passwordMessage}
                      </small>
                    )}
                  </div>
                )}
              </div>

              {/* Right Column */}
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Wing</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fas fa-building"></i>
                    </span>
                    <input
                      type="text"
                      name="wing"
                      value={form.wing}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter wing"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">House No</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fas fa-home"></i>
                    </span>
                    <input
                      type="text"
                      name="house_no"
                      value={form.house_no}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter house number"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Building Name</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fas fa-city"></i>
                    </span>
                    <input
                      type="text"
                      name="building_name"
                      value={form.building_name}
                      onChange={handleChange}
                      className="form-control"
                      placeholder="Enter building name"
                    />
                  </div>
                </div>

                {form.building_name && (
                  <div className="mb-3">
                    <label className="form-label">Secretary</label>
                    <div className="input-group">
                      <span className="input-group-text">
                        <i className="fas fa-user-tie"></i>
                      </span>
                      <select
                        name="secretary_id"
                        value={form.secretary_id}
                        onChange={handleChange}
                        className="form-select"
                        required
                      >
                        <option value="">-- Select Secretary --</option>
                        {filteredSecretaries.length > 0 ? (
                          filteredSecretaries.map((sec) => (
                            <option key={sec.secretary_id} value={sec.secretary_id}>
                              {sec.sname} ({sec.building_name})
                            </option>
                          ))
                        ) : (
                          <option disabled>No secretary found for this building</option>
                        )}
                      </select>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 d-flex justify-content-between">
              <button
                type="button"
                className="btn btn-outline-danger"
                onClick={handleCancel}
              >
                <i className="fas fa-times me-2"></i> Cancel
              </button>
              <button
                type="submit"
                disabled={
                  disableSubmit ||
                  (!isEdit &&
                    (!passwordValid ||
                      passwordStrength === "Weak" ||
                      passwordStrength === "Too Short"))
                }
                className={`btn ${
                  disableSubmit ||
                  (!isEdit &&
                    (!passwordValid ||
                      passwordStrength === "Weak" ||
                      passwordStrength === "Too Short"))
                    ? "btn-secondary"
                    : "btn-primary"
                }`}
              >
                <i
                  className={`me-2 ${
                    isEdit ? "fas fa-save" : "fas fa-plus-circle"
                  }`}
                ></i>
                {isEdit ? "Update User" : "Add User"}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Toast Container */}
      <ToastContainer position="top-right" autoClose={2000} hideProgressBar />
    </div>
  );
};

export default UserForm;