import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const [stats, setStats] = useState({
    issues: 0,
    pendingIssues: 0,
    inProgressIssues: 0,
    resolvedIssues: 0,
  });

  const [recentIssues, setRecentIssues] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // 🔹 Fetch stats (total, pending, in progress, resolved)
    axios.get("/issues/stats", { withCredentials: true })
      .then(res => {
        setStats({
          issues: res.data.total || 0,
          pendingIssues: res.data.pending || 0,
          inProgressIssues: res.data.inProgress || 0,
          resolvedIssues: res.data.resolved || 0,
        });
      })
      .catch(err => console.error("Error fetching stats:", err));

    // 🔹 Fetch last 5 recent issues
    axios.get("/issues", { withCredentials: true })
      .then(res => {
        setRecentIssues(res.data.slice(-5).reverse());
      })
      .catch(err => console.error("Error fetching issues:", err));
  }, []);

  // 🔹 Function to handle card clicks
  const handleCardClick = (status) => {
    if (status === "All") {
      navigate("/issues");
    } else {
      navigate(`/issues?status=${status}`);
    }
  };

  return (
    <div>
      <h2 className="mb-1">Admin Dashboard</h2>
      <p className="text-muted">Quick overview of issues</p>

      {/* Stats Row */}
      <div className="row g-4 mb-4">
        {/* Total Issues */}
        <div className="col-md-3">
          <div
            className="card shadow-sm text-center border-0 cursor-pointer"
            style={{ cursor: "pointer" }}
            onClick={() => handleCardClick("All")}
          >
            <div className="card-body">
              <i className="fas fa-exclamation-circle fa-2x text-primary mb-2"></i>
              <h6 className="text-muted">Total Issues</h6>
              <h3>{stats.issues}</h3>
            </div>
          </div>
        </div>

        {/* Pending Issues */}
        <div className="col-md-3">
          <div
            className="card shadow-sm text-center border-0"
            style={{ cursor: "pointer" }}
            onClick={() => handleCardClick("Pending")}
          >
            <div className="card-body">
              <i className="fas fa-hourglass-half fa-2x text-warning mb-2"></i>
              <h6 className="text-warning">Pending Issues</h6>
              <h3 className="text-warning">{stats.pendingIssues}</h3>
            </div>
          </div>
        </div>

        {/* In Progress Issues */}
        <div className="col-md-3">
          <div
            className="card shadow-sm text-center border-0 bg-info text-white"
            style={{ cursor: "pointer" }}
            onClick={() => handleCardClick("In Progress")}
          >
            <div className="card-body">
              <i className="fas fa-spinner fa-spin fa-2x mb-2"></i>
              <h6>In Progress</h6>
              <h3>{stats.inProgressIssues}</h3>
            </div>
          </div>
        </div>

        {/* Resolved Issues */}
        <div className="col-md-3">
          <div
            className="card shadow-sm text-center border-0 bg-success text-white"
            style={{ cursor: "pointer" }}
            onClick={() => handleCardClick("Resolved")}
          >
            <div className="card-body">
              <i className="fas fa-check-circle fa-2x mb-2"></i>
              <h6>Resolved Issues</h6>
              <h3>{stats.resolvedIssues}</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Issues */}
      <div className="card shadow-sm border-0">
        <div className="card-header bg-white">
          <h5 className="mb-0">Recent Issues</h5>
        </div>
        <ul className="list-group list-group-flush">
          {recentIssues.map(i => (
            <li
              key={i.issue_id}
              className="list-group-item d-flex justify-content-between align-items-center"
            >
              <span>
                <i className="fas fa-bug me-2 text-secondary"></i>
                {i.title}
              </span>
              <span
                className={`badge d-flex align-items-center px-3 py-2 ${
                  i.status === "Resolved"
                    ? "bg-success"
                    : i.status === "In Progress"
                    ? "bg-info text-white"
                    : "bg-warning text-dark"
                }`}
              >
                {i.status}
              </span>
            </li>
          ))}
          {recentIssues.length === 0 && (
            <li className="list-group-item text-center text-muted">
              No issues found
            </li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;