import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminDashboard = () => {
  const [stats, setStats] = useState({});
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAdminData = async () => {
    setLoading(true);
    setError(null);

    const token = localStorage.getItem("token");
    if (!token) {
      setError("No token found. Please login.");
      setLoading(false);
      return;
    }

    const config = { headers: { Authorization: `Bearer ${token}` } };

    try {
      // Fetch stats
      const statsRes = await axios.get("http://localhost:5000/issues/stats", config);

      // Fetch issues
      const issuesRes = await axios.get("http://localhost:5000/issues", config);
      const fetchedIssues = Array.isArray(issuesRes.data)
        ? issuesRes.data
        : issuesRes.data.issues || [];

      setStats(statsRes.data || {});
      setIssues(fetchedIssues); // use reporter_name from API directly
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load admin data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
    const interval = setInterval(fetchAdminData, 15000); // Refresh every 15s
    return () => clearInterval(interval);
  }, []);

  if (loading) return <div className="text-center mt-5">Loading dashboard...</div>;
  if (error) return <div className="text-danger text-center mt-5">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Dashboard</h2>
      <p className="text-muted">Overview of all issues</p>

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card text-white bg-primary h-100">
            <div className="card-body">
              <h5 className="card-title">Total Issues</h5>
              <p className="card-text fs-4">{stats.total || 0}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-white bg-warning h-100">
            <div className="card-body">
              <h5 className="card-title">Pending</h5>
              <p className="card-text fs-4">{stats.pending || 0}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-white bg-info h-100">
            <div className="card-body">
              <h5 className="card-title">In Progress</h5>
              <p className="card-text fs-4">{stats.inProgress || 0}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-white bg-success h-100">
            <div className="card-body">
              <h5 className="card-title">Resolved</h5>
              <p className="card-text fs-4">{stats.resolved || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Issues Table */}
      <div className="card">
        <div className="card-header bg-dark text-white text-center">
          <h5 className="mb-0">All Issues</h5>
        </div>
        <div className="card-body p-0">
          {issues.length === 0 ? (
            <p className="p-3">No issues found.</p>
          ) : (
            <div className="table-responsive">
              <table className="table table-striped table-hover mb-0">
                <thead className="table-dark">
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Submitted By</th>
                  </tr>
                </thead>
                <tbody>
                  {issues.map((issue) => (
                    <tr key={issue.id || issue.issue_id}>
                      <td>{issue.id || issue.issue_id}</td>
                      <td>{issue.title}</td>
                      <td>{issue.status}</td>
                      <td>{issue.reporter_name}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;