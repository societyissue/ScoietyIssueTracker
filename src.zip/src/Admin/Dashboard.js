import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [stats, setStats] = useState({
    issues: 0,
    pendingIssues: 0,
    inProgressIssues: 0,
    resolvedIssues: 0,
  });

  const [recentIssues, setRecentIssues] = useState([]);

  useEffect(() => {
    // 🔹 Fetch stats
    axios
      .get("http://localhost:5000/issues/stats", { withCredentials: true })
      .then((res) => {
        setStats({
          issues: res.data.total || 0,
          pendingIssues: res.data.pending || 0,
          inProgressIssues: res.data.inProgress || 0,
          resolvedIssues: res.data.resolved || 0,
        });
      })
      .catch((err) => console.error("Error fetching stats:", err));

    // 🔹 Fetch last 5 issues
    axios
      .get("http://localhost:5000/issues", { withCredentials: true })
      .then((res) => {
        setRecentIssues(res.data.slice(0, 5)); // top 5 recent
      })
      .catch((err) => console.error("Error fetching issues:", err));
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-1">Dashboard</h2>
      <p className="text-muted">Quick overview of issues</p>

      {/* Stats Row */}
      <div className="row g-4 mb-4">
        <div className="col-md-3">
          <div className="card shadow-sm text-center border-0">
            <div className="card-body">
              <i className="fas fa-exclamation-circle fa-2x text-primary mb-2"></i>
              <h6 className="text-muted">Total Issues</h6>
              <h3>{stats.issues}</h3>
            </div>
          </div>
        </div>

        <div className="col-md-3">
          <div className="card shadow-sm text-center border-0">
            <div className="card-body">
              <i className="fas fa-hourglass-half fa-2x text-warning mb-2"></i>
              <h6 className="text-warning">Pending Issues</h6>
              <h3 className="text-warning">{stats.pendingIssues}</h3>
            </div>
          </div>
        </div>

        <div className="col-md-3">
          <div className="card shadow-sm text-center border-0 bg-info text-white">
            <div className="card-body">
              <i className="fas fa-spinner fa-spin fa-2x mb-2"></i>
              <h6>In Progress</h6>
              <h3>{stats.inProgressIssues}</h3>
            </div>
          </div>
        </div>

        <div className="col-md-3">
          <div className="card shadow-sm text-center border-0 bg-success text-white">
            <div className="card-body">
              <i className="fas fa-check-circle fa-2x mb-2"></i>
              <h6>Resolved Issues</h6>
              <h3>{stats.resolvedIssues}</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Issues */}
      <div className="card shadow-sm border-0">
        <div className="card-header bg-white">
          <h5 className="mb-0">Recent Issues</h5>
        </div>
        <ul className="list-group list-group-flush">
          {recentIssues.length > 0 ? (
            recentIssues.map((i) => (
              <li
                key={i.issue_id}
                className="list-group-item d-flex justify-content-between align-items-center flex-column flex-md-row"
              >
                <div>
                  <i className="fas fa-bug me-2 text-secondary"></i>
                  <strong>{i.title}</strong> &nbsp;
                  <span className="text-muted small">by {i.reporter_name || "Unknown"}</span>
                </div>
                <span
                  className={`badge d-flex align-items-center px-3 py-2 mt-2 mt-md-0 ${
                    i.status === "Resolved"
                      ? "bg-success"
                      : i.status === "In Progress"
                      ? "bg-info text-white"
                      : "bg-warning text-dark"
                  }`}
                >
                  {i.status}
                </span>
              </li>
            ))
          ) : (
            <li className="list-group-item text-center text-muted">
              No issues found
            </li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;