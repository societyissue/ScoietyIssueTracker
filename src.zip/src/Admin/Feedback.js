import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminFeedback = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      setLoading(true);
      setError(null);

      const token = localStorage.getItem("token");
      if (!token) {
        setLoading(false);
        return setError("No authentication token found. Please login.");
      }

      try {
        const res = await axios.get("http://localhost:5000/feedback", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setFeedbacks(Array.isArray(res.data) ? res.data : res.data.feedbacks || []);
      } catch (err) {
        setError(
          err.response?.data?.message || "Failed to fetch feedbacks. Try again."
        );
      } finally {
        setLoading(false);
      }
    };

    fetchFeedbacks();
  }, []);

  if (loading) return <div>Loading feedbacks...</div>;
  if (error) return <div className="text-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Feedback</h2>
      {feedbacks.length === 0 ? (
        <p>No feedback found.</p>
      ) : (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Message</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {feedbacks.map((fb) => (
              <tr key={fb.id || fb.feedback_id}>
                <td>{fb.id || fb.feedback_id}</td>
                <td>{fb.user_name}</td>
                <td>{fb.message}</td>
                <td>{new Date(fb.date).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AdminFeedback;