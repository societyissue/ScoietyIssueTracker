import React, { useEffect, useState } from "react";
import axios from "axios";

const Feedback = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/feedback", { withCredentials: true })
      .then(res => setData(res.data));
  }, []);

  return (
    <div>
      <h3>Feedback</h3>
      <ul className="list-group">
        {data.map(f => (
          <li key={f.feedback_id} className="list-group-item">
            <strong>Issue {f.issue_id}</strong>: {f.feedback_text}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Feedback;