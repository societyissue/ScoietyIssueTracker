import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminFeedback = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchFeedbacks = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/admin/feedback", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFeedbacks(res.data);
    } catch (err) {
      console.error("Failed to fetch feedbacks:", err);
      alert("Failed to load feedbacks");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this feedback?")) return;

    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/feedback/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFeedbacks(feedbacks.filter((fb) => fb.feedback_id !== id));
      alert("Feedback deleted successfully");
    } catch (err) {
      console.error("Failed to delete feedback:", err);
      alert("Failed to delete feedback");
    }
  };

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  if (loading) return <p className="text-center mt-5">Loading feedbacks...</p>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Admin Feedbacks</h2>
      {feedbacks.length === 0 ? (
        <p>No feedbacks available.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-bordered table-hover">
            <thead className="table-dark">
              <tr>
                <th>Sr No.</th>
                <th>Feedback</th>
                <th>Giver Name</th>
                <th>Giver Email</th>
                <th>Issue Title</th>
                <th>Building</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {feedbacks.map((fb, index) => (
                <tr key={fb.feedback_id}>
                  <td>{index + 1}</td>
                  <td>{fb.feedback_text}</td>
                  <td>{fb.giver_name}</td>
                  <td>{fb.giver_email}</td>
                  <td>{fb.issue_title || "-"}</td>
                  <td>{fb.building_name || "-"}</td>
                  <td>{new Date(fb.created_at).toLocaleString()}</td>
                  <td>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleDelete(fb.feedback_id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminFeedback;