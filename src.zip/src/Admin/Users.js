import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";

const Users = () => {
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  // Load users
  const loadUsers = async () => {
    try {
      const res = await axios.get("http://localhost:5000/users", { withCredentials: true });
      setUsers(res.data);
    } catch (err) {
      console.error("Error loading users:", err);
    }
  };

  // Reload users whenever the route changes to /admin/users
  useEffect(() => {
    if (location.pathname === "/admin/users") {
      loadUsers();
    }
  }, [location.pathname]);

  return (
    <div className="container mt-3">
      <h3>Users</h3>

      <button
        className="btn btn-success mb-3"
        onClick={() => navigate("/admin/users/new")}
      >
        Add New User
      </button>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Building</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.user_id}>
              <td>{u.user_id}</td>
              <td>{u.uname}</td>
              <td>{u.uemail}</td>
              <td>{u.building_name}</td>
              <td>
                <button
                  className="btn btn-sm btn-primary me-1"
                  onClick={() => navigate(`/admin/users/edit/${u.user_id}`)}
                >
                  Edit
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={async () => {
                    if (window.confirm("Are you sure you want to delete this user?")) {
                      await axios.delete(`http://localhost:5000/users/${u.user_id}`, { withCredentials: true });
                      loadUsers();
                    }
                  }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
          {users.length === 0 && (
            <tr>
              <td colSpan="5" className="text-center">No users found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Users;