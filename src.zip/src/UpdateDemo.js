import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, useLocation, useParams } from 'react-router-dom';

const UpdateEmployee = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { state } = useLocation(); // 👈 Get employee from location
  const employee = state?.employee;

  const [formValues, setFormValues] = useState({
    name: employee?.name || '',
    age: employee?.age || ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', formValues.name);
    formData.append('age', formValues.age);

    try {
      await axios.put(`http://localhost:8000/emp/${id}`, formData);
      alert('Employee updated successfully');
      navigate('/');
    } catch (err) {
      alert('Update error: ' + (err.response?.data?.message || err.message));
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Update Employee</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name: </label>
          <input
            name="name"
            value={formValues.name}
            onChange={handleChange}
            required
          />
        </div>
        <br />
        <div>
          <label>Age: </label>
          <input
            name="age"
            value={formValues.age}
            onChange={handleChange}
            required
          />
        </div>
        <br />
        <button type="submit">Update</button>
      </form>
    </div>
  );
};

export default UpdateEmployee;