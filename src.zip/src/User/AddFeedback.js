import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddFeedback = () => {
  const [user, setUser] = useState(null);
  const [issues, setIssues] = useState([]);
  const [selectedIssue, setSelectedIssue] = useState("");
  const [feedbackText, setFeedbackText] = useState("");
  const [message, setMessage] = useState("");

  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  // 1️⃣ Get logged-in user
  useEffect(() => {
    if (!token) return;

    axios
      .get("http://localhost:5000/auth/me", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setUser(res.data))
      .catch((err) => console.error("Auth error:", err));
  }, [token]);

  // 2️⃣ Fetch issues reported by this user
  useEffect(() => {
    if (!user) return;

    axios
      .get("http://localhost:5000/issues", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => {
        const userIssues = res.data.filter(
          (issue) => issue.reporter_id === user.id
        );
        setIssues(userIssues);
      })
      .catch((err) => {
        console.error(err);
        setMessage("Failed to load your issues");
      });
  }, [user, token]);

  // 3️⃣ Submit feedback
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedIssue || !feedbackText) {
      setMessage("Please select an issue and enter feedback");
      return;
    }

    try {
      await axios.post(
        "http://localhost:5000/feedback",
        { issue_id: selectedIssue, feedback_text: feedbackText },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Redirect to user feedback page after submission
      navigate("/user/feedback");
    } catch (err) {
      console.error(err);
      setMessage(err.response?.data?.message || "Failed to submit feedback");
    }
  };

  const handleCancel = () => {
    navigate("/user/feedback");
  };

  if (!user) return <p className="text-center mt-5">Please log in...</p>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Submit Feedback</h2>

      <div className="card mb-4">
        <div className="card-body">
          {message && <p className="text-danger">{message}</p>}
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Select Issue</label>
              <select
                className="form-select"
                value={selectedIssue}
                onChange={(e) => setSelectedIssue(e.target.value)}
              >
                <option value="">-- Select an Issue --</option>
                {issues.map((issue) => (
                  <option key={issue.issue_id} value={issue.issue_id}>
                    {issue.title} (#{issue.issue_id})
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Your Feedback</label>
              <textarea
                className="form-control"
                rows="4"
                value={feedbackText}
                onChange={(e) => setFeedbackText(e.target.value)}
              ></textarea>
            </div>

            <button type="submit" className="btn btn-primary me-2">
              Submit
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleCancel}
            >
              Cancel
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddFeedback;