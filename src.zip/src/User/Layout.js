import React, { useEffect, useState, useRef } from "react";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import {
  FaTachometerAlt,
  FaBug,
  FaComments,
  FaBell,
  FaFileAlt,
  FaSignOutAlt,
  FaUserCircle,
} from "react-icons/fa";
import axios from "axios";

const UserLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [notificationCount, setNotificationCount] = useState(0);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const [user, setUser] = useState({ name: "User", avatar: null });
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser({
        name: storedUser.name || "User",
        avatar: storedUser.avatar || null,
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  };

  const fetchNotificationCount = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get(
        "http://localhost:5000/notifications/unread/count",
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNotificationCount(res.data.unreadCount);
    } catch (err) {
      console.error("Error fetching notifications count:", err);
    }
  };

  useEffect(() => {
    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 30000);
    return () => clearInterval(interval);
  }, []);

  const isActive = (path) => {
    if (path === "/user") return location.pathname === "/user";
    return location.pathname.startsWith(path);
  };

  const links = [
    { path: "/user", label: "Dashboard", icon: <FaTachometerAlt /> },
    { path: "/user/report-issue", label: "Report Issue", icon: <FaBug /> },
    { path: "/user/feedback", label: "Feedback", icon: <FaComments /> },
    { path: "/user/notifications", label: "Notifications", icon: <FaBell /> },
    { path: "/user/reports", label: "Reports", icon: <FaFileAlt /> },
  ];

  const dropdownRef = useRef();
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="container-fluid p-0">
      {/* Top Navbar */}
      <nav
        className="navbar navbar-expand-lg navbar-dark w-100"
        style={{ backgroundColor: "#6c757d" }}
      >
        <div className="d-flex justify-content-between align-items-center px-3 w-100">
          <span className="navbar-brand mb-0 h1 text-white">{user.name}</span>

          <div className="d-flex align-items-center">
            {/* Notifications */}
            <button
              className="btn btn-outline-light position-relative me-3"
              onClick={() => navigate("/user/notifications")}
            >
              <FaBell />
              {notificationCount > 0 && (
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  {notificationCount}
                </span>
              )}
            </button>

            {/* Profile Dropdown */}
            <div className="dropdown" ref={dropdownRef}>
              <button
                className="btn btn-outline-light d-flex align-items-center"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                style={{ transition: "background 0.3s" }}
              >
                {user.avatar ? (
                  <img
                    src={user.avatar}
                    alt="Avatar"
                    className="rounded-circle me-2"
                    style={{ width: "30px", height: "30px", objectFit: "cover" }}
                  />
                ) : (
                  <FaUserCircle className="me-2" size={24} />
                )}
                <span>{user.name}</span>
              </button>

              <div
                className={`dropdown-menu dropdown-menu-end mt-2 shadow ${
                  dropdownOpen ? "show animate__animated animate__fadeIn" : ""
                }`}
                style={{ minWidth: "200px" }}
              >
                <button
                  className="dropdown-item"
                  onClick={() => {
                    navigate("/user/profile");
                    setDropdownOpen(false);
                  }}
                >
                  Profile
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="row m-0">
        {/* Sidebar */}
        <aside
          className="col-md-2 vh-100 p-0 d-flex flex-column"
          style={{ backgroundColor: "#212529" }}
        >
          <nav className="nav flex-column flex-grow-1">
            {links.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link d-flex align-items-center p-3 ${
                  isActive(item.path) ? "bg-black text-white" : "text-light"
                }`}
                style={{ transition: "background 0.3s, color 0.3s" }}
                onMouseEnter={(e) => {
                  if (!isActive(item.path))
                    e.currentTarget.style.backgroundColor = "#343a40";
                }}
                onMouseLeave={(e) => {
                  if (!isActive(item.path))
                    e.currentTarget.style.backgroundColor = "transparent";
                }}
              >
                {item.icon} <span className="ms-2">{item.label}</span>
              </Link>
            ))}

            {/* Divider line */}
            <hr className="text-secondary my-2" />

            {/* Logout Button just after Reports */}
            <div className="p-3">
              <button
                className="btn btn-danger w-100 d-flex align-items-center justify-content-center"
                onClick={handleLogout}
              >
                <FaSignOutAlt className="me-2" /> Logout
              </button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main
          className="col-md-10 p-4"
          style={{ backgroundColor: "#f8f9fa", minHeight: "100vh" }}
        >
          <Outlet context={{ refreshNotifications: fetchNotificationCount }} />
        </main>
      </div>
    </div>
  );
};

export default UserLayout;