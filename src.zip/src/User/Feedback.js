import React, { useState } from "react";
import axios from "axios";

const Feedback = () => {
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:5000/user/feedback", { message }, { withCredentials: true })
      .then(() => {
        alert("Feedback submitted!");
        setMessage("");
      })
      .catch(err => console.error(err));
  };

  return (
    <div className="container mt-4">
      <h2>Submit Feedback</h2>
      <form onSubmit={handleSubmit}>
        <textarea 
          className="form-control mb-3" 
          rows="4" 
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Enter your feedback"
        />
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
};

export default Feedback;