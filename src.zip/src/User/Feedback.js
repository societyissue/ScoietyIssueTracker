import React, { useEffect, useState } from "react";
import axios from "axios";

const UserFeedback = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // form state
  const [issueId, setIssueId] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const fetchFeedbacks = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/user/feedback", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFeedbacks(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to fetch feedback");
    } finally {
      setLoading(false);
    }
  };

  const fetchIssues = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/issues", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setIssues(res.data);
    } catch (err) {
      console.error("Failed to fetch issues", err);
    }
  };

  useEffect(() => {
    fetchFeedbacks();
    fetchIssues();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!issueId || !message.trim()) {
      return alert("Please select an issue and enter your feedback.");
    }

    try {
      setSubmitting(true);
      const token = localStorage.getItem("token");

      await axios.post(
        "http://localhost:5000/user/feedback",
        { issue_id: issueId, feedback_text: message },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setMessage("");
      setIssueId("");
      fetchFeedbacks(); // refresh feedback list
    } catch (err) {
      alert(err.response?.data?.message || "Failed to submit feedback");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="text-center mt-5">Loading feedbacks...</div>;
  if (error) return <div className="text-danger text-center mt-5">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-3">My Feedback</h2>

      {/* Feedback Form */}
      <div className="card p-3 mb-4 shadow-sm">
        <h5 className="mb-3">Send Feedback</h5>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Select Issue</label>
            <select
              className="form-select"
              value={issueId}
              onChange={(e) => setIssueId(e.target.value)}
              required
            >
              <option value="">-- Select Issue --</option>
              {issues.map((issue) => (
                <option key={issue.issue_id} value={issue.issue_id}>
                  {issue.title}
                </option>
              ))}
            </select>
          </div>

          <div className="mb-3">
            <label className="form-label">Feedback Message</label>
            <textarea
              className="form-control"
              rows="3"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            disabled={submitting}
          >
            {submitting ? "Sending..." : "Send Feedback"}
          </button>
        </form>
      </div>

      {/* Feedback List */}
      <div className="table-responsive">
        <table className="table table-striped table-hover">
          <thead className="table-dark">
            <tr>
              <th>Issue</th>
              <th>Message</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {feedbacks.map((fb) => (
              <tr key={fb.feedback_id}>
                <td>{fb.issue_title}</td>
                <td>{fb.feedback_text}</td>
                <td>{new Date(fb.created_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserFeedback;