import React, { useEffect, useState } from "react";
import axios from "axios";

const Notification = () => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/user/notifications", { withCredentials: true })
      .then(res => setNotifications(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container mt-4">
      <h2>Notifications</h2>
      <ul className="list-group">
        {notifications.map((n, i) => (
          <li key={i} className="list-group-item">
            {n.message} <span className="text-muted">({n.date})</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Notification;
