import React, { useState } from "react";
import axios from "axios";

const ReportIssue = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [buildingName, setBuildingName] = useState("");
  const [category, setCategory] = useState("");
  const [images, setImages] = useState([]); // multiple images
  const [message, setMessage] = useState("");

  // Handle image selection
  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setImages(files);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);
      formData.append("building_name", buildingName);
      formData.append("category", category);

      images.forEach((img) => {
        formData.append("images", img); // append multiple images
      });

      const res = await axios.post("http://localhost:5000/issues", formData, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true,
      });

      setMessage("Issue reported successfully!");
      setTitle("");
      setDescription("");
      setBuildingName("");
      setCategory("");
      setImages([]);
    } catch (err) {
      console.error(err);
      setMessage("Error reporting issue. Please try again.");
    }
  };

  return (
    <div className="container">
      <h2 className="mb-4">Report an Issue</h2>
      {message && <div className="alert alert-info">{message}</div>}

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Issue Title</label>
          <input
            type="text"
            className="form-control"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Description</label>
          <textarea
            className="form-control"
            rows="4"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          ></textarea>
        </div>

        <div className="mb-3">
          <label className="form-label">Building Name</label>
          <input
            type="text"
            className="form-control"
            value={buildingName}
            onChange={(e) => setBuildingName(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Category</label>
          <input
            type="text"
            className="form-control"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Upload Images (optional)</label>
          <input
            type="file"
            className="form-control"
            onChange={handleImageChange}
            multiple
            accept="image/*"
          />
        </div>

        {images.length > 0 && (
          <div className="mb-3">
            <label className="form-label">Preview:</label>
            <div className="d-flex flex-wrap gap-2">
              {images.map((img, idx) => (
                <img
                  key={idx}
                  src={URL.createObjectURL(img)}
                  alt={`preview-${idx}`}
                  width="100"
                  height="100"
                  style={{ objectFit: "cover", borderRadius: "5px" }}
                />
              ))}
            </div>
          </div>
        )}

        <button type="submit" className="btn btn-primary">
          Submit Issue
        </button>
      </form>
    </div>
  );
};

export default ReportIssue;