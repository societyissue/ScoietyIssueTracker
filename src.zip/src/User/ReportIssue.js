// ReportIssue.js
import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaPlusCircle, FaImage } from "react-icons/fa";

const ReportIssue = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("Pending");
  const [buildingName, setBuildingName] = useState("");
  const [message, setMessage] = useState("");
  const [images, setImages] = useState([]);

  useEffect(() => {
    // Fetch current user's building
    axios
      .get("http://localhost:5000/auth/me", { withCredentials: true })
      .then((res) => {
        const user = res.data;
        setBuildingName(user.building_name || "");
      })
      .catch((err) => console.error(err));
  }, []);

  const handleImageChange = (e) => {
    setImages([...e.target.files]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    try {
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);
      formData.append("category", category);
      formData.append("status", status);
      formData.append("building_name", buildingName);

      images.forEach((img) => formData.append("images", img));

      await axios.post("http://localhost:5000/issues", formData, {
        withCredentials: true,
        headers: { "Content-Type": "multipart/form-data" },
      });

      setMessage("Issue reported successfully!");
      setTitle("");
      setDescription("");
      setCategory("");
      setStatus("Pending");
      setImages([]);
    } catch (err) {
      console.error(err);
      setMessage("Failed to report issue.");
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">
        <FaPlusCircle className="me-2" />
        Report an Issue
      </h2>

      {message && <div className="alert alert-info">{message}</div>}

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Title</label>
          <input
            type="text"
            className="form-control"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            placeholder="Enter issue title"
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Description</label>
          <textarea
            className="form-control"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            placeholder="Describe the issue"
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Category</label>
          <input
            type="text"
            className="form-control"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            required
            placeholder="E.g., Electrical, Plumbing"
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Status</label>
          <select
            className="form-select"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">
            <FaImage className="me-1" /> Attach Images
          </label>
          <input
            type="file"
            className="form-control"
            onChange={handleImageChange}
            multiple
            accept="image/*"
          />
        </div>

        <button type="submit" className="btn btn-primary">
          <FaPlusCircle className="me-2" />
          Submit Issue
        </button>
      </form>
    </div>
  );
};

export default ReportIssue;