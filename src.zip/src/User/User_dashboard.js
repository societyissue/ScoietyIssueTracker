import React, { useEffect, useState } from "react";
import axios from "axios";

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch user info
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;

    axios
      .get("http://localhost:5000/auth/me", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setUser(res.data))
      .catch((err) => console.error("Auth error:", err));
  }, []);

  // Fetch issues
  useEffect(() => {
    if (!user) return;

    const token = localStorage.getItem("token");

    axios
      .get("http://localhost:5000/issues", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setIssues(res.data))
      .catch((err) => {
        console.error("Issues fetch error:", err);
        alert("Failed to load data: " + (err.response?.data?.message || err.message));
      })
      .finally(() => setLoading(false));
  }, [user]);

  if (!user) return <p className="text-center mt-5">Please log in...</p>;
  if (loading) return <p className="text-center mt-5">Loading your issues...</p>;

  const total = issues.length;
  const pending = issues.filter((i) => i.status === "Pending").length;
  const inProgress = issues.filter((i) => i.status === "In Progress").length;
  const resolved = issues.filter((i) => i.status === "Resolved").length;

  return (
    <div className="container mt-4">
      <h1 className="mb-3">User Dashboard</h1>
      <h4 className="mb-4">Welcome, {user.name}!</h4>

      {/* Stats */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-info text-white">
            <div className="card-body">
              <h5 className="card-title">Total Issues</h5>
              <p className="card-text display-6">{total}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-warning text-dark">
            <div className="card-body">
              <h5 className="card-title">Pending</h5>
              <p className="card-text display-6">{pending}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-center text-white" style={{ backgroundColor: "#6f42c1" }}>
            <div className="card-body">
              <h5 className="card-title">In Progress</h5>
              <p className="card-text display-6">{inProgress}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-success text-white">
            <div className="card-body">
              <h5 className="card-title">Resolved</h5>
              <p className="card-text display-6">{resolved}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Issues Table */}
      <table className="table table-bordered">
        <thead className="table-light">
          <tr>
            <th>Issue ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Category</th>
            <th>Status</th>
            <th>Images</th>
          </tr>
        </thead>

        <tbody>
          {issues.map((issue) => {
            let images = [];
            try {
              images = JSON.parse(issue.image);
              if (!Array.isArray(images)) images = [issue.image];
            } catch (e) {
              images = issue.image ? [issue.image] : [];
            }

            return (
              <tr key={issue.issue_id}>
                <td>{issue.issue_id}</td>
                <td>{issue.title}</td>
                <td>{issue.description}</td>
                <td>{issue.category}</td>
                <td>{issue.status}</td>
                <td>
                  {images.length > 0
                    ? images.map((img, idx) => (
                        <img
                          key={idx}
                          src={`http://localhost:5000/uploads/${img}`}
                          alt="Issue"
                          style={{ width: "100px", marginRight: "10px" }}
                        />
                      ))
                    : "No Image"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default UserDashboard;