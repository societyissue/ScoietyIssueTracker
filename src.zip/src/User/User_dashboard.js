import React, { useEffect, useState } from "react";
import axios from "axios";

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("http://localhost:5000/auth/me", { withCredentials: true })
      .then((res) => setUser(res.data))
      .catch((err) => console.error("Auth error:", err));
  }, []);

  useEffect(() => {
    if (!user) return;

    axios
      .get("http://localhost:5000/issues", { withCredentials: true })
      .then((res) => setIssues(res.data))
      .catch((err) => {
        console.error("Issues fetch error:", err);
        alert("Failed to load data: " + err.response?.data?.message || err.message);
      })
      .finally(() => setLoading(false));
  }, [user]);

  if (!user) return <p>Please log in...</p>;
  if (loading) return <p>Loading your issues...</p>;

  return (
    <div className="container mt-4">
      <h2>User Dashboard</h2>
      <p>Welcome, {user.name}! Here are your reported issues:</p>

      <table className="table table-bordered mt-3">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Building</th>
            <th>Description</th>
            <th>Status</th>
            <th>Images</th>
          </tr>
        </thead>
        <tbody>
          {issues.length === 0 ? (
            <tr>
              <td colSpan="6" className="text-center">
                No issues reported yet.
              </td>
            </tr>
          ) : (
            issues.map((issue) => (
              <tr key={issue.issue_id}>
                <td>{issue.issue_id}</td>
                <td>{issue.title}</td>
                <td>{issue.building_name}</td>
                <td>{issue.description}</td>
                <td>{issue.status}</td>
                <td>
                  {issue.image &&
                    JSON.parse(issue.image).map((img, idx) => (
                      <img
                        key={idx}
                        src={`http://localhost:5000/${img}`}
                        alt={`issue-${idx}`}
                        width="50"
                        height="50"
                        style={{ objectFit: "cover", marginRight: "5px" }}
                      />
                    ))}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default UserDashboard;