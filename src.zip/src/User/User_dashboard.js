import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [issues, setIssues] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/issues", { withCredentials: true }) // fixed URL
      .then(res => setIssues(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container mt-4">
      <h2>User Dashboard</h2>
      <p>Overview of your reported issues</p>
      <table className="table table-bordered mt-3">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Building</th>
            <th>Description</th>
            <th>Status</th>
            <th>Images</th>
          </tr>
        </thead>
        <tbody>
          {issues.map(issue => (
            <tr key={issue.issue_id}>
              <td>{issue.issue_id}</td>
              <td>{issue.title}</td>
              <td>{issue.building_name}</td>
              <td>{issue.description}</td>
              <td>{issue.status}</td>
              <td>
                {issue.image && JSON.parse(issue.image).map((img, idx) => (
                  <img
                    key={idx}
                    src={`http://localhost:5000/${img}`}
                    alt={`issue-${idx}`}
                    width="50"
                    height="50"
                    style={{ objectFit: "cover", marginRight: "5px" }}
                  />
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Dashboard;