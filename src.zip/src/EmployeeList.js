import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  const navigate = useNavigate();

  const fetchEmployees = async () => {
    try {
      const response = await axios.get('http://localhost:8000/employee');
      setEmployees(response.data);
    } catch (error) {
      console.error('Fetch Error:', error.message);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleDelete = async (Emp_no) => {
    if (!window.confirm('Are you sure you want to delete this employee?')) return;
    try {
      await axios.delete(`http://localhost:8000/employee/${Emp_no}`);
      alert('Deleted successfully');
      fetchEmployees();
    } catch (error) {
      console.error(error);
      alert('Delete failed: ' + error.message);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-success">Employee List</h2>
      <button className="btn btn-success mb-3" onClick={() => navigate('/employee-form')}>Add Employee</button>
      <table className="table table-bordered table-striped table-hover">
        <thead className="table-dark">
          <tr>
            <th>Emp No</th>
            <th>Name</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map(emp => (
            <tr key={emp.Emp_no}>
              <td>{emp.Emp_no}</td>
              <td>{emp.Ename}</td>
              <td>{emp.Salary}</td>
              <td>
                <button className="btn btn-primary btn-sm me-2" onClick={() => navigate(`/employee-form/${emp.Emp_no}`)}>
                  Edit
                </button>
                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(emp.Emp_no)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;