import React ,{useState} from 'react';
function Calc ()  {

    const [no1,setNo1] = useState(0);
    const [no2,setNo2] = useState(0);
    const [result,setresult] = useState(0);

    const handleChange = event => setNo1(event.target.value);
    const handleChange2 = event => setNo2(event.target.value);
    
    const check = () =>
    {
        setresult(parseInt(no1)+parseInt(no2));
    }

 
    return (
        <div>
            <form>
                <input type="text" id="no1" placeholder='Enter your firstnumber' value={no1} onChange={handleChange}/>
                <input type='text' id='no2' placeholder='Enter second number' value={no2} onChange={handleChange2}/>
                <input type='text' id='result' placeholder='' value={result} onChange={setresult} readOnly/>
                <button type='button' className='btn-btn-primary' onClick={check}>Submit</button>
            </form>
        </div>
    );
};

export default Calc;
