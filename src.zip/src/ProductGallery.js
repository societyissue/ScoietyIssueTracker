import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const products = [
  { id: 1, name: 'Product 1', price: 50 },
  { id: 2, name: 'Product 2', price: 30 },
  { id: 3, name: 'Product 3', price: 20 },
];

const ProductGallery = () => {
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const handleViewCart = () => {
    navigate('/viewcart', { state: { cart } });
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Product Gallery</h2>

      <table className="table table-bordered table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Price (Rs.)</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.name}</td>
              <td>Rs. {product.price}</td>
              <td>
                <button
                  className="btn btn-sm btn-success"
                  onClick={() => addToCart(product)}
                >
                  Add to Cart
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-center">
        <button className="btn btn-primary mt-3" onClick={handleViewCart}>
          View Cart ({cart.length})
        </button>
      </div>
    </div>
  );
};

export default ProductGallery;