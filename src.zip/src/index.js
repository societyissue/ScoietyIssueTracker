import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
//import 'bootstrap/dist/css/bootstrap.min.css';

import reportWebVitals from './reportWebVitals';
/*import TestPage from './TestPage';
import Area from './Area';
import Calculator from './Calculator';
import RadioSample from './RadioSample';
import RadioSample2 from './RadioSample2';
import FirstProgram from './FirstProgram';
import SecondProgram from './SecondProgram';*/

import { BrowserRouter,Route,Routes } from 'react-router-dom';
import Home from './Homee';
import About from './About';
import Contact from './Contact';
import Login from './Loginn';
import ProductGallery from './ProductGallery';
import ViewCart from './ViewCart';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    
    {/*<TestPage/>*/}
    {/*<Calculator/>
    <Area/>
    <RadioSample/>
    <RadioSample2/>*/}
   {/* <FirstProgram/>
    <SecondProgram/>*/}
    <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Login/>}/>
        <Route exact path='/homee' element={<Home/>}/>

        <Route exact path='/about' element={<About/>}/>
        <Route exact path='/contact' element={<Contact/>}/>
        <Route exact path="/ProductGallery" element={<ProductGallery/>} />
         <Route exact path="/viewcart" element={<ViewCart />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
