import React from "react";
import ReactDOM from "react-dom/client";
import axios from "axios";
import "./index.css";
import reportWebVitals from "./reportWebVitals";
import "bootstrap/dist/css/bootstrap.min.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./Login";
import Registration from "./Registration";

// --- Admin Pages ---
import Dashboard from "./Admin/Dashboard";
import Users from "./Admin/Users";
import Secretaries from "./Admin/Secretaries";
import SecretaryForm from "./Admin/SecretaryForm";
import UserForm from "./Admin/UserForm";
import Issues from "./Admin/Issues";
import Feedback from "./Admin/Feedback";
import IssueLog from "./Admin/IssueLog";
import Notification from "./Admin/Notification";
import Layout from "./Admin/Layout";

// --- Secretary Pages ---
import SecDashboard from "./Secretary/Dashboard";
import SecFeedback from "./Secretary/Feedback";
import SecNotification from "./Secretary/Notification";
import SecUserDetails from "./Secretary/UserDetails";
import SecLayout from "./Secretary/Layout";
import ReportExport from "./Secretary/Report_Export";

// --- User Pages ---
import UserDashboard from "./User/User_dashboard";
import ReportIssue from "./User/ReportIssue";
import UserFeedback from "./User/Feedback";
import UserNotification from "./User/Notification";
import UserLayout from "./User/Layout";
import UserReportExport from "./User/Report_export";

// ✅ Configure axios defaults
axios.defaults.baseURL = "http://localhost:5000";
axios.defaults.withCredentials = true;

// ✅ ProtectedRoute wrapper
const ProtectedRoute = ({ children, role }) => {
  const user = JSON.parse(sessionStorage.getItem("user"));

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (role && user.role !== role) {
    return <Navigate to={`/${user.role}`} replace />;
  }

  return children;
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />

        {/* Admin Routes */}
        <Route
          path="/admin/*"
          element={
            <ProtectedRoute role="admin">
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="users" element={<Users />} />
          <Route path="users/new" element={<UserForm />} />
          <Route path="users/edit/:id" element={<UserForm />} />
          <Route path="secretaries" element={<Secretaries />} />
          <Route path="secretaries/new" element={<SecretaryForm />} />
          <Route path="secretaries/edit/:id" element={<SecretaryForm />} />
          <Route path="issues" element={<Issues />} />
          <Route path="feedback" element={<Feedback />} />
          <Route path="issue-log" element={<IssueLog />} />
          <Route path="notifications" element={<Notification />} />
        </Route>

        {/* Secretary Routes */}
        <Route
          path="/secretary/*"
          element={
            <ProtectedRoute role="secretary">
              <SecLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<SecDashboard />} />
          <Route path="feedback" element={<SecFeedback />} />
          <Route path="notifications" element={<SecNotification />} />
          <Route path="user-details" element={<SecUserDetails />} />
          <Route path="export" element={<ReportExport />} />
        </Route>

        {/* User Routes */}
        <Route
          path="/user/*"
          element={
            <ProtectedRoute role="user">
              <UserLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<UserDashboard />} />
          <Route path="report" element={<ReportIssue />} />
          <Route path="feedback" element={<UserFeedback />} />
          <Route path="notifications" element={<UserNotification />} />
          <Route path="export" element={<UserReportExport />} />
        </Route>

        {/* Default redirect */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);

reportWebVitals();