import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './Homee';
import About from './About';
import Contact from './Contact';
import Login from './Loginn';
import ProductGallery from './ProductGallery';
import ViewCart from './ViewCart';
import SampleJSONAxios from './SampleJSONAxios';
import InsertEmp from './InsertEmp';
import UpdateDemo from './UpdateDemo';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route exact path="/emp" element={<InsertEmp />} />
        <Route exact path="/emp/:id" element={<UpdateDemo />} />
        <Route exact path="/" element={<Login />} />
        <Route exact path="/homee" element={<Home />} />
        <Route exact path="/about" element={<About />} />
        <Route exact path="/contact" element={<Contact />} />
        <Route exact path="/ProductGallery" element={<ProductGallery />} />
        <Route exact path="/viewcart" element={<ViewCart />} />
        <Route exact path="/employee" element={<SampleJSONAxios />} /> 
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);

reportWebVitals();