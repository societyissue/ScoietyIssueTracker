import React from "react";
import  "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
const Calculate = () => {
  const [choice, setChoice] = React.useState('');
  const [num, setNum] = React.useState('');
  const [res, setResult] = React.useState('');

  const rate = 100;

  const calculateAmount = (qty, option) => {
    const total = qty * rate;
    let finalAmount = 0;

    if (option === 'H') {
      finalAmount = total - total * 0.10;
    } else if (option === 'R') {
      finalAmount = total;
    } else if (option === 'F') {
      finalAmount = total + total * 0.20;
    }

    setResult(finalAmount.toFixed(2));
  };

  const handleChoiceChange = (event) => {
    const selected = event.target.value;
    setChoice(selected);
    if (num) {
      calculateAmount(num, selected);
    }
  };

  const handleQuantityChange = (event) => {
    const qty = Number(event.target.value);
    setNum(qty);
    if (choice) {
      calculateAmount(qty, choice);
    }
  };

  return (
    <div className="container mt-5 d-flex justify-content-center">
      <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
        <div className="card-header bg-primary text-white text-center">
          <h4>Amount Calculator</h4>
        </div>
        <div className="card-body bg-light">
          <form>
            <div className="form-floating mb-2">
              <input
                type="text"
                className="form-control form-control-sm"
                id="name"
                placeholder="Your Name"
              />
              <label htmlFor="name">Your Name</label>
            </div>

            <div className="form-floating mb-3">
              <input
                type="number"
                className="form-control form-control-sm"
                id="quantity"
                placeholder="Quantity"
                value={num}
                onChange={handleQuantityChange}
              />
              <label htmlFor="quantity">Quantity</label>
            </div>

            <div className="form-floating mb-3">
              <input
                type="number"
                className="form-control"
                id="rate"
                placeholder="Rate"
                value={rate}
                readOnly
              />
              <label htmlFor="rate">Rate</label>
            </div>

            <p className="fw-bold">Choice</p>

            <div className="form-check mb-2">
              <input
                className="form-check-input"
                type="radio"
                name="option"
                id="happy"
                value="H"
                checked={choice === 'H'}
                onChange={handleChoiceChange}
              />
              <label className="form-check-label" htmlFor="happy">
                Happy Hours (10% Discount)
              </label>
            </div>

            <div className="form-check mb-2">
              <input
                className="form-check-input"
                type="radio"
                name="option"
                id="regular"
                value="R"
                checked={choice === 'R'}
                onChange={handleChoiceChange}
              />
              <label className="form-check-label" htmlFor="regular">
                Regular (No Change)
              </label>
            </div>

            <div className="form-check mb-4">
              <input
                className="form-check-input"
                type="radio"
                name="option"
                id="funtime"
                value="F"
                checked={choice === 'F'}
                onChange={handleChoiceChange}
              />
              <label className="form-check-label" htmlFor="funtime">
                Funtime (20% Increase)
              </label>
            </div>

            <div className="form-floating mb-3">
              <input
                type="text"
                className="form-control"
                id="amount"
                placeholder="Amount"
                value={res}
                readOnly
              />
              <label htmlFor="amount">Amount</label>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Calculate;