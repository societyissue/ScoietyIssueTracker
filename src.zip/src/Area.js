import React, { useState } from 'react';

function App() {
  const [length, setLength] = useState('');
  const [width, setWidth] = useState('');
  const [height, setHeight] = useState('');
  const [area, setArea] = useState(null);
  const [volume, setVolume] = useState(null);

  const calculate = () => {
    const l = parseFloat(length);
    const w = parseFloat(width);
    const h = parseFloat(height);

    if (!isNaN(l) && !isNaN(w) && !isNaN(h)) {
      setArea(l * w);          // Area of rectangle = length × width
      setVolume(l * w * h);    // Volume of box = length × width × height
    } else {
      setArea(null);
      setVolume(null);
    }
  };

  return (
    <div>
      <h2>Area and Volume Calculator</h2>

      <div>
        <label>Length: </label>
        <input
          type="number"
          value={length}
          onChange={(e) => setLength(e.target.value)}
          placeholder="Enter length"
        />
      </div>

      <div>
        <label>Width: </label>
        <input
          type="number"
          value={width}
          onChange={(e) => setWidth(e.target.value)}
          placeholder="Enter width"
        />
      </div>

      <div>
        <label>Height: </label>
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Enter height"
        />
      </div>

      <button onClick={calculate}>Calculate</button>

      {area !== null && volume !== null && (
        <div>
          <p>Area (L × W): {area}</p>
          <p>Volume (L × W × H): {volume}</p>
        </div>
      )}
    </div>
  );
}

export default App;