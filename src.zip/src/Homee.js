import React from 'react';
import { useLocation, Link } from 'react-router-dom';

export default function Home() {
  const location = useLocation();
  const user = location.state?.user || 'Guest';

  return (
    <div className="container mt-4">
      <div className="text-center">
        <h1 className="mb-3">Welcome User</h1>
        <h4><b>{user}</b></h4>

        <div className="mt-4">
          <Link to="/about" className="btn btn-primary mx-2">About</Link>
          
          <Link to="/contact" className="btn btn-success mx-2">Contact Us</Link>
          <Link to="/ProductGallery" className="btn btn-warning mx-2">Show Product</Link>
        </div>
      </div>
    </div>
  );
}