import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const SecretaryIssueStatus = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [issue, setIssue] = useState(null);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const ALLOWED_STATUSES = ["Pending", "In Progress", "Resolved", "Closed"];
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchIssue = async () => {
      try {
        setLoading(true);

        // Fetch all issues for secretary's building
        const res = await axios.get("http://localhost:5000/secretary/dashboard-data", {
          headers: { Authorization: `Bearer ${token}` },
        });

        // Find the specific issue by ID
        const foundIssue = res.data.issues.find(
          (i) => i.issue_id.toString() === id.toString()
        );

        if (!foundIssue) {
          setMessage("Issue not found for your building");
          setIssue(null);
        } else {
          setIssue(foundIssue);
          setStatus(foundIssue.status);
        }
      } catch (err) {
        console.error("Error fetching issue:", err);
        setMessage(err.response?.data?.message || "Failed to fetch issue details");
      } finally {
        setLoading(false);
      }
    };

    fetchIssue();
  }, [id, token]);

  const handleUpdate = async () => {
    try {
      const res = await axios.put(
        `http://localhost:5000/issues/${id}`, // Your API endpoint to update issue
        { status },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setMessage(res.data.message || "Status updated successfully");

      // Update local issue state
      setIssue((prev) => ({ ...prev, status }));

      // Redirect back to issues page after 1 second
      setTimeout(() => navigate("/secretary/issues"), 1000);
    } catch (err) {
      console.error("Failed to update issue:", err);
      setMessage(err.response?.data?.message || "Failed to update issue status");
    }
  };

  const handleCancel = () => navigate("/secretary/issues");

  if (loading)
    return <p className="text-center mt-5">Loading issue details...</p>;

  if (!issue)
    return (
      <p className="text-center mt-5 text-danger">
        {message || "Issue not found"}
      </p>
    );

  return (
    <div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-body">
          <h2 className="card-title h5 mb-4">Update Issue #{issue.issue_id}</h2>

          <p><strong>Title:</strong> {issue.title}</p>
          <p><strong>Status:</strong> {issue.status}</p>
          <p><strong>Reporter:</strong> {issue.reporter_name}</p>
          <p><strong>Category:</strong> {issue.category}</p>
          <p><strong>Description:</strong> {issue.description}</p>
          <p><strong>Reported At:</strong> {new Date(issue.created_at).toLocaleString()}</p>

          <div className="mb-4 mt-3">
            <label className="form-label"><strong>Update Status:</strong></label>
            <select
              className="form-select"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              {ALLOWED_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div className="d-flex gap-3">
            <button onClick={handleUpdate} className="btn btn-primary w-50">
              Update Status
            </button>
            <button onClick={handleCancel} className="btn btn-secondary w-50">
              Cancel
            </button>
          </div>

          {message && (
            <div className="alert alert-info text-center mt-4">{message}</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SecretaryIssueStatus;