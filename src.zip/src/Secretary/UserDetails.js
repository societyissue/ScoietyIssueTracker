// src/Secretary/UserDetails.js
import React, { useEffect, useState } from "react";
import axios from "axios";

const UserDetails = () => {
  const [users, setUsers] = useState([]);
  const [buildingName, setBuildingName] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Fetch users from secretary API
  const fetchUsers = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await axios.get("http://localhost:5000/secretary/users", {
        withCredentials: true,
      });
      setUsers(res.data.users);
      setBuildingName(res.data.buildingName);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Failed to fetch users.");
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDelete = async (userId) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    try {
      await axios.delete(`http://localhost:5000/users/${userId}`, {
        withCredentials: true,
      });
      alert("User deleted successfully");
      fetchUsers(); // refresh users list
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Failed to delete user");
    }
  };

  const handleEdit = (userId) => {
    // Redirect or open edit modal
    window.location.href = `/secretary/users/edit/${userId}`;
  };

  if (loading) return <div>Loading users...</div>;

  return (
    <div className="container mt-4">
      <h2>Users in {buildingName}</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      {users.length === 0 ? (
        <p>No users found in your building.</p>
      ) : (
        <table className="table table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Wing</th>
              <th>House No</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.user_id}>
                <td>{u.user_id}</td>
                <td>{u.uname}</td>
                <td>{u.uemail}</td>
                <td>{u.wing}</td>
                <td>{u.house_no}</td>
                <td>
                  <button
                    className="btn btn-sm btn-primary me-2"
                    onClick={() => handleEdit(u.user_id)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(u.user_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default UserDetails;