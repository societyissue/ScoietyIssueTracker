import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const SecretaryIssues = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchIssues = async () => {
      setLoading(true);
      try {
        const res = await axios.get("http://localhost:5000/secretary/dashboard-data", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setIssues(res.data.issues || []);
      } catch (err) {
        console.error("Failed to fetch issues:", err);
        alert("Failed to fetch issues");
      } finally {
        setLoading(false);
      }
    };

    fetchIssues();
  }, [token]);

  if (loading) return <p className="text-center mt-5">Loading issues...</p>;
  if (!issues.length)
    return <p className="text-center mt-5">No issues found for your building.</p>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Issues in Your Building</h2>
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Reporter</th>
              <th>Status</th>
              <th>Category</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {issues.map((issue) => (
              <tr key={issue.issue_id}>
                <td>{issue.issue_id}</td>
                <td>{issue.title}</td>
                <td>{issue.reporter_name}</td>
                <td>{issue.status}</td>
                <td>{issue.category}</td>
                <td>
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => navigate(`/secretary/issues/${issue.issue_id}`)}
                  >
                    Update Status
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SecretaryIssues;