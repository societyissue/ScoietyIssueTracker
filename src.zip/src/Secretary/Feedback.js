import React, { useEffect, useState } from "react";
import axios from "axios";

const Feedback = () => {
  const [feedbacks, setFeedbacks] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/secretary/feedback", { withCredentials: true })
      .then(res => setFeedbacks(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container mt-4">
      <h2>User Feedback</h2>
      <ul className="list-group">
        {feedbacks.map((fb, i) => (
          <li key={i} className="list-group-item">
            <strong>{fb.user_name}</strong>: {fb.message}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Feedback;
