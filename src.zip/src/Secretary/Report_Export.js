import React from "react";
import axios from "axios";

const ReportExport = () => {
  const handleExport = () => {
    axios.get("http://localhost:5000/secretary/export", {
      responseType: "blob",
      withCredentials: true
    }).then(res => {
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "secretary_report.xlsx");
      document.body.appendChild(link);
      link.click();
    });
  };

  return (
    <div className="container mt-4">
      <h2>Export Reports</h2>
      <button className="btn btn-success" onClick={handleExport}>Download Excel</button>
    </div>
  );
};

export default ReportExport;