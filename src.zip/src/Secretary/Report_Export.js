import React, { useEffect, useState } from "react";
import axios from "axios";

const SecretaryReports = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("All");

  const fetchIssues = async () => {
    try {
      setLoading(true);
      const res = await axios.get("/issues", { withCredentials: true });
      setIssues(res.data); // server filters issues by secretary's building
      setLoading(false);
    } catch (err) {
      console.error("Error fetching issues:", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIssues();
  }, []);

  const filteredIssues = issues.filter((i) =>
    filterStatus === "All" ? true : i.status === filterStatus
  );

  const exportCSV = async () => {
    try {
      const res = await axios.get("/export/issues", {
        withCredentials: true,
        responseType: "blob",
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `issues_report_secretary.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error("Export error:", err);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Secretary Reports & Export</h2>
      <p className="text-muted">View and export issues for your building</p>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <label>Status Filter: </label>
          <select
            className="form-select d-inline-block w-auto ms-2"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option>All</option>
            <option>Pending</option>
            <option>In Progress</option>
            <option>Resolved</option>
          </select>
        </div>
        <button className="btn btn-success" onClick={exportCSV}>
          Export CSV
        </button>
      </div>

      {loading ? (
        <p>Loading issues...</p>
      ) : (
        <table className="table table-striped table-bordered">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Description</th>
              <th>Status</th>
              <th>Category</th>
              <th>Building</th>
              <th>Reporter</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            {filteredIssues.length > 0 ? (
              filteredIssues.map((issue) => (
                <tr key={issue.issue_id}>
                  <td>{issue.issue_id}</td>
                  <td>{issue.title}</td>
                  <td>{issue.description}</td>
                  <td>{issue.status}</td>
                  <td>{issue.category}</td>
                  <td>{issue.building_name}</td>
                  <td>{issue.reporter_name}</td>
                  <td>{new Date(issue.created_at).toLocaleString()}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8" className="text-center text-muted">
                  No issues found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default SecretaryReports;