import React, { useEffect, useState } from "react";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import {
  FaTachometerAlt,
  FaUsers,
  FaComments,
  FaFileAlt,
  FaSignOutAlt,
  FaUserCircle,
} from "react-icons/fa";

const SecretaryLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState({ name: "Secretary", avatar: null });

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser({
        name: storedUser.name || "Secretary",
        avatar: storedUser.avatar || null,
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  };

  const isActive = (path) => {
    if (path === "/secretary") return location.pathname === "/secretary";
    return location.pathname.startsWith(path);
  };

  const links = [
    { path: "/secretary/profile", label: "Profile", icon: <FaUserCircle /> },
    { path: "/secretary", label: "Dashboard", icon: <FaTachometerAlt /> },
    { path: "/secretary/users", label: "User Details", icon: <FaUsers /> },
    { path: "/secretary/issues", label: "Issues ", icon: <FaUsers /> },
    { path: "/secretary/feedback", label: "Feedback", icon: <FaComments /> },
    { path: "/secretary/reports", label: "Reports", icon: <FaFileAlt /> },
  ];

  return (
    <div className="container-fluid p-0">
      <div className="row g-0">
        {/* Sidebar */}
        <aside className="col-md-2 vh-100 bg-dark text-white d-flex flex-column p-0">
          {/* Profile Section */}
          <div
            className="text-center p-4 border-bottom"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?fit=crop&w=600&q=80')",
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          >
            {user.avatar ? (
              <img
                src={user.avatar}
                alt="Avatar"
                className="rounded-circle mb-2 border border-white"
                style={{ width: "80px", height: "80px", objectFit: "cover" }}
              />
            ) : (
              <FaUserCircle size={80} className="mb-2 text-white" />
            )}
            <h6 className="mb-0 text-white">{user.name}</h6>
          </div>

          {/* Nav Links */}
          <nav className="nav flex-column mt-3 flex-grow-1">
            {links.map((item) =>
              item.path === "/logout" ? null : (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`nav-link d-flex align-items-center py-3 px-4 ${
                    isActive(item.path) ? "bg-primary text-white" : "text-light"
                  }`}
                  style={{ transition: "0.3s" }}
                  onMouseEnter={(e) => {
                    if (!isActive(item.path))
                      e.currentTarget.style.backgroundColor = "#343a40";
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive(item.path))
                      e.currentTarget.style.backgroundColor = "transparent";
                  }}
                >
                  {item.icon} <span className="ms-2">{item.label}</span>
                </Link>
              )
            )}

            {/* Spacer */}
            <div className="mt-auto p-3">
              <button
                className="btn btn-danger w-100 d-flex align-items-center justify-content-center"
                onClick={handleLogout}
              >
                <FaSignOutAlt className="me-2" /> Logout
              </button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="col-md-10 bg-light p-4 min-vh-100">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default SecretaryLayout;