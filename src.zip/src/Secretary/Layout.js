import React from "react";
import { Link, Outlet, useNavigate, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const SecretaryLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const secretary = JSON.parse(localStorage.getItem("secretary"));

  const handleLogout = () => {
    localStorage.removeItem("secretary");
    navigate("/login");
  };

  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <div className="d-flex" style={{ minHeight: "100vh" }}>
      <aside className="bg-primary text-white d-flex flex-column p-3" style={{ width: "250px" }}>
        <div className="text-center mb-4 border-bottom pb-3">
          <i className="fas fa-user-tie fa-4x mb-2"></i>
          <h5 className="mb-0">{secretary?.name || "Secretary"}</h5>
        </div>

        <nav className="flex-grow-1">
          <ul className="nav flex-column">
            <li className="nav-item mb-2">
              <Link
                className={`nav-link ${isActive("/secretary") ? "active text-warning" : "text-white"}`}
                to="/secretary"
              >
                <i className="fas fa-home me-2"></i> Dashboard
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className={`nav-link ${isActive("/secretary/user-details") ? "active text-warning" : "text-white"}`}
                to="/secretary/user-details"
              >
                <i className="fas fa-users me-2"></i> User Details
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className={`nav-link ${isActive("/secretary/feedback") ? "active text-warning" : "text-white"}`}
                to="/secretary/feedback"
              >
                <i className="fas fa-comments me-2"></i> Feedback
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className={`nav-link ${isActive("/secretary/notifications") ? "active text-warning" : "text-white"}`}
                to="/secretary/notifications"
              >
                <i className="fas fa-bell me-2"></i> Notifications
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className={`nav-link ${isActive("/secretary/export") ? "active text-warning" : "text-white"}`}
                to="/secretary/export"
              >
                <i className="fas fa-file-export me-2"></i> Reports / Export
              </Link>
            </li>
          </ul>
        </nav>
      </aside>

      <main className="flex-grow-1 d-flex flex-column">
        <header className="navbar navbar-light bg-light shadow-sm px-3 d-flex justify-content-between align-items-center">
          <div className="d-flex align-items-center">
            <span className="navbar-brand mb-0 h5 me-3">Secretary Panel</span>
            <span className="fw-bold text-dark">{secretary?.name || "Secretary"}</span>
          </div>
          <button className="btn btn-outline-danger btn-sm" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt me-1"></i> Logout
          </button>
        </header>

        <section className="flex-grow-1 p-4 bg-light">
          <Outlet />
        </section>
      </main>
    </div>
  );
};

export default SecretaryLayout;