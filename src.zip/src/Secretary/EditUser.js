// src/Secretary/EditUser.js
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const EditUser = () => {
  const { id } = useParams(); // user ID from URL
  const navigate = useNavigate();

  const [user, setUser] = useState({
    uname: "",
    uemail: "",
    upassword: "",
    wing: "",
    house_no: "",
    building_name: "",
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Fetch user details
  const fetchUser = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`http://localhost:5000/users/${id}`, {
        withCredentials: true,
      });
      setUser(res.data);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Failed to fetch user");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, [id]);

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/users/${id}`, user, {
        withCredentials: true,
      });
      alert("User updated successfully");
      navigate("/secretary/users"); // redirect back to users list
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Failed to update user");
    }
  };

  if (loading) return <div>Loading user details...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <h2>Edit User</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            name="uname"
            className="form-control"
            value={user.uname}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="uemail"
            className="form-control"
            value={user.uemail}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            type="password"
            name="upassword"
            className="form-control"
            value={user.upassword}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Wing</label>
          <input
            type="text"
            name="wing"
            className="form-control"
            value={user.wing}
            onChange={handleChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">House No</label>
          <input
            type="text"
            name="house_no"
            className="form-control"
            value={user.house_no}
            onChange={handleChange}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Building Name</label>
          <input
            type="text"
            name="building_name"
            className="form-control"
            value={user.building_name}
            onChange={handleChange}
            disabled // secretary cannot change building
          />
        </div>
        <button type="submit" className="btn btn-success me-2">
          Update
        </button>
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate("/secretary/users")}
        >
          Cancel
        </button>
      </form>
    </div>
  );
};

export default EditUser;