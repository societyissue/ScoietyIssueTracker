import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [issues, setIssues] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/secretary/issues", { withCredentials: true })
      .then(res => setIssues(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container mt-4">
      <h2>Secretary Dashboard</h2>
      <p>Issues reported by your assigned users</p>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>User</th>
            <th>Building</th>
            <th>Description</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {issues.map(issue => (
            <tr key={issue.issue_id}>
              <td>{issue.issue_id}</td>
              <td>{issue.user_name}</td>
              <td>{issue.building_name}</td>
              <td>{issue.description}</td>
              <td>{issue.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Dashboard;