import React, { useEffect, useState } from "react";
import axios from "axios";

const SecretaryDashboard = () => {
  const [dashboard, setDashboard] = useState({
    buildingName: "",
    stats: { total: 0, pending: 0, inProgress: 0, resolved: 0 },
    issues: [],
  });
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token"); // JWT stored in localStorage

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await axios.get("http://localhost:5000/secretary/dashboard-data", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setDashboard(res.data);
      } catch (err) {
        console.error(err);
        alert("Failed to fetch dashboard data");
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();
  }, [token]);

  if (loading) return <p className="text-center mt-5">Loading...</p>;

  const { buildingName, stats, issues } = dashboard;

  return (
    <div className="container mt-4">
      <h1 className="mb-3">Secretary Dashboard</h1>
      <h4 className="mb-4">Building: {buildingName}</h4>

      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-primary text-white">
            <div className="card-body">
              <h5 className="card-title">Total Issues</h5>
              <p className="card-text display-6">{stats.total}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-warning text-dark">
            <div className="card-body">
              <h5 className="card-title">Pending</h5>
              <p className="card-text display-6">{stats.pending}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-orange text-white" style={{ backgroundColor: "#fd7e14" }}>
            <div className="card-body">
              <h5 className="card-title">In Progress</h5>
              <p className="card-text display-6">{stats.inProgress}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card text-center bg-success text-white">
            <div className="card-body">
              <h5 className="card-title">Resolved</h5>
              <p className="card-text display-6">{stats.resolved}</p>
            </div>
          </div>
        </div>
      </div>

      <h4 className="mb-3">Recent Issues</h4>
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead className="table-light">
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Reporter</th>
              <th>Status</th>
              <th>Category</th>
            </tr>
          </thead>
          <tbody>
            {issues.length === 0 ? (
              <tr>
                <td colSpan="5" className="text-center">
                  No issues reported
                </td>
              </tr>
            ) : (
              issues.map((issue) => (
                <tr key={issue.issue_id}>
                  <td>{issue.issue_id}</td>
                  <td>{issue.title}</td>
                  <td>{issue.reporter_name}</td>
                  <td>{issue.status}</td>
                  <td>{issue.category}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SecretaryDashboard;