// SecretaryDashboard.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faClipboardList,
  faHourglassHalf,
  faSpinner,
  faCheckCircle,
} from "@fortawesome/free-solid-svg-icons";

const SecretaryDashboard = () => {
  const [buildingName, setBuildingName] = useState("");
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
  });
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        const res = await axios.get(
          "http://localhost:5000/secretary/dashboard-data",
          { withCredentials: true }
        );

        setBuildingName(res.data.buildingName);
        setStats(res.data.stats);
        setIssues(res.data.issues);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching dashboard data:", err);
        setError("Failed to load dashboard data.");
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) return <p>Loading dashboard...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <div className="container p-4">
      <h2 className="mb-4">
        Secretary Dashboard <small className="text-muted">- {buildingName}</small>
      </h2>

      {/* Issue counts with icons */}
      <div className="row text-center mb-4">
        <div className="col-md-3 mb-3">
          <div className="card shadow-sm border-primary h-100">
            <div className="card-body">
              <FontAwesomeIcon icon={faClipboardList} size="2x" className="text-primary mb-2" />
              <h5 className="card-title">Total Issues</h5>
              <p className="card-text display-6">{stats.total}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card shadow-sm border-warning h-100">
            <div className="card-body">
              <FontAwesomeIcon icon={faHourglassHalf} size="2x" className="text-warning mb-2" />
              <h5 className="card-title">Pending</h5>
              <p className="card-text display-6">{stats.pending}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card shadow-sm border-info h-100">
            <div className="card-body">
              <FontAwesomeIcon icon={faSpinner} size="2x" className="text-info mb-2" />
              <h5 className="card-title">In Progress</h5>
              <p className="card-text display-6">{stats.inProgress}</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card shadow-sm border-success h-100">
            <div className="card-body">
              <FontAwesomeIcon icon={faCheckCircle} size="2x" className="text-success mb-2" />
              <h5 className="card-title">Resolved</h5>
              <p className="card-text display-6">{stats.resolved}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Issues table */}
      <div className="table-responsive">
        <table className="table table-striped table-hover table-bordered">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Reporter</th>
              <th>Status</th>
              <th>Category</th>
              <th>Description</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            {issues.length > 0 ? (
              issues.map((issue) => (
                <tr key={issue.issue_id}>
                  <td>{issue.issue_id}</td>
                  <td>{issue.title}</td>
                  <td>
                    {issue.reporter_name}{" "}
                    <span className="text-muted">({issue.reporter_type})</span>
                  </td>
                  <td>{issue.status}</td>
                  <td>{issue.category}</td>
                  <td>{issue.description}</td>
                  <td>{new Date(issue.created_at).toLocaleString()}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="text-center">
                  No issues found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SecretaryDashboard;