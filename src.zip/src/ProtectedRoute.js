import React from "react";
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ allowedRole, children }) => {
  const storedUser = localStorage.getItem("user");
  const user = storedUser ? JSON.parse(storedUser) : null;

  // If not logged in → send to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If role does not match → block access
  if (user.role !== allowedRole) {
    return <Navigate to="/login" replace />;
  }

  // Otherwise → allow access
  return children;
};

export default ProtectedRoute;