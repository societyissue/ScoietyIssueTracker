import React from "react";
import Login from "./Login";

function App() {
  return (
    <div className="bg-light min-vh-100 d-flex align-items-center">
      <Login />
    </div>
  );
}

export default App;