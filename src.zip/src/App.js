import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./Login";
import Registration from "./Registration";
import ProtectedRoute from "./ProtectedRoute";

/* ===== Admin Pages ===== */
import AdminLayout from "./Admin/Layout";
import AdminDashboard from "./Admin/Dashboard";
import AdminUsers from "./Admin/Users";
import AddUser from "./Admin/AddUser";
import EditUser from "./Admin/EditUser";
import AdminSecretaries from "./Admin/Secretaries";
import AddSecretary from "./Admin/AddSecretary";
import EditSecretary from "./Admin/EditSecretary";
import AdminIssues from "./Admin/Issues";
import AdminIssueLog from "./Admin/IssueLog";
import AdminFeedback from "./Admin/Feedback";
import AdminNotification from "./Admin/Notification";
import AdminReportExport from "./Admin/Report&Export";
import AdminProfile from "./Admin/Profile";

/* ===== Secretary Pages ===== */
import SecretaryLayout from "./Secretary/Layout";
import SecretaryDashboard from "./Secretary/Dashboard";
import SecretaryUserDetails from "./Secretary/UserDetails";
import AddUserSecretary from "./Secretary/AddUser";
import EditUserSecretary from "./Secretary/EditUser";
import SecretaryFeedback from "./Secretary/Feedback";
import SecretaryNotification from "./Secretary/Notification";
import SecretaryReportExport from "./Secretary/Report_Export";
import SecretaryProfile from "./Secretary/Profile";
import SecretaryIssueStatus from "./Secretary/IssueStatus";

/* ===== User Pages ===== */
import UserLayout from "./User/Layout";
import UserDashboard from "./User/User_dashboard";
import UserReportIssue from "./User/ReportIssue";
import UserFeedback from "./User/Feedback";
import UserNotification from "./User/Notification";
import UserReportExport from "./User/Report_export";
import UserProfile from "./User/Profile";

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />

        {/* Admin Routes */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute role="admin">
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<AdminDashboard />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="users/add" element={<AddUser />} />
          <Route path="users/edit/:id" element={<EditUser />} />
          <Route path="secretaries" element={<AdminSecretaries />} />
          <Route path="secretaries/add" element={<AddSecretary />} />
          <Route path="secretaries/edit/:id" element={<EditSecretary />} />
          <Route path="issues" element={<AdminIssues />} />
          <Route path="issue-log" element={<AdminIssueLog />} />
          <Route path="feedback" element={<AdminFeedback />} />
          <Route path="notifications" element={<AdminNotification />} />
          <Route path="reports" element={<AdminReportExport />} />
          <Route path="profile" element={<AdminProfile />} />
        </Route>

        {/* Secretary Routes */}
        <Route
          path="/secretary"
          element={
            <ProtectedRoute role="secretary">
              <SecretaryLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<SecretaryDashboard />} />
          <Route path="users" element={<SecretaryUserDetails />} />
          <Route path="users/add" element={<AddUserSecretary />} />
          <Route path="users/edit/:id" element={<EditUserSecretary />} />
          <Route path="issues" element={<SecretaryIssueStatus />} />
          <Route path="feedback" element={<SecretaryFeedback />} />
          <Route path="notifications" element={<SecretaryNotification />} />
          <Route path="reports" element={<SecretaryReportExport />} />
          <Route path="issues/update/:id" element={<SecretaryIssueStatus />} />
          <Route path="profile" element={<SecretaryProfile />} />
        </Route>

        {/* User Routes */}
        <Route
          path="/user"
          element={
            <ProtectedRoute role="user">
              <UserLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<UserDashboard />} />
          <Route path="report-issue" element={<UserReportIssue />} />
          <Route path="feedback" element={<UserFeedback />} />
          <Route path="notifications" element={<UserNotification />} />
          <Route path="reports" element={<UserReportExport />} />
          <Route path="profile" element={<UserProfile />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;