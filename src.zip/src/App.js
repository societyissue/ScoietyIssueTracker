import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./Login";
import Registration from "./Registration";

// Admin
import Layout from "./Admin/Layout";
import Dashboard from "./Admin/Dashboard";
import Users from "./Admin/Users";
import Secretaries from "./Admin/Secretaries";
import SecretaryForm from "./Admin/SecretaryForm";
import UserForm from "./Admin/UserForm";
import Issues from "./Admin/Issues";
import Feedback from "./Admin/Feedback";
import IssueLog from "./Admin/IssueLog";
import Notification from "./Admin/Notification";

// Secretary
import SecLayout from "./Secretary/Layout";
import SecretaryDashboard from "./Secretary/Dashboard";
import SecFeedback from "./Secretary/Feedback";
import SecNotification from "./Secretary/Notification";
import SecUserDetails from "./Secretary/UserDetails";
import ReportExport from "./Secretary/Report_Export";

// User
import UserLayout from "./User/Layout";
import UserDashboard from "./User/User_dashboard";
import ReportIssue from "./User/ReportIssue";
import UserFeedback from "./User/Feedback";
import UserNotification from "./User/Notification";
import UserReportExport from "./User/Report_export";

import ProtectedRoute from "./ProtectedRoute";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />

        {/* Admin */}
        <Route
          path="/admin/*"
          element={
            <ProtectedRoute allowedRole="admin">
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="users" element={<Users />} />
          <Route path="users/new" element={<UserForm />} />
          <Route path="users/edit/:id" element={<UserForm />} />
          <Route path="secretaries" element={<Secretaries />} />
          <Route path="secretaries/new" element={<SecretaryForm />} />
          <Route path="secretaries/edit/:id" element={<SecretaryForm />} />
          <Route path="issues" element={<Issues />} />
          <Route path="feedback" element={<Feedback />} />
          <Route path="issue-log" element={<IssueLog />} />
          <Route path="notifications" element={<Notification />} />
        </Route>

        {/* Secretary */}
        <Route
          path="/secretary/*"
          element={
            <ProtectedRoute allowedRole="secretary">
              <SecLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<SecretaryDashboard />} />
          <Route path="dashboard" element={<SecretaryDashboard />} />
          <Route path="feedback" element={<SecFeedback />} />
          <Route path="notifications" element={<SecNotification />} />
          <Route path="user-details" element={<SecUserDetails />} />
          <Route path="report" element={<ReportExport />} />
        </Route>

        {/* User */}
        <Route
          path="/user/*"
          element={
            <ProtectedRoute allowedRole="user">
              <UserLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<UserDashboard />} />
          <Route path="dashboard" element={<UserDashboard />} />
          <Route path="issues" element={<ReportIssue />} />
          <Route path="feedback" element={<UserFeedback />} />
          <Route path="notifications" element={<UserNotification />} />
          <Route path="report" element={<UserReportExport />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;