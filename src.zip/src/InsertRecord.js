import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [formData, setFormData] = useState({ Emp_no: '', Ename: '', Salary: '' });
  const [employees, setEmployees] = useState([]);
  const [editMode, setEditMode] = useState(false);

  // Load all employees
  const fetchEmployees = async () => {
    try {
      const response = await axios.get('http://localhost:8000/employee');
      setEmployees(response.data);
    } catch (error) {
      console.error('Fetch Error:', error.message);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await axios.put(`http://localhost:8000/employee/${formData.Emp_no}`, formData);
        alert('Employee updated successfully');
      } else {
        await axios.post('http://localhost:8000/employee', formData);
        alert('Employee inserted successfully');
      }
      setFormData({ Emp_no: '', Ename: '', Salary: '' });
      setEditMode(false);
      fetchEmployees();
    } catch (error) {
      console.error(error);
      alert('Error submitting form: ' + error.message);
    }
  };

  const handleEdit = (emp) => {
    setFormData(emp);
    setEditMode(true);
  };

  const handleDelete = async (Emp_no) => {
    if (!window.confirm('Are you sure you want to delete this employee?')) return;

    try {
      await axios.delete(`http://localhost:8000/employee/${Emp_no}`);
      alert('Employee deleted successfully');
      fetchEmployees();
    } catch (error) {
      console.error(error);
      alert('Delete failed: ' + error.message);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>{editMode ? 'Update Employee' : 'Insert Employee'}</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Emp No:</label><br />
          <input
            type="text"
            name="Emp_no"
            value={formData.Emp_no}
            onChange={handleChange}
            required
            disabled={editMode}
          />
        </div>
        <div>
          <label>Ename:</label><br />
          <input
            type="text"
            name="Ename"
            value={formData.Ename}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Salary:</label><br />
          <input
            type="number"
            name="Salary"
            value={formData.Salary}
            onChange={handleChange}
            required
          />
        </div>
        <br />
        <button type="submit">{editMode ? 'Update' : 'Insert'}</button>
      </form>

      <hr />

      <h2>Employee List</h2>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Emp No</th>
            <th>Name</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map(emp => (
            <tr key={emp.Emp_no}>
              <td>{emp.Emp_no}</td>
              <td>{emp.Ename}</td>
              <td>{emp.Salary}</td>
              <td>
                <button onClick={() => handleEdit(emp)}>Edit</button>{' '}
                <button onClick={() => handleDelete(emp.Emp_no)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;
