import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const EmployeeForm = () => {
  const [formData, setFormData] = useState({ Emp_no: '', Ename: '', Salary: '' });
  const navigate = useNavigate();
  const { Emp_no } = useParams(); // ✅ get from route param
  const editMode = Boolean(Emp_no);

  useEffect(() => {
    if (editMode) {
      axios.get(`http://localhost:8000/employee/${Emp_no}`)
        .then(res => {
          console.log('Fetched data:', res.data);
          setFormData(res.data);
        })
        .catch(err => {
          console.error('❌ Error fetching employee details:', err);
          alert('Failed to fetch employee');
        });
    }
  }, [Emp_no, editMode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (editMode) {
      axios.put(`http://localhost:8000/employee/${Emp_no}`, formData)
        .then(() => {
          alert('✅ Employee updated successfully');
          navigate('/');
        })
        .catch(err => {
          console.error('❌ Update error:', err);
          alert('Failed to update');
        });
    } else {
      axios.post('http://localhost:8000/employee', formData)
        .then(() => {
          alert('✅ Employee inserted successfully');
          navigate('/');
        })
        .catch(err => {
          console.error('❌ Insert error:', err);
          alert('Failed to insert');
        });
    }
  };

  return (
    <div className="container mt-4">
      <h2>{editMode ? 'Edit Employee' : 'Add Employee'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          
          <input
            type="hidden"
            name="Emp_no"
            value={formData.Emp_no}
            onChange={handleChange}
            className="form-control"
            required
            disabled={editMode}
          />
        </div>
        <div className="mb-3">
          <label>Name</label>
          <input
            type="text"
            name="Ename"
            value={formData.Ename}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label>Salary</label>
          <input
            type="number"
            name="Salary"
            value={formData.Salary}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <button type="submit" className="btn btn-success">
          {editMode ? 'Update' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default EmployeeForm;