import React ,{useState} from 'react';
const TestPage = () => {
    const [user,setUser] = useState('Guest1');
    const [pass,setPassword] = useState('');

    const handleChange = event => setUser(event.target.value);
    const handleChange2 = event => setPassword(event.target.value);

    const check=()=>{
        if(user === 'react' && pass==='easy')
            alert('Welcome ....'+ user);
        else
            alert('sorry');
    }
    return (
        <div>
            <form>
                <input type="text" id="username" placeholder='Enter your username' value={user} onChange={handleChange}/>
                <input type='passowrd' id='pass' placeholder='' value={pass} onChange={handleChange2}/>
                <button type='submit' className='btn-btn-primary' onClick={check}>Submit</button>
            </form>
        </div>
    );
};

export default TestPage;
