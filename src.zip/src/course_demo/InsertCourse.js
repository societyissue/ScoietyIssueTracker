import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const CourseForm = () => {
  const [formData, setFormData] = useState({
    courseId: '',
    courseName: '',
    credits: '',
    department: ''
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const { courseId } = useParams();
  const editMode = Boolean(courseId);

  useEffect(() => {
    if (editMode) {
      axios
        .get(`http://localhost:5000/api/update/${courseId}`)
        .then((res) => {
          console.log('API response:', res.data); 
          const data = res.data;

          
          setFormData({
            courseId: data.courseId ? String(data.courseId) : '',
            courseName: data.courseName ? String(data.courseName) : '',
            credits: data.credits ? String(data.credits) : '',
            department: data.department ? String(data.department) : ''
          });
        })
        .catch((err) => {
          console.error('Error fetching course details', err);
          alert('Failed to fetch course details');
        });
    }
  }, [courseId, editMode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validate = () => {
    console.log('Validating formData:', formData); 

    const newErrors = {};
    if (!String(formData.courseId).trim() && !editMode) {
      newErrors.courseId = 'Course ID is required';
    }
    if (!String(formData.courseName).trim()) {
      newErrors.courseName = 'Course Name is required';
    }
    if (!String(formData.credits).trim()) {
      newErrors.credits = 'Credits are required';
    }
    if (!String(formData.department).trim()) {
      newErrors.department = 'Department is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    const payload = {
      ...formData,
      credits: Number(formData.credits)
    };

    const apiCall = editMode
      ? axios.put(`http://localhost:5000/api/update/${courseId}`, payload)
      : axios.post('http://localhost:5000/api/addcourse', payload);

    apiCall
      .then(() => {
        alert(editMode ? 'Course updated successfully' : 'Course inserted successfully');
        navigate('/');
      })
      .catch((err) => {
        console.error(editMode ? 'Update error:' : 'Insert error:', err);
        alert('Operation failed');
      });
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">{editMode ? 'Edit Course' : 'Add Course'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Course ID:</label>
          <input
            type="text"
            className={`form-control ${errors.courseId ? 'is-invalid' : ''}`}
            name="courseId"
            placeholder="Enter Course ID"
            value={formData.courseId}
            onChange={handleChange}
            disabled={editMode}
          />
          {errors.courseId && <div className="invalid-feedback">{errors.courseId}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Course Name:</label>
          <input
            type="text"
            className={`form-control ${errors.courseName ? 'is-invalid' : ''}`}
            name="courseName"
            placeholder="Enter Course Name"
            value={formData.courseName}
            onChange={handleChange}
          />
          {errors.courseName && <div className="invalid-feedback">{errors.courseName}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Course Credits:</label>
          <input
            type="number"
            className={`form-control ${errors.credits ? 'is-invalid' : ''}`}
            name="credits"
            placeholder="Enter Credits"
            value={formData.credits}
            onChange={handleChange}
          />
          {errors.credits && <div className="invalid-feedback">{errors.credits}</div>}
        </div>

        <div className="mb-3">
          <label className="form-label">Department:</label>
          <input
            type="text"
            className={`form-control ${errors.department ? 'is-invalid' : ''}`}
            name="department"
            placeholder="Enter Department"
            value={formData.department}
            onChange={handleChange}
          />
          {errors.department && <div className="invalid-feedback">{errors.department}</div>}
        </div>

        <button type="submit" className="btn btn-success">
          {editMode ? 'Update Course' : 'Add Course'}
        </button>
      </form>
    </div>
  );
};

export default CourseForm;