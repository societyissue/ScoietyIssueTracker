import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/viewcourse');
      setCourses(response.data);
    } catch (error) {
      console.error('Fetch Error:', error.message);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  const handleDelete = async (courseId) => {
    if (!window.confirm('Are you sure you want to delete this course?')) return;
    try {
      await axios.delete(`http://localhost:5000/api/delete/${courseId}`);
      alert('Deleted Successfully');
      fetchCourses();
    } catch (error) {
      console.error(error);
      alert('Delete failed: ' + error.message);
    }
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    if (value.trim() === '') {
      setError('Search field cannot be empty');
    } else {
      setError('');
    }
  };

  const uniqueDepartments = [...new Set(courses.map((c) => c.department))];

  const filteredCourses = courses.filter((course) => {
    const matchesName = course.courseName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === '' || course.department === selectedDept;
    return matchesName && matchesDept;
  });

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Course List</h2>

      <div className="row mb-4">
        <div className="col-md-5">
          <input
            type="text"
            className="form-control"
            placeholder="Search by Course Name"
            value={searchTerm}
            onChange={handleSearchChange}
          />
          {error && <small className="text-danger">{error}</small>}
        </div>

        <div className="col-md-4">
          <select
            className="form-select"
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
          >
            <option value="">All Departments</option>
            {uniqueDepartments.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
        </div>

        <div className="col-md-3">
          <button className="btn btn-primary w-100" onClick={() => navigate('/course-form')}>
            Add Course
          </button>
        </div>
      </div>

      <table className="table table-bordered table-hover">
        <thead className="table-light">
          <tr>
            <th>Course ID</th>
            <th>Course Name</th>
            <th>Credits</th>
            <th>Department</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredCourses.length > 0 ? (
            filteredCourses.map((course) => (
              <tr key={course.courseId}>
                <td>{course.courseId}</td>
                <td>{course.courseName}</td>
                <td>{course.credits}</td>
                <td>{course.department}</td>
                <td>
                  <button
                    className="btn btn-sm btn-warning me-2"
                    onClick={() => navigate(`/course-form/${course.courseId}`)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(course.courseId)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center text-muted">
                No matching courses found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default CourseList;