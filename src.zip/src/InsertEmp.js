import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const InsertDemo = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [id, setUpdateId] = useState(""); // for navigation

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = { name, age };

    try {
      const response = await axios.post("http://localhost:8000/emp", data);
      if (response.status === 200 || response.status === 201) {
        alert("Record inserted successfully");
        setName("");
        setAge("");
      }
    } catch (err) {
      alert("Error: " + (err.response?.data?.message || err.message));
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Insert Record</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name:</label>
          <input
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Age:</label>
          <input
            type="number"
            className="form-control"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary me-2">
          Insert
        </button>

        <input
          type="text"
          placeholder="Enter ID to update"
          className="form-control mt-3"
          value={id}
          onChange={(e) => setUpdateId(e.target.value)}
        />
        <button
          type="button"
          className="btn btn-warning mt-2"
          onClick={() => {
            if (id.trim()) {
              navigate(`/emp/${id}`);
            } else {
              alert("Please enter a valid ID to update");
            }
          }}
        >
          Go to Update Page
        </button>
      </form>
    </div>
  );
};

export default InsertDemo;