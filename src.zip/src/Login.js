import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
export default function Login () {
    const navigate = useNavigate();
    const [data, setData] = useState({
        uname:"",
        pwd: "",
         });
    
      // Handle the onchange event for each textbox
      const handleChange = (event) => {
        const { name, value } = event.target;
        setData((values) => ({
          ...values,
          [name]: value
        }));
      //  alert(data.No1);
      };

      const check=() =>
   {
       
        var x=data["uname"];
        var y=data["pwd"];
    if (x==="manav" && y==="123")
        //navigate("/home");
    //{state:{id:1,name:'zzz'}}
    navigate("homee/", { state: { user: x }} );
    else
        alert("sorry");
    };

    return (
        <div>
            <form>

<br/>
<br/>
<br/>
           
      <label for="uname" >UserName:</label>
      <input type="text"  id="uname" placeholder="Enter UserName" name="uname" value={data.uname}  onChange={handleChange} />
  <br/>
      <label for="pwd" >Password:</label>
      <input type="text" id="pwd" placeholder="Enter Password" name="pwd" value={data.pwd} onChange={handleChange}/>
       <br/>
       <button type="button" className="btn btn-primary" name='b1'  onClick={check}>Submit</button>
            </form>
        </div>
    );
};