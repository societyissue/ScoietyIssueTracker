import React, { useState } from "react";
import axios from "axios";

const Registration = () => {
  const [form, setForm] = useState({
    uname: "",
    uemail: "",
    upassword: "",
    building_name: "",
    wing: "",
    house_no: "",
  });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/users", form, { withCredentials: true });
      alert("User registered successfully!");
      setForm({ uname: "", uemail: "", upassword: "", building_name: "", wing: "", house_no: "" });
    } catch {
      alert("Registration failed");
    }
  };

  return (
    <div className="container mt-5 col-md-6">
      <h3 className="mb-3">Register User</h3>
      <form onSubmit={handleSubmit}>
        <input name="uname" placeholder="Name" value={form.uname} onChange={handleChange} className="form-control mb-2" />
        <input name="uemail" placeholder="Email" value={form.uemail} onChange={handleChange} className="form-control mb-2" />
        <input name="upassword" placeholder="Password" type="password" value={form.upassword} onChange={handleChange} className="form-control mb-2" />
        <input name="building_name" placeholder="Building" value={form.building_name} onChange={handleChange} className="form-control mb-2" />
        <input name="wing" placeholder="Wing" value={form.wing} onChange={handleChange} className="form-control mb-2" />
        <input name="house_no" placeholder="House No" value={form.house_no} onChange={handleChange} className="form-control mb-2" />
        <button className="btn btn-success w-100">Register</button>
      </form>
    </div>
  );
};

export default Registration;