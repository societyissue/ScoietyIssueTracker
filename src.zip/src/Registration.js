import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Register.css";

const Registration = () => {
  const [role, setRole] = useState("user");
  const [formData, setFormData] = useState({
    uname: "",
    uemail: "",
    upassword: "",
    confirmPassword: "",
    wing: "",
    house_no: "",
    building_name: "",
    secretary_id: "",
    sname: "",
    semail: "",
    spassword: "",
    sconfirmPassword: "",
  });
  const [secretaries, setSecretaries] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (formData.building_name.trim() && role === "user") {
      axios
        .get(`http://localhost:5000/public/secretaries/building?name=${formData.building_name}`)
        .then((res) => {
          console.log("Fetched secretaries:", res.data); // debug log
          setSecretaries(res.data);
        })
        .catch((err) => {
          console.error("Error fetching secretaries:", err.response?.data || err.message);
          setSecretaries([]);
        });
    }
  }, [formData.building_name, role]);  

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    try {
      if (role === "user") {
        if (formData.upassword !== formData.confirmPassword) {
          alert("User passwords do not match");
          setLoading(false);
          return;
        }
  
        const res = await axios.post("http://localhost:5000/public/users", {
          uname: formData.uname,
          uemail: formData.uemail,
          upassword: formData.upassword,
          wing: formData.wing,
          house_no: formData.house_no,
          building_name: formData.building_name,
          secretary_id: formData.secretary_id,
        });
  
        // ✅ Save token and role
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("role", "user");
  
        navigate("/user");
      } else {
        if (formData.spassword !== formData.sconfirmPassword) {
          alert("Secretary passwords do not match");
          setLoading(false);
          return;
        }
  
        const res = await axios.post("http://localhost:5000/public/secretaries", {
          sname: formData.sname,
          semail: formData.semail,
          spassword: formData.spassword,
          wing: formData.wing,
          house_no: formData.house_no,
          building_name: formData.building_name,
        });
  
        // ✅ Save token and role
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("role", "secretary");
  
        navigate("/secretary");
      }
    } catch (err) {
      alert(err.response?.data?.message || "Registration failed!");
    } finally {
      setLoading(false);
    }
  };  

  return (
    <div className="register-container d-flex align-items-center justify-content-center vh-100">
      <div className="card shadow-lg p-4 register-card w-75">
        <h2 className="text-center mb-4">Register</h2>

        {/* Role Selection */}
        <div className="mb-3">
          <label className="form-label">Register as</label>
          <select
            className="form-select"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="user">User</option>
            <option value="secretary">Secretary</option>
          </select>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="row">
            {/* LEFT SIDE */}
            <div className="col-md-6">
              {role === "user" ? (
                <>
                  <div className="mb-3">
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      name="uname"
                      className="form-control"
                      value={formData.uname}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      name="uemail"
                      className="form-control"
                      value={formData.uemail}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      name="upassword"
                      className="form-control"
                      value={formData.upassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Confirm Password</label>
                    <input
                      type="password"
                      name="confirmPassword"
                      className="form-control"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="mb-3">
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      name="sname"
                      className="form-control"
                      value={formData.sname}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      name="semail"
                      className="form-control"
                      value={formData.semail}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      name="spassword"
                      className="form-control"
                      value={formData.spassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Confirm Password</label>
                    <input
                      type="password"
                      name="sconfirmPassword"
                      className="form-control"
                      value={formData.sconfirmPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </>
              )}
            </div>

            {/* RIGHT SIDE */}
            <div className="col-md-6">
              <div className="mb-3">
                <label className="form-label">Wing</label>
                <input
                  type="text"
                  name="wing"
                  className="form-control"
                  value={formData.wing}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">House No</label>
                <input
                  type="text"
                  name="house_no"
                  className="form-control"
                  value={formData.house_no}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Building Name</label>
                <input
                  type="text"
                  name="building_name"
                  className="form-control"
                  value={formData.building_name}
                  onChange={handleChange}
                  required
                />
              </div>

              {role === "user" && (
                <div className="mb-3">
                  <label className="form-label">Select Secretary</label>
                  <select
                    name="secretary_id"
                    className="form-select"
                    value={formData.secretary_id}
                    onChange={handleChange}
                    required
                  >
                    <option value="">-- Select Secretary --</option>
                    {secretaries.map((sec) => (
                      <option key={sec.secretary_id} value={sec.secretary_id}>
                        {sec.sname} ({sec.building_name})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          <button
            type="submit"
            className="btn btn-success w-100 mt-3"
            disabled={loading}
          >
            {loading ? "Registering..." : "Register"}
          </button>
        </form>

        <p className="mt-3 text-center">
          Already have an account?{" "}
          <Link to="/login" className="text-decoration-none">
            Login here
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Registration;