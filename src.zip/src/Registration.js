import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Registration = () => {
  const [form, setForm] = useState({
    role: "user", // default role
    name: "",
    email: "",
    password: "",
    building_name: "",
    wing: "",
    house_no: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      let userData = {};

      if (form.role === "user") {
        const res = await axios.post(
          "http://localhost:5000/users",
          {
            uname: form.name,
            uemail: form.email,
            upassword: form.password,
            building_name: form.building_name,
            wing: form.wing,
            house_no: form.house_no,
          },
          { withCredentials: true }
        );
        userData = { role: "user", ...res.data }; // Save backend response
        localStorage.setItem("user", JSON.stringify(userData));
        alert("User registered successfully!");
        navigate("/user/dashboard");
      } else if (form.role === "secretary") {
        const res = await axios.post(
          "http://localhost:5000/secretaries",
          {
            sname: form.name,
            semail: form.email,
            spassword: form.password,
            building_name: form.building_name,
            wing: form.wing,
            house_no: form.house_no,
          },
          { withCredentials: true }
        );
        userData = { role: "secretary", ...res.data }; // Save backend response
        localStorage.setItem("user", JSON.stringify(userData));
        alert("Secretary registered successfully!");
        navigate("/secretary/dashboard");
      }

      // Clear form
      setForm({ role: "user", name: "", email: "", password: "", building_name: "", wing: "", house_no: "" });
    } catch (err) {
      console.error(err);
      alert("Registration failed");
    }
  };

  return (
    <div className="container mt-5 col-md-6">
      <h3 className="mb-3">Register {form.role === "user" ? "User" : "Secretary"}</h3>
      <form onSubmit={handleSubmit}>
        {/* Role Dropdown */}
        <div className="mb-3">
          <label className="form-label">Select Role</label>
          <select
            name="role"
            value={form.role}
            onChange={handleChange}
            className="form-control"
          >
            <option value="user">User</option>
            <option value="secretary">Secretary</option>
          </select>
        </div>

        <input
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          className="form-control mb-2"
          required
        />
        <input
          name="email"
          placeholder="Email"
          type="email"
          value={form.email}
          onChange={handleChange}
          className="form-control mb-2"
          required
        />
        <input
          name="password"
          placeholder="Password"
          type="password"
          value={form.password}
          onChange={handleChange}
          className="form-control mb-2"
          required
        />
        <input
          name="building_name"
          placeholder="Building"
          value={form.building_name}
          onChange={handleChange}
          className="form-control mb-2"
          required
        />
        <input
          name="wing"
          placeholder="Wing"
          value={form.wing}
          onChange={handleChange}
          className="form-control mb-2"
          required
        />
        <input
          name="house_no"
          placeholder="House No"
          value={form.house_no}
          onChange={handleChange}
          className="form-control mb-2"
          required
        />

        <button type="submit" className="btn btn-success w-100">
          Register
        </button>
      </form>
    </div>
  );
};

export default Registration;