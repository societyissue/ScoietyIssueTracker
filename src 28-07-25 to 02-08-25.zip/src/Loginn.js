import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const navigate = useNavigate();
  const [data, setData] = useState({
    uname: "",
    pwd: "",
  });

  // Handle input changes
  const handleChange = (event) => {
    const { name, value } = event.target;
    setData((values) => ({
      ...values,
      [name]: value,
    }));
  };

  // Login check
  const check = () => {
    const { uname, pwd } = data;
    if (uname === "manav" && pwd === "123") {
      navigate("/homee", { state: { user: uname } });
    } else {
      alert("Invalid username or password");
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
      <div className="card p-4 shadow" style={{ width: "350px" }}>
        <h3 className="text-center mb-3">Login</h3>
        <form>
          <div className="mb-3">
            <label htmlFor="uname" className="form-label">Username</label>
            <input
              type="text"
              className="form-control"
              id="uname"
              name="uname"
              placeholder="Enter Username"
              value={data.uname}
              onChange={handleChange}
            />
          </div>

          <div className="mb-3">
            <label htmlFor="pwd" className="form-label">Password</label>
            <input
              type="password"
              className="form-control"
              id="pwd"
              name="pwd"
              placeholder="Enter Password"
              value={data.pwd}
              onChange={handleChange}
            />
          </div>

          <button
            type="button"
            className="btn btn-primary w-100"
            onClick={check}
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
}