import React from "react";
import axios from "axios";

const Payment = () => {
  // Function to load Razorpay checkout script
  const loadScript = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const loadRazorpay = async () => {
    const scriptLoaded = await loadScript("https://checkout.razorpay.com/v1/checkout.js");
    if (!scriptLoaded) {
      alert("Failed to load Razorpay SDK. Check your internet connection.");
      return;
    }

    try {
      // Call backend to create order
      const result = await axios.post("http://localhost:5000/create-order", {
        amount: 500, // ₹5.00
      });

      const { id: order_id, amount } = result.data;

      const options = {
        key: "rzp_test_DtkdKHdJFeUHry", // from Razorpay dashboard
        amount: amount, // amount in paise
        currency: "INR",
        name: "My Store",
        description: "Test Transaction",
        order_id: order_id,
        handler: function (response) {
          alert("Payment ID: " + response.razorpay_payment_id);
          alert("Order ID: " + response.razorpay_order_id);
          alert("Signature: " + response.razorpay_signature);
        },
        prefill: {
          name: "Parekh Manav",
          email: "issuetracking25@gmail.com",
          contact: "6354202794",
        },
        theme: {
          color: "#3399cc",
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (error) {
      console.error("Error creating order:", error);
      alert("Failed to create order. Check backend logs.");
    }
  };

  return (
    <button
      onClick={loadRazorpay}
      style={{
        padding: "10px 20px",
        fontSize: "16px",
        backgroundColor: "#3399cc",
        color: "white",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
      }}
    >
      Pay ₹500
    </button>
  );
};

export default Payment;