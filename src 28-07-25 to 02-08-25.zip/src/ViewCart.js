import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const ViewCart = () => {
  const location = useLocation();
  const cart = location.state?.cart || [];

  const [coupon, setCoupon] = useState('');
  const [discount, setDiscount] = useState(0);
  const [message, setMessage] = useState('');

  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const finalAmount = total - discount;

  const applyCoupon = () => {
    const code = coupon.trim().toUpperCase();

    if (code === 'DISCOUNT10') {
      const d = total * 0.1;
      setDiscount(d);
      setMessage('10% discount applied!');
    } else if (code === 'DISCOUNT50') {
      setDiscount(50);
      setMessage('₹50 discount applied!');
    } else {
      setDiscount(0);
      setMessage('Invalid coupon code.');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Cart Items</h2>

      {cart.length === 0 ? (
        <div className="alert alert-warning text-center">Your cart is empty.</div>
      ) : (
        <>
          <table className="table table-bordered table-hover">
            <thead className="table-dark">
              <tr>
                <th>Product Name</th>
                <th>Price (Rs.)</th>
              </tr>
            </thead>
            <tbody>
              {cart.map((item, index) => (
                <tr key={index}>
                  <td>{item.name}</td>
                  <td>{item.price}</td>
                </tr>
              ))}
              <tr>
                <td><strong>Total</strong></td>
                <td><strong>Rs. {total.toFixed(2)}</strong></td>
              </tr>
              {discount > 0 && (
                <tr>
                  <td><strong>Discount</strong></td>
                  <td className="text-danger">- Rs. {discount.toFixed(2)}</td>
                </tr>
              )}
              <tr>
                <td><strong>Final Amount</strong></td>
                <td><strong>Rs. {finalAmount.toFixed(2)}</strong></td>
              </tr>
            </tbody>
          </table>

          <div className="row mt-4">
            <div className="col-md-6">
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Coupon Code"
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                />
                <button className="btn btn-primary" onClick={applyCoupon}>
                  Apply
                </button>
              </div>
              {message && (
                <p className={`mt-2 ${discount > 0 ? 'text-success' : 'text-danger'}`}>
                  {message}
                </p>
              )}
            </div>
          </div>
        </>
      )}

      <div className="mt-4">
        <Link to="/ProductGallery" className="btn btn-secondary">
          Back to Products
        </Link>
      </div>
    </div>
  );
};

export default ViewCart;