import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';

import { BrowserRouter, Route, Routes } from 'react-router-dom';
// import Payment from './razorpay/payment';
// import Home from './Homee';
// import About from './About';
// import Contact from './Contact';
// import Login from './Loginn';
// import ProductGallery from './ProductGallery';
// import ViewCart from './ViewCart';
// import SampleJSONAxios from './SampleJSONAxios';
// import InsertEmp from './InsertEmp';
// import UpdateDemo from './UpdateDemo';
// import InsertRecord from './InsertRecord';
// import EmployeeList from './EmployeeList';
// import InsertCourse from './course_demo/InsertCourse';
// import CourseList from './course_demo/CourseList';
// import FileUpload from './fileupload/FileUpload';
// import ShowProduct from './fileupload/ShowProduct';
// import ProductBrand from './foreign key concept/ProductBrand';
// import ProductBrandFom from './foreign key concept/ProductBrandFom';
// import ProductDetails from './foreign key concept/ProductDetails';
// import ProductForm from './foreign key concept/ProductForm';
// import Registration  from './foreign key concept/Registration';
// import Login from './foreign key concept/Login';
import Pay from './razorpay/Pay';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Pay/>}/>
        {/* <Route path='/' element={<Login/>}/>
        <Route path='/register' element={<Registration/>}/>
        <Route path='/brand/view' element={<ProductBrand/>}/>
        <Route path='/brand/insert' element={<ProductBrandFom/>}/>
        <Route path='/brand/edit/:id' element={<ProductBrandFom/>}/>
        <Route path='/mobile' element={<ProductDetails/>}/>
        <Route path='/mobile/insert' element={<ProductForm/>}/>
        <Route path='/mobile/edit/:id' element={<ProductForm/>}/> */}
        {/* <Route path='/product-form' element={<FileUpload/>}/>
        <Route path='/product-form/:p_id' element={<FileUpload/>}/>
        <Route path='/' element={<ShowProduct/>}/> */}
        {/* <Route path="/" element={<CourseList />} />
        <Route path="/course-form" element={<InsertCourse />} />
        <Route path="/course-form/:courseId" element={<InsertCourse />} /> */}
        {/* <Route exact path="/" element={<InsertEmp />} />
        <Route exact path="/employee/:id" element={<UpdateDemo />} /> */}
        {/* <Route exact path="/" element={<Login />} />
        <Route exact path="/homee" element={<Home />} />
        <Route exact path="/about" element={<About />} />
        <Route exact path="/contact" element={<Contact />} />
        <Route exact path="/ProductGallery" element={<ProductGallery />} />
        <Route exact path="/viewcart" element={<ViewCart />} /> */}
        {/* <Route exact path="/employee" element={<SampleJSONAxios />} />  */}
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);

reportWebVitals();