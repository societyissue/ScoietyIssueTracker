import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const fetchProducts = async () => {
    try {
      const res = await axios.get('http://localhost:4000/products');
      setProducts(res.data);
    } catch (err) {
      console.error('Fetch error:', err.message);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDelete = async (p_id) => {
    if (!window.confirm('Delete this product?')) return;
    try {
      await axios.delete(`http://localhost:4000/products/${p_id}`);
      fetchProducts();
    } catch (err) {
      console.error('Delete failed:', err.message);
    }
  };

  const filtered = products.filter(p =>
    p.p_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Product List</h2>

      <div className="row mb-3">
        <div className="col-md-5">
          <input
            type="text"
            className="form-control"
            placeholder="Search by name"
            value={searchTerm}
            onChange={e => {
              setSearchTerm(e.target.value);
              setError(e.target.value.trim() === '' ? 'Search field cannot be empty' : '');
            }}
          />
          {error && <small className="text-danger">{error}</small>}
        </div>
        <div className="col-md-3">
          <button className="btn btn-primary w-100" onClick={() => navigate('/product-form')}>
            Add Product
          </button>
        </div>
      </div>

      <table className="table table-bordered table-hover">
        <thead className="table-light">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Photo</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.length > 0 ? (
            filtered.map(product => (
              <tr key={product.p_id}>
                <td>{product.p_id}</td>
                <td>{product.p_name}</td>
                <td>{product.p_price}</td>
                <td>
                  {product.p_photo ? (
                    <img
                      src={`http://localhost:4000/uploads/${product.p_photo}`}
                      alt={product.p_name}
                      width="60"
                      height="60"
                      style={{ objectFit: 'cover', borderRadius: '4px' }}
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/60';
                      }}
                    />
                  ) : 'No Image'}
                </td>
                <td>
                  <button className="btn btn-sm btn-warning me-2"
                    onClick={() => navigate(`/product-form/${product.p_id}`)}>Edit</button>
                  <button className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(product.p_id)}>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center text-muted">No matching products found.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ProductList;