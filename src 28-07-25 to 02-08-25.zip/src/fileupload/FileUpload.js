import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const ProductForm = () => {
  const [formData, setFormData] = useState({ p_name: '', p_price: '', p_photo: null });
  const [preview, setPreview] = useState('');
  const navigate = useNavigate();
  const { p_id } = useParams();

  const isEdit = Boolean(p_id);

  useEffect(() => {
    if (isEdit) {
      axios.get(`http://localhost:4000/products/${p_id}`).then(res => {
        setFormData({ p_name: res.data.p_name, p_price: res.data.p_price, p_photo: null });
        setPreview(`http://localhost:4000/uploads/${res.data.p_photo}`);
      });
    }
  }, [p_id, isEdit]);

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = e => {
    const file = e.target.files[0];
    setFormData(prev => ({ ...prev, p_photo: file }));
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const data = new FormData();
    data.append('p_name', formData.p_name);
    data.append('p_price', formData.p_price);
    if (formData.p_photo) data.append('p_photo', formData.p_photo);

    try {
      if (isEdit) {
        await axios.put(`http://localhost:4000/products/${p_id}`, data);
      } else {
        await axios.post('http://localhost:4000/products', data);
      }
      navigate('/');
    } catch (err) {
      console.error('Submit failed:', err);
    }
  };

  return (
    <div className="container mt-4">
      <h3>{isEdit ? 'Edit' : 'Add'} Product</h3>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label className="form-label">Product Name</label>
          <input type="text" className="form-control" name="p_name" value={formData.p_name} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label className="form-label">Product Price</label>
          <input type="number" className="form-control" name="p_price" value={formData.p_price} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label className="form-label">Product Image</label>
          <input type="file" className="form-control" accept="image/*" onChange={handleFileChange} />
        </div>

        {preview && (
          <div className="mb-3">
            <img src={preview} alt="Preview" height="100" />
          </div>
        )}

        <button type="submit" className="btn btn-success">{isEdit ? 'Update' : 'Add'} Product</button>
      </form>
    </div>
  );
};

export default ProductForm;