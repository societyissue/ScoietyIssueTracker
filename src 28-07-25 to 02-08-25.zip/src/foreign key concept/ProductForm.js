import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const MobileForm = () => {
  const [model_no, setModelNo] = useState('');
  const [price, setPrice] = useState('');
  const [features, setFeatures] = useState('');
  const [images, setImages] = useState([]);
  const [preview, setPreview] = useState([]);
  const [oldImages, setOldImages] = useState([]); // from DB
  const [brands, setBrands] = useState([]);
  const [b_id, setBrand] = useState('');
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    axios.get('http://localhost:4000/brand/view').then(res => setBrands(res.data));

    if (id) {
      axios.get(`http://localhost:4000/mobile/update/${id}`).then(res => {
        setModelNo(res.data.model_no);
        setPrice(res.data.price);
        setFeatures(res.data.features);
        setBrand(res.data.b_id);
        const imgList = res.data.image?.split(',') || [];
        setOldImages(imgList);
      });
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('model_no', model_no);
    formData.append('price', price);
    formData.append('features', features);
    formData.append('b_id', b_id);

    // Append new images
    for (let i = 0; i < images.length; i++) {
      formData.append('images', images[i]);
    }

    // Append retained old images (after any removal)
    formData.append('oldImages', oldImages.join(','));

    if (id) {
      await axios.put(`http://localhost:4000/mobile/update/${id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
    } else {
      await axios.post('http://localhost:4000/mobile/insert', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
    }

    navigate('/mobile');
  };

  const removeOldImage = (imgName) => {
    setOldImages(oldImages.filter(img => img !== imgName));
  };

  return (
    <div className="container mt-4">
      <h2>{id ? 'Edit Mobile' : 'Add Mobile'}</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label>Model No</label>
          <input type="text" className="form-control" value={model_no} onChange={e => setModelNo(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label>Price</label>
          <input type="number" className="form-control" value={price} onChange={e => setPrice(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label>Features</label>
          <textarea className="form-control" value={features} onChange={e => setFeatures(e.target.value)} />
        </div>
        <div className="mb-3">
          <label>Brand</label>
          <select className="form-control" value={b_id} onChange={e => setBrand(e.target.value)} required>
            <option value="">-- Select Brand --</option>
            {brands.map(b => <option key={b.b_id} value={b.b_id}>{b.b_name}</option>)}
          </select>
        </div>

        {/* Existing images (editable) */}
        {id && oldImages.length > 0 && (
          <div className="mb-3">
            <label>Old Images (click to remove)</label>
            <div className="d-flex flex-wrap gap-2">
              {oldImages.map((img, index) => (
                <div key={index} className="position-relative">
                  <img
                    src={`http://localhost:4000/upload/${img}`}
                    alt="old"
                    height="100"
                    style={{ cursor: 'pointer', border: '2px solid #ccc' }}
                    onClick={() => removeOldImage(img)}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* New images upload */}
        <div className="mb-3">
          <label>New Images (optional)</label>
          <input
            type="file"
            className="form-control"
            multiple
            onChange={e => {
              setImages([...e.target.files]);
              setPreview([...e.target.files].map(file => URL.createObjectURL(file)));
            }}
          />
        </div>

        {/* Preview new images */}
        {preview.length > 0 && (
          <div className="mb-3 d-flex flex-wrap gap-2">
            {preview.map((img, i) => (
              <img key={i} src={img} height="100" alt="preview" />
            ))}
          </div>
        )}

        <button type="submit" className="btn btn-success mt-3">{id ? 'Update' : 'Add'} Mobile</button>
      </form>
    </div>
  );
};

export default MobileForm;