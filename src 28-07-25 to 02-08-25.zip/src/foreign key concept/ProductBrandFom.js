import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const BrandForm = () => {
  const [b_name, setBName] = useState('');
  const [b_logo, setBLogo] = useState(null);
  const [preview, setPreview] = useState('');
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      axios.get(`http://localhost:4000/brand/${id}`).then(res => {
        setBName(res.data.b_name);
        if (res.data.b_logo) {
          setPreview(`http://localhost:4000/upload/${res.data.b_logo}`);
        }
      });
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('b_name', b_name);
    if (b_logo) formData.append('b_logo', b_logo);

    try {
      if (id) {
        // UPDATE
        const response = await axios.put(`http://localhost:4000/brand/update/${id}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        console.log("Brand updated:", response.data);
      } else {
        // INSERT
        const response = await axios.post('http://localhost:4000/brand/insert', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        console.log("Brand added:", response.data);
      }
      navigate('/brand/view');
    } catch (err) {
      console.error("Submit error:", err.response?.data || err.message);
    }
  };

  return (
    <div className="container mt-4">
      <h2>{id ? 'Edit Brand' : 'Add Brand'}</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label>Brand Name</label>
          <input
            type="text"
            className="form-control"
            value={b_name}
            onChange={(e) => setBName(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label>Logo</label>
          <input
            type="file"
            className="form-control"
            onChange={(e) => {
              setBLogo(e.target.files[0]);
              setPreview(URL.createObjectURL(e.target.files[0]));
            }}
          />
        </div>

        {preview && <img src={preview} alt="Logo preview" height="80" />}

        <button type="submit" className="btn btn-success mt-3">
          {id ? 'Update' : 'Add'}
        </button>
      </form>
    </div>
  );
};

export default BrandForm;