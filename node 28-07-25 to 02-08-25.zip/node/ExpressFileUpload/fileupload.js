const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');
const fs = require('fs');
const connection = require('./db')

const app = express();
const PORT = 3000;

app.post('/api/fileupload', function (req, res) {
    const { p_id, p_name, p_price, p_photo } = req.body
    const query = "INSERT INTO product (p_id, p_name, p_price, p_photo) VALUES (?,?,?,?)"
    connection.query(query, [p_id,p_name,p_price,p_photo],(err,results)=>{
        if(err){
            console.error('Error in inserting product details:', err)
            return res.status(500).send('server error')
        }
    })
});
app.use(fileUpload());
app.use(express.static('uploads'));
app.post('/upload', (req, res) => {
    console.log(req.files);

    if (!req.files || !req.files.files) {
        return res.status(400).send('No files were uploaded.');
    }

    const allowedExtensions = ['.jpg', '.jpeg', '.png'];
    const uploadedFiles = Array.isArray(req.files.files) ? req.files.files : [req.files.files];
    let results = [];
    let uploadsDone = 0;

    const totalValidFiles = uploadedFiles.filter(file => file && file.name).length;

    uploadedFiles.forEach((file) => {
        if (!file || !file.name) {
            results.push(`One file is invalid or missing a name`);
            uploadsDone++;
            if (uploadsDone === totalValidFiles) {
                res.send(results.join('<br>'));
            }
            return;
        }

        const ext = path.extname(file.name).toLowerCase();
        if (!allowedExtensions.includes(ext)) {
            results.push(`${file.name} - Invalid file type`);
            uploadsDone++;
            if (uploadsDone === totalValidFiles) {
                res.send(results.join('<br>'));
            }
            return;
        }

        const uploadPath = path.join(__dirname, 'uploads', file.name);

        file.mv(uploadPath, (err) => {
            uploadsDone++;
            if (err) {
                results.push(`${file.name} - Failed to upload`);
            } else {
                results.push(`${file.name} - Uploaded successfully`);
            }

            if (uploadsDone === totalValidFiles) {
                res.send(results.join('<br>'));
            }
        });
    });
});



app.get('/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);

    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.status(404).send('File not found.');
        }
        res.download(filePath);
    });
});
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});