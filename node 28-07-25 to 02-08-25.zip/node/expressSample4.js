var express = require('express');
var app = express();
var bodyParser = require("body-parser");
//app.use(bodyParser.urlencoded({ extended: false }));

app.get('/', function (req, res) {
    res.sendFile(__dirname +'/express_form.html');
});

app.post('/submit-data', function (req, res) {
    console.log(req.body)
    var user = req.body.uname;
    var pass= req.body.pass;
    if (user=="mscit" && pass=="easy")
        res.sendFile(__dirname+"/register.html");
    else
        res.send("Verify User");
//    res.send(name + ' Submitted Successfully!');
});

app.get("/register",function(req,res)
{
res.sendFile(__dirname+"/register.html")
});

app.post("/submit_register",function(req,res)
{
    var user=req.body.user;
    var pass=req.body.pass;
    var email=req.body.email;
    var contact=req.body.contact;
    var city=req.body.city;
    res.send(user+ "<br> "+ pass+"<br>"+ email+"<br>"+ contact+"<br>"+city+"<br>");

});
var server = app.listen(8000, function () {
    console.log('server is running..8000');
});