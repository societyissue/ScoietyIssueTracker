const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db');

const app = express();
const PORT = 4000;

app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
app.use(express.json());
app.use('/upload', express.static('upload'));

// 🔴 Removed express-session
// 🔴 Removed isAuthenticated middleware

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'upload/'),
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

/* -------- AUTH -------- */
app.post('/login', (req, res) => {
  const { remail, rpassword } = req.body;
  db.query(
    'SELECT * FROM registration WHERE remail = ? AND rpassword = ?',
    [remail, rpassword],
    (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (result.length === 0) return res.status(401).json({ message: 'Invalid credentials' });

      const { rpassword, ...user } = result[0];
      res.json({ message: 'Login successful', user });
    }
  );
});

app.post('/logout', (req, res) => {
  res.json({ message: 'Logged out' }); // no session to destroy
});

app.post('/registration', (req, res) => {
  const { name, email, password } = req.body;

  // 1. Check if the email already exists
  db.query('SELECT * FROM registration WHERE remail = ?', [email], (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error', error: err });

    if (results.length > 0) {
      // Email already registered
      return res.status(400).json({ message: 'Email already registered' });
    }

    // 2. Insert new user
    db.query('INSERT INTO registration (rname, remail, rpassword) VALUES (?, ?, ?)', 
      [name, email, password], 
      (err2, result) => {
        if (err2) return res.status(500).json({ message: 'Insert failed', error: err2 });

        res.status(200).json({ message: 'Registration successful' });
    });
  });
});

/* -------- BRAND ROUTES -------- */
app.post('/brand/insert', upload.single('b_logo'), (req, res) => {
  const { b_name } = req.body;
  const b_logo = req.file?.filename || null;
  db.query('INSERT INTO product_brand (b_name, b_logo) VALUES (?, ?)', [b_name, b_logo], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Brand added', id: result.insertId });
  });
});

app.get('/brand/view', (req, res) => {
  db.query('SELECT * FROM product_brand', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

app.get('/brand/:id', (req, res) => {
  db.query('SELECT * FROM product_brand WHERE b_id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Brand not found' });
    res.json(result[0]);
  });
});

app.put('/brand/update/:id', upload.single('b_logo'), (req, res) => {
  const { b_name } = req.body;
  const { id } = req.params;
  const b_logo = req.file?.filename;

  const sql = b_logo
    ? 'UPDATE product_brand SET b_name = ?, b_logo = ? WHERE b_id = ?'
    : 'UPDATE product_brand SET b_name = ? WHERE b_id = ?';
  const values = b_logo ? [b_name, b_logo, id] : [b_name, id];

  db.query(sql, values, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Brand updated successfully' });
  });
});

app.delete('/brand/delete/:id', (req, res) => {
  const id = req.params.id;
  db.query('SELECT COUNT(*) AS count FROM products WHERE b_id = ?', [id], (err, result) => {
    if (err) return res.status(500).json(err);

    if (result[0].count > 0) {
      return res.status(400).json({ error: 'Brand is associated with products. Cannot delete.' });
    }
    db.query('SELECT b_logo FROM product_brand WHERE b_id = ?', [id], (err, result) => {
      if (err) return res.status(500).json(err);

      const logo = result[0]?.b_logo;
      if (logo) {
        const logoPath = path.join(__dirname, 'upload', logo);
        if (fs.existsSync(logoPath)) {
          try {
            fs.unlinkSync(logoPath);
          } catch (fileErr) {
            console.error('Error deleting logo:', fileErr);       
          }
        }
      }
      db.query('DELETE FROM product_brand WHERE b_id = ?', [id], (err2) => {
        if (err2) return res.status(500).json(err2);
        res.json({ message: 'Brand deleted' });
      });
    });
  });
});

/* -------- MOBILE ROUTES -------- */
app.post('/mobile/insert', upload.array('images', 5), (req, res) => {
  const { model_no, price, b_id, features } = req.body;
  if (!req.files?.length) return res.status(400).json({ error: 'Images required' });

  const images = req.files.map(file => file.filename).join(',');
  db.query('INSERT INTO products (model_no, price, image, b_id, features) VALUES (?, ?, ?, ?, ?)',
    [model_no, price, images, b_id, features],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Mobile added', id: result.insertId });
    }
  );
});

app.get('/mobile/view', (req, res) => {
  db.query(`
    SELECT p.*, b.b_name AS brand_name
    FROM products p
    JOIN product_brand b ON p.b_id = b.b_id
    ORDER BY p.m_id ASC
  `, (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
});

app.get('/mobile/update/:id', (req, res) => {
  db.query('SELECT * FROM products WHERE m_id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(404).json({ message: 'Mobile not found' });
    res.json(result[0]);
  });
});

app.put('/mobile/update/:id', upload.array('images', 5), (req, res) => {
  const { model_no, price, features, b_id } = req.body;
  const { id } = req.params;

  if (req.files?.length > 0) {
    db.query('SELECT image FROM products WHERE m_id = ?', [id], (err, result) => {
      if (err) return res.status(500).json(err);

      const oldImages = result[0]?.image?.split(',') || [];
      oldImages.forEach(img => {
        const filePath = path.join(__dirname, 'upload', img);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      });

      const newImages = req.files.map(file => file.filename).join(',');
      db.query(
        'UPDATE products SET model_no=?, price=?, image=?, b_id=?, features=? WHERE m_id=?',
        [model_no, price, newImages, b_id, features, id],
        (err2) => {
          if (err2) return res.status(500).json(err2);
          res.json({ message: 'Updated with new images' });
        }
      );
    });
  } else {
    db.query(
      'UPDATE products SET model_no=?, price=?, b_id=?, features=? WHERE m_id=?',
      [model_no, price, b_id, features, id],
      (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Updated without images' });
      }
    );
  }
});

app.delete('/mobile/:id', (req, res) => {
  db.query('DELETE FROM products WHERE m_id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Deleted' });
  });
});

// Start server
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));