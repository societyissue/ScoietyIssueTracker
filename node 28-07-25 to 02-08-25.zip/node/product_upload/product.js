const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const multer = require('multer');
const path = require('path');

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));


const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', 
  database: 'fileupload',
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) =>
    cb(null, Date.now() + path.extname(file.originalname)),
});

const upload = multer({ storage });


app.post('/products', upload.single('p_photo'), (req, res) => {
  const { p_name, p_price } = req.body;
  const p_photo = req.file ? req.file.filename : null;
  const sql = 'INSERT INTO product (p_name, p_price, p_photo) VALUES (?, ?, ?)';
  db.query(sql, [p_name, p_price, p_photo], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Product added', id: result.insertId });
  });
});


app.get('/products', (req, res) => {
  db.query('SELECT * FROM product', (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
});


app.get('/products/:id', (req, res) => {
  db.query('SELECT * FROM product WHERE p_id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result[0]);
  });
});


app.put('/products/:id', upload.single('p_photo'), (req, res) => {
  const { p_name, p_price } = req.body;
  const p_photo = req.file ? req.file.filename : null;

  let sql;
  let data;

  if (p_photo) {
    sql = 'UPDATE product SET p_name = ?, p_price = ?, p_photo = ? WHERE p_id = ?';
    data = [p_name, p_price, p_photo, req.params.id];
  } else {
    sql = 'UPDATE product SET p_name = ?, p_price = ? WHERE p_id = ?';
    data = [p_name, p_price, req.params.id];
  }

  db.query(sql, data, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Product updated' });
  });
});


app.delete('/products/:id', (req, res) => {
  db.query('DELETE FROM product WHERE p_id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Product deleted' });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});