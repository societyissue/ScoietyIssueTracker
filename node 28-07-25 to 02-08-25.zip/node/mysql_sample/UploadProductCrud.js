const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const cors=require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(cors())
// MySQL setup
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'testdb2'
});

db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Multer setup for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// CRUD operations

// Create product
app.post('/products', upload.single('photo'), (req, res) => {
    const { pname, price } = req.body;
    const photo = req.file ? req.file.filename : null;
    const query = 'INSERT INTO product (pname, price, photo) VALUES (?, ?, ?)';
    db.query(query, [pname, price, photo], (err, result) => {
        if (err) throw err;
        res.json({ id: result.insertId, pname, price, photo });
    });
});

// Read products
app.get('/products', (req, res) => {
    const query = 'SELECT * FROM product';
    db.query(query, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// Update product
app.put('/products/:id', upload.single('photo'), (req, res) => {
    const { pname, price } = req.body;
    const photo = req.file ? req.file.filename : null;
    const query = 'UPDATE product SET pname = ?, price = ?, photo = ? WHERE pid = ?';
    db.query(query, [pname, price, photo, req.params.id], (err, result) => {
        if (err) throw err;
        res.json({ message: 'Product updated successfully' });
    });
});

// Delete product
app.delete('/products/:id', (req, res) => {
    const query = 'DELETE FROM product WHERE pid = ?';
    db.query(query, [req.params.id], (err, result) => {
        if (err) throw err;
        res.json({ message: 'Product deleted successfully' });
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
