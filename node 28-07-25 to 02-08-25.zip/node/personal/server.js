const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use('/upload', express.static('upload'));

app.post('/insert',  (req, res) => {
    const { b_name } = req.body;
    const sql = 'INSERT INTO personal (b_name, b_logo) VALUES (?, ?)';
    db.query(sql, [b_name, b_logo], (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Brand added', id: result.insertId });
    });
});

app.listen(PORT, () => {
    console.log("Server running at port number 5000")
})