const express = require("express");
const cors = require("cors");
const Razorpay = require("razorpay");

const app = express();
const PORT = 5000;

app.use(cors({
  origin: "http://localhost:3000", // React app URL
  methods: ["GET", "POST"],
  credentials: true
}));
app.use(express.json());

// Razorpay instance
const instance = new Razorpay({
  key_id: "rzp_test_DtkdKHdJFeUHry",   // Your Razorpay Key ID
  key_secret: "YbXeICIcT1QzHHC2uKRPMLm2"        // Your Razorpay Key Secret
});

// Create order API
app.post("/create-order", async (req, res) => {
  const { amount } = req.body;

  try {
    const order = await instance.orders.create({
      amount: amount * 100, // amount in paise
      currency: "INR",
      receipt: `receipt_${Date.now()}`,
    });
    res.json(order);
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).send("Error creating order");
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
