var express = require('express');
//var { get } = require('http');
var app = express();

app.get('/', function(req, res){
   res.send("Hello world!");
});

app.get('/test1', function(req, res){
    res.send("Hello Test1.....!");
 });

app.get('/test2', function(req, res){
    res.send("Hello Test2.....!");
 });

app.get('/mscit', function(req, res){
   res.send("Hello MSCIT USers ");
});

app.get('/mscict', function(req, res){
   res.send("Learning Routing");
});

app.listen(3000);
// npm install express 
