var http = require('http')

var server = http.createServer(function(req,res){
    if(req.url=='/'){
        res.writeHead({'content-type':'text/html'})
        res.write('Hello world')
        res.end()
    }
    if(req.url=='/home'){
        res.writeHead({'content-type':'text/html'})
        res.write('This is home us page')
        res.end()
    }
    if(req.url=='/about'){
        res.writeHead({'content-type':'text/html'})
        res.write('This is about us page')
        res.end()
    }
    if(req.url=='/contact'){
        res.writeHead({'content-type':'text/html'})
        res.write('This is contact us page')
        res.end()
    }
    if(req.url=='/json'){
        res.writeHead({'content-type':'application/json'})
        res.write(JSON.stringify({ 'name': "Manav", 'role':'admin'}));  
        res.end();
    }
})
server.listen(3200)
console.log('server running at port number 3200')