const express = require('express');
const connection = require('./db');
const cors=require('cors');

const app = express();

app.use(express.json());

app.use(cors())

app.post('/api/addcourse', (req, res) => {
    
    const { courseId, courseName, credits, department } = req.body;
    const query = "INSERT INTO course (courseId, courseName, credits, department) VALUES (?, ?, ?, ?)";
    connection.query(query, [courseId, courseName, credits, department], (err, results) => {
      if (err) {
        console.error('Error inserting course:', err);
        return res.status(500).send('Server error');
      } else {
        res.status(201).send('Course created');
      }
    });
  });

app.get('/api/viewcourse',(req,res) => {
    const query = "SELECT * FROM course";
    connection.query(query, (err, results)=>{
        if(err){
            console.error('Error in fetching details of course', err)
            res.status(500).send('Server error')
        }
        else{
            res.status(200).json(results)
        }
    })
})

app.get('/api/update/:courseId',(req,res)=>{
    const {courseId} = req.params
    const query = "SELECT * FROM course WHERE courseId = ?"
    connection.query(query,[courseId],(err,results)=>{
        if(err){
            console.error('Error in fetching course id', err)
            res.status(500).send('Server error')
        }else if (results.length === 0) {
            res.status(404).send('Course not found');
        }
        else{
            res.status(200).json(results[0])
        }
    })
})

app.put('/api/update/:courseId',(req,res)=>{
    const {courseId} = req.params
    const {courseName,credits,department} = req.body
    const query = "UPDATE course SET courseName = ?, credits = ?, department = ? WHERE courseId = ?"
    connection.query(query,[courseName,credits,department,courseId],(err,results)=>{
        if(err){
            console.error('Error in update details of course',err)
            res.status(500).send('Server error')
        }
        else if(results.affectedRows === 0){
            res.status(404).send('Course not found')
        }else{
            res.status(200).json('Course update Successfully')
        }
    })
})

app.delete('/api/delete/:courseId',(req,res)=>{
    const {courseId} = req.params
    const query = "DELETE FROM course WHERE courseId = ?"
    connection.query(query,[courseId],(err,results)=>{
        if(err){
            console.error('Error for delete record of course',err)
            res.status(500).send('Server error')
        }else if(results.affectedRows === 0){
            res.status(404).send('Course not found')
        }else{
            res.status(200).send('Course delete')
        }
    })
})

const PORT = 5000
app.listen(PORT, ()=>{
    console.log(`Server is running on port ${PORT}`)
})