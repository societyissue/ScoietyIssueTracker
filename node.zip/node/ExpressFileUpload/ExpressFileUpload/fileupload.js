//npm install express express-fileupload

const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.get('/', function (req, res) {
    res.sendFile(__dirname +'/sample.html');
});

app.use(fileUpload());

// Set up a static folder to serve files
app.use(express.static('uploads'));

// send sample.html file


app.post('/upload', (req, res) => {
    console.log(req.files);

    if (!req.files || !req.files.files) {
        return res.status(400).send('No files were uploaded.');
    }

    const allowedExtensions = ['.jpg', '.jpeg', '.png'];
    const uploadedFiles = Array.isArray(req.files.files) ? req.files.files : [req.files.files];
    let results = [];
    let uploadsDone = 0;

    const totalValidFiles = uploadedFiles.filter(file => file && file.name).length;

    uploadedFiles.forEach((file) => {
        if (!file || !file.name) {
            results.push(`One file is invalid or missing a name`);
            uploadsDone++;
            if (uploadsDone === totalValidFiles) {
                res.send(results.join('<br>'));
            }
            return;
        }

        const ext = path.extname(file.name).toLowerCase();
        if (!allowedExtensions.includes(ext)) {
            results.push(`${file.name} - Invalid file type`);
            uploadsDone++;
            if (uploadsDone === totalValidFiles) {
                res.send(results.join('<br>'));
            }
            return;
        }

        const uploadPath = path.join(__dirname, 'uploads', file.name);

        file.mv(uploadPath, (err) => {
            uploadsDone++;
            if (err) {
                results.push(`${file.name} - Failed to upload`);
            } else {
                results.push(`${file.name} - Uploaded successfully`);
            }

            if (uploadsDone === totalValidFiles) {
                res.send(results.join('<br>'));
            }
        });
    });
});


// Route to download a file
app.get('/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);

    // Check if the file exists, then download
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.status(404).send('File not found.');
        }
        res.download(filePath);
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
