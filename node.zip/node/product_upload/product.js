const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'fileupload'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '_' + file.originalname);
  }
});
const upload = multer({ storage: storage });

app.post('/products', upload.single('p_photo'), (req, res) => {
  const { p_name, p_price } = req.body;
  const p_photo = req.file ? `uploads/${req.file.filename}` : null;

  db.query(
    'INSERT INTO product (p_name, p_price, p_photo) VALUES (?, ?, ?)',
    [p_name, p_price, p_photo],
    (err, result) => {
      if (err) return res.status(500).send(err);
      res.send({ message: 'Product added', id: result.insertId });
    }
  );
});

app.get('/products', (req, res) => {
  db.query('SELECT * FROM product', (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

app.get('/products/:id', (req, res) => {
  db.query(
    'SELECT * FROM product WHERE p_id = ?',
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).send(err);
      if (result.length === 0) return res.status(404).send({ message: 'Not found' });
      res.send(result[0]);
    }
  );
});

app.put('/products/:id', upload.single('p_photo'), (req, res) => {
  const { p_name, p_price } = req.body;
  const p_photo = req.file ? `uploads/${req.file.filename}` : null;

  let query = 'UPDATE product SET p_name = ?, p_price = ?';
  const values = [p_name, p_price];

  if (p_photo) {
    query += ', p_photo = ?';
    values.push(p_photo);
  }

  query += ' WHERE p_id = ?';
  values.push(req.params.id);

  db.query(query, values, (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ message: 'Product updated' });
  });
});

app.delete('/products/:id', (req, res) => {
  db.query('DELETE FROM product WHERE p_id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ message: 'Product deleted' });
  });
});

app.listen(4000, () => console.log('Server running on port 4000'));