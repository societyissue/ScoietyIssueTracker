// app.js
const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./db');
const cors=require('cors');

const app = express();

app.use(express.json());

app.use(cors())
// Create a new student

app.post('/emp', (req, res) => {
  const { id, name, age } = req.body;
  const query = 'INSERT INTO Employee (id, name, age) VALUES (?, ?, ?)';
  connection.query(query, [id, name, age], (err, results) => {
    if (err) {
      console.error('Error inserting student:', err);
      res.status(500).send('Server error');
    } else {
      res.status(201).send('Student created');
    }
  });
});

// Read all students
app.get('/employee', (req, res) => {
  const query = 'SELECT * FROM Employee';
  connection.query(query, (err, result) => {
    if (err) {
      console.error('Error fetching students:', err);
      res.status(500).send('Server error');
    } else {
      res.status(200).json(result);
    }
  });
});

// Read a single student by rno
app.get('/emp/:id', (req, res) => {
  const { id } = req.params;
  const query = 'SELECT * FROM Employee WHERE id = ?';
  connection.query(query, [id], (err, results) => {
    if (err) {
      console.error('Error fetching employee:', err);
      res.status(500).send('Server error');
    } else if (results.length === 0) {
      res.status(404).send('Student not found');
    } else {
      res.status(200).json(results[0]);
    }
  });
});

// Update a student
app.put('/emp/:id', (req, res) => {
  const id = req.params.id;
  const { name, age } = req.body;
  const sql = 'UPDATE Employee SET name = ?, age = ? WHERE id = ?';
  connection.query(sql, [name, age, id], (err, result) => {
    if (err) return res.status(500).json({ message: 'Update error', error: err });
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Employee not found' });
    res.json({ message: 'Record updated successfully' });
  });
});

// Delete a student
app.delete('/employee/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM Employee WHERE id = ?';
  connection.query(query, [id], (err, results) => {
    if (err) {
      console.error('Error deleting employee:', err);
      res.status(500).send('Server error');
    } else if (results.affectedRows === 0) {
      res.status(404).send('Employee not found');
    } else {
      res.status(200).send('Employee deleted');
    }
  });
});

// Start the server
const PORT = 8000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
