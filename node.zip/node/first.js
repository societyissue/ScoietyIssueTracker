var http = require('http')
var server = http.createServer(
    function(req,res){
        if(req.url=='/'){
            res.writeHead(200, {'content-type':'text/html'})
            res.write('<b>Hello welcome to my new internship during</b>')
        }
        else if(req.url=='/admin'){
            res.writeHead(200, {'content-type':'text/html'})
            res.write('<b>Hello welcome Admin</b>')
            res.end()
        }
        else if(req.url=='/secretery'){
            res.writeHead(200, {'content-type':'text/html'})
            res.write('<b>Hello welcome Secretery</b>')
            res.end()
        }
        else if(req.url=='/user'){
            res.writeHead(200, {'content-type':'text/html'})
            res.write('<b>Hello welcome User</b>')
            res.end()
        }
        else{
            res.write('<b>404 Not Found<b>')
            res.end()
        }
    }
)
server.listen(3000)
console.log('server running at port number 3000')