var { check, validationResult } = require('express-validator'); 
var bodyparser = require('body-parser') ;
var express = require("express") ;
var app = express() ;

app.use(bodyparser.urlencoded({ extended: false })) 

app.get("/", function (req, res) { 
	res.sendFile(__dirname+"/validateform.html"); 
}) 

app.post('/submitForm', [ 
    check('name', 'Name length should be 1 to 15 characters') 
                    .isLength({ min: 1, max: 15 }),
    check('email', 'Email length should be 10 to 30 characters') 
                    .isEmail().isLength({ min: 10, max: 30 }),
    check('password', 'Password length should be 8 to 10 characters')
                    .notEmpty().withMessage("Password is required")
                    .isLength({ min: 8, max: 10 }),
    check('salary')
                    .exists({ checkFalsy: true }).withMessage('Salary is required')
                    .bail()
                    .custom(value => {
                      // Convert to number
                      const num = Number(value);
                      if (isNaN(num)) {
                        throw new Error('Salary must be a valid number');
                      }
                      if (!Number.isInteger(num)) {
                        throw new Error('Salary must be an integer');
                      }
                      if (num < 10000 || num > 50000) {
                        throw new Error('Salary must be between 10000 and 50000');
                      }
                      return true;
                    })
], (req, res) => { 
 
    var errors = validationResult(req); 

    if (!errors.isEmpty()) { 
        res.json(errors) 
    }    
    else { 
        res.send("Successfully validated") 
    } 
});

var server = app.listen(8001, function () {
    console.log('8001  server is running..');
});