// server.js
const express = require("express");
const mysql = require("mysql2");
const session = require("express-session");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const sharp = require("sharp");

const app = express();
const PORT = 5000;

/* ======================== Middleware ======================== */
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: "super-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false,
      sameSite: "lax",
    },
  })
);
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

/* ======================== DB Connection ======================== */
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "issue_tracking",
});
db.connect((err) => {
  if (err) console.error("DB connection error:", err);
  else console.log("Connected to MySQL");
});
const dbp = db.promise();

/* ======================== File Upload ======================== */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

const resizeImage = async (filePath) => {
  const outputFile = filePath.replace(/(\.\w+)$/, "_resized$1");
  await sharp(filePath).resize(800, 600, { fit: "inside" }).toFile(outputFile);
  fs.unlinkSync(filePath);
  return outputFile.replace(/^uploads[\\/]/, "uploads/");
};

/* ======================== Helpers ======================== */
const requireRole = (roles) => (req, res, next) => {
  const user = req.currentUser;
  if (!user || !roles.includes(user.role)) return res.status(403).json({ message: "Forbidden" });
  next();
};

const roleToLogType = (role) => (role === "Secretary" ? "Secretary" : "User");

const notify = (receiver_type, receiver_id, message, cb = () => {}) => {
  if (!["User", "Secretary", "admin"].includes(receiver_type)) return cb(null, null);
  db.query(
    "INSERT INTO notifications (receiver_type, receiver_id, message) VALUES (?,?,?)",
    [receiver_type, receiver_id, message],
    cb
  );
};

// unified helper used everywhere below
function createNotification(receiverType, receiverId, message) {
  db.query(
    "INSERT INTO notifications (receiver_type, receiver_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())",
    [receiverType, receiverId, message],
    (err) => {
      if (err) console.error("Notification error:", err);
    }
  );
}

async function notifyAllAdmins(message) {
  try {
    const [admins] = await dbp.query("SELECT admin_id FROM admin");
    admins.forEach((a) => createNotification("admin", a.admin_id, message));
  } catch (e) {
    console.error("notifyAllAdmins error:", e);
  }
}

async function notifySecretaryForBuilding(building_name, message) {
  try {
    const [secs] = await dbp.query("SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1", [building_name]);
    if (secs.length) createNotification("Secretary", secs[0].secretary_id, message);
  } catch (e) {
    console.error("notifySecretaryForBuilding error:", e);
  }
}

app.use((req, res, next) => {
  req.currentUser = req.session.user || null;
  next();
});

/* ======================== Auth ======================== */
app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  // Admin
  db.query(
    "SELECT admin_id AS id, admin_email AS email, admin_password AS password FROM admin WHERE admin_email=? LIMIT 1",
    [email],
    (err, adminRows) => {
      if (err) return res.status(500).json({ message: "DB error", error: err });
      if (adminRows.length > 0) {
        const admin = adminRows[0];
        if (admin.password !== password) {
          return res.status(401).json({ message: "Invalid email or password" });
        }
        req.session.user = { role: "admin", id: admin.id, email: admin.email, name: admin.email.split("@")[0] };
        return res.json({ message: "Logged in as Admin", user: req.session.user });
      }

      // Secretary
      db.query(
        "SELECT secretary_id AS id, semail AS email, spassword AS password, sname AS name FROM secretary WHERE semail=? LIMIT 1",
        [email],
        (err, secRows) => {
          if (err) return res.status(500).json({ message: "DB error", error: err });
          if (secRows.length > 0) {
            const secretary = secRows[0];
            if (secretary.password !== password) {
              return res.status(401).json({ message: "Invalid email or password" });
            }
            req.session.user = { role: "secretary", id: secretary.id, email: secretary.email, name: secretary.name };
            return res.json({ message: "Logged in as Secretary", user: req.session.user });
          }

          // User
          db.query(
            "SELECT user_id AS id, uemail AS email, upassword AS password, uname AS name FROM users WHERE uemail=? LIMIT 1",
            [email],
            (err, userRows) => {
              if (err) return res.status(500).json({ message: "DB error", error: err });
              if (userRows.length > 0) {
                const user = userRows[0];
                if (user.password !== password) {
                  return res.status(401).json({ message: "Invalid email or password" });
                }
                req.session.user = { role: "user", id: user.id, email: user.email, name: user.name };
                return res.json({ message: "Logged in as User", user: req.session.user });
              }

              return res.status(401).json({ message: "Invalid email or password" });
            }
          );
        }
      );
    }
  );
});
app.get("/auth/me", (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Unauthorized" });
  res.json(req.session.user);
});


/* ======================== Secretary CRUD ======================== */
app.post("/secretaries", requireRole(["admin"]), (req, res) => {
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;
  db.query(
    "INSERT INTO secretary (sname, semail, spassword, role, wing, house_no, building_name) VALUES (?, ?, ?, 'Secretary', ?, ?, ?)",
    [sname, semail, spassword, wing, house_no, building_name],
    (err, result) =>
      err ? res.status(500).json(err) : res.json({ message: "Secretary created", secretary_id: result.insertId })
  );
});
app.get("/secretaries", requireRole(["admin", "Secretary"]), (req, res) => {
  db.query("SELECT * FROM secretary", (err, rows) => (err ? res.status(500).json(err) : res.json(rows)));
});
app.put("/secretaries/:id", requireRole(["admin", "Secretary"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;
  if (role !== "admin" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query(
    "UPDATE secretary SET sname=?, semail=?, spassword=?, wing=?, house_no=?, building_name=? WHERE secretary_id=?",
    [sname, semail, spassword, wing, house_no, building_name, req.params.id],
    (err) => (err ? res.status(500).json(err) : res.json({ message: "Secretary updated" }))
  );
});
app.delete("/secretaries/:id", requireRole(["admin"]), (req, res) => {
  db.query("DELETE FROM secretary WHERE secretary_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "Secretary deleted" })
  );
});


app.get("/secretary/dashboard-data", async (req, res) => {
  try {
    // 1️⃣ Get the logged-in secretary's ID
    const secretaryId = req.currentUser?.id;
    if (!secretaryId) return res.status(401).json({ message: "Unauthorized" });

    // 2️⃣ Fetch the building name
    const [secRows] = await dbp.query(
      "SELECT building_name FROM secretary WHERE secretary_id=?",
      [secretaryId]
    );
    if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
    const buildingName = secRows[0].building_name;

    // 3️⃣ Fetch issues and stats
    const [statsRows, issuesRows] = await Promise.all([
      dbp.query(
        `SELECT 
          COUNT(*) AS total,
          SUM(status='Pending') AS pending,
          SUM(status='In Progress') AS inProgress,
          SUM(status='Resolved') AS resolved
        FROM issues 
        WHERE building_name=? AND reporter_type='user'`,
        [buildingName]
      ),
      dbp.query(
        `SELECT i.*, u.uname AS reporter_name
         FROM issues i
         JOIN users u ON i.reporter_id=u.user_id
         WHERE i.building_name=? AND i.reporter_type='user'
         ORDER BY i.issue_id DESC`,
        [buildingName]
      ),
    ]);

    const stats = statsRows[0][0] || { total: 0, pending: 0, inProgress: 0, resolved: 0 };
    const issues = issuesRows[0] || [];

    // 4️⃣ Send response
    res.json({ buildingName, stats, issues });
  } catch (err) {
    console.error("Secretary dashboard error:", err);
    res.status(500).json({ message: "Server error", error: err });
  }
});

app.get("/secretaries/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM secretary WHERE secretary_id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(404).json({ error: "Secretary not found" });
    res.json(results[0]);
  });
});

/* ======================== Users CRUD ======================== */
app.post("/users", requireRole(["admin", "Secretary"]), (req, res) => {
  const { uname, uemail, upassword, wing, house_no, building_name } = req.body;
  db.query("SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1", [building_name], (err, rows) => {
    if (err) return res.status(500).json(err);
    const secretary_id = rows.length ? rows[0].secretary_id : null;
    db.query(
      "INSERT INTO users (uname, uemail, upassword, role, wing, house_no, building_name, secretary_id) VALUES (?,?,?, 'User', ?,?,?,?)",
      [uname, uemail, upassword, wing, house_no, building_name, secretary_id],
      (iErr, result) =>
        iErr ? res.status(500).json(iErr) : res.json({ message: "User created", user_id: result.insertId, secretary_id })
    );
  });
});

// Get all users in the logged-in secretary's building
app.get("/secretary/users", requireRole(["Secretary"]), async (req, res) => {
  try {
    const secretary = req.currentUser;
    if (!secretary) return res.status(401).json({ message: "Unauthorized" });

    // Ensure role is correct (case-insensitive)
    if (secretary.role.toLowerCase() !== "secretary") {
      return res.status(403).json({ message: "Forbidden" });
    }

    const secretaryId = secretary.id;

    // Fetch secretary's building
    const [secRows] = await dbp.query(
      "SELECT building_name FROM secretary WHERE secretary_id = ?",
      [secretaryId]
    );

    if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });

    const buildingName = secRows[0].building_name;

    // Fetch all users in the same building
    const [userRows] = await dbp.query(
      "SELECT user_id, uname, uemail, wing, house_no, building_name FROM users WHERE building_name = ?",
      [buildingName]
    );

    if (!userRows.length) return res.status(404).json({ message: "No users found in your building" });

    res.json({ buildingName, users: userRows });
  } catch (err) {
    console.error("Error fetching users for secretary:", err);
    res.status(500).json({ message: "Server error", error: err });
  }
});

app.get("/users/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM users WHERE user_id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(404).json({ error: "User not found" });
    res.json(results[0]);
  });
});
app.get("/users", requireRole(["admin", "Secretary", "User"]), async (req, res) => {
  const { role, id } = req.currentUser;

  try {
    if (role === "admin") {
      const [rows] = await dbp.query("SELECT * FROM users");
      return res.json(rows);
    }

    if (role === "Secretary") {
      // Secretary sees all users in their building
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [id]);
      if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
      const building = secRows[0].building_name;
      const [userRows] = await dbp.query("SELECT * FROM users WHERE building_name=?", [building]);
      return res.json(userRows);
    }
    res.status(403).json({ message: "Forbidden" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error", error: err });
  }
});

app.put("/users/:id", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  const { uname, uemail, upassword, wing, house_no, building_name } = req.body;
  if (role === "User" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query("SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1", [building_name], (err, rows) => {
    if (err) return res.status(500).json(err);
    const secretary_id = rows.length ? rows[0].secretary_id : null;
    db.query(
      "UPDATE users SET uname=?, uemail=?, upassword=?, wing=?, house_no=?, building_name=?, secretary_id=? WHERE user_id=?",
      [uname, uemail, upassword, wing, house_no, building_name, secretary_id, req.params.id],
      (uErr) => (uErr ? res.status(500).json(uErr) : res.json({ message: "User updated", secretary_id }))
    );
  });
});
app.delete("/users/:id", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  if (role === "User" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query("DELETE FROM users WHERE user_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "User deleted" })
  );
});

/* ======================== Issues CRUD ======================== */
const insertIssueLog = (issue_id, updated_by_type, updated_by_id, action, old_value, new_value, cb = () => {}) => {
  db.query(
    "INSERT INTO issue_logs (issue_id, updated_by_type, updated_by_id, action, old_value, new_value) VALUES (?,?,?,?,?,?)",
    [issue_id, updated_by_type, updated_by_id, action, old_value, new_value],
    cb
  );
};
const uploadMultiple = upload.array("images", 5);

// CREATE Issue + notify secretary (by building) + admins
app.post("/issues", requireRole(["admin", "Secretary", "User"]), upload.any(), async (req, res) => {
  try {
    const { title, description, status = "Pending", category, building_name } = req.body;
    const { role, id } = req.currentUser;

    let images = [];
    if (req.files && req.files.length > 0) {
      for (let f of req.files) images.push(await resizeImage(f.path));
    }
    const imageData = JSON.stringify(images);

    db.query(
      "INSERT INTO issues (reporter_type, reporter_id, category, title, description, building_name, image, status, created_at) VALUES (?,?,?,?,?,?,?,?, NOW())",
      [role === "admin" ? "admin" : role, id, category, title, description, building_name, imageData, status],
      async (err, result) => {
        if (err) return res.status(500).json(err);

        // logs
        ["title", "description", "status", "category", "building_name", "image"].forEach((field) => {
          const value = field === "image" ? imageData : req.body[field] || (field === "status" ? status : null);
          if (value) insertIssueLog(result.insertId, roleToLogType(role), id, `CREATE:${field}`, null, value);
        });

        // 🔔 Notifications
        // 1) Notify Secretary for this building
        await notifySecretaryForBuilding(building_name, `New issue reported: ${title}`);

        // 2) Notify all Admins
        await notifyAllAdmins(`New issue reported: ${title}`);

        res.json({ message: "Issue created", issue_id: result.insertId });
      }
    );
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// DELETE Issue (only Admin) + notify reporter
app.delete("/issues/:id", requireRole(["admin"]), async (req, res) => {
  try {
    const [rows] = await dbp.query("SELECT reporter_type, reporter_id FROM issues WHERE issue_id=?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: "Issue not found" });

    await dbp.query("DELETE FROM issues WHERE issue_id=?", [req.params.id]);

    // 🔔 notify reporter that admin deleted
    const issue = rows[0];
    createNotification(issue.reporter_type, issue.reporter_id, `Your issue #${req.params.id} was deleted by Admin`);

    res.json({ message: "Issue deleted" });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// GET all issues (role-based) with reporter name
app.get("/issues", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;

  let sql = "";
  let params = [];

  if (role === "admin") {
    sql = `
      SELECT i.*, 
        CASE 
          WHEN i.reporter_type='user' THEN u.uname
          WHEN i.reporter_type='secretary' THEN s.sname
          ELSE 'Admin'
        END AS reporter_name
      FROM issues i
      LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
      LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
      ORDER BY i.issue_id DESC
    `;
  } else if (role === "Secretary") {
    sql = `
      SELECT i.*, 
        CASE 
          WHEN i.reporter_type='user' THEN u.uname
          WHEN i.reporter_type='secretary' THEN s.sname
          ELSE 'Admin'
        END AS reporter_name
      FROM issues i
      LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
      LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
      JOIN secretary sec ON i.building_name = sec.building_name
      WHERE sec.secretary_id=?
      ORDER BY i.issue_id DESC
    `;
    params = [id];
  } else if (role === "User") {
    sql = `
      SELECT i.*, 
        CASE 
          WHEN i.reporter_type='user' THEN u.uname
          WHEN i.reporter_type='secretary' THEN s.sname
          ELSE 'Admin'
        END AS reporter_name
      FROM issues i
      LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
      LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
      WHERE i.reporter_type='user' AND i.reporter_id=?
      ORDER BY i.issue_id DESC
    `;
    params = [id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

// GET issues stats
app.get("/issues/stats", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  let sql = "";
  let params = [];

  if (role === "admin")
    sql = `SELECT COUNT(*) AS total, SUM(status='Pending') AS pending, SUM(status='In Progress') AS inProgress, SUM(status='Resolved') AS resolved FROM issues`;
  else if (role === "Secretary") {
    sql = `SELECT COUNT(*) AS total, SUM(status='Pending') AS pending, SUM(status='In Progress') AS inProgress, SUM(status='Resolved') AS resolved FROM issues i JOIN secretary s ON i.building_name = s.building_name WHERE s.secretary_id=?`;
    params = [id];
  } else {
    sql = `SELECT COUNT(*) AS total, SUM(status='Pending') AS pending, SUM(status='In Progress') AS inProgress, SUM(status='Resolved') AS resolved FROM issues WHERE reporter_type='user' AND reporter_id=?`;
    params = [id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    const data = rows[0] || {};
    res.json({
      total: data.total || 0,
      pending: data.pending || 0,
      inProgress: data.inProgress || 0,
      resolved: data.resolved || 0,
    });
  });
});

// UPDATE Issue (only Secretary & User) + notifications
app.put("/issues/:id", requireRole(["Secretary", "User"]), upload.any(), async (req, res) => {
  try {
    const { role, id: currentId } = req.currentUser;
    const { title, description, status, category, building_name } = req.body;

    // Fetch old issue data
    const [oldRows] = await dbp.query("SELECT * FROM issues WHERE issue_id=?", [req.params.id]);
    if (!oldRows.length) return res.status(404).json({ message: "Issue not found" });
    const oldData = oldRows[0];

    // User: can only update their own issues
    if (role === "User") {
      if (oldData.reporter_type !== "user" || oldData.reporter_id !== currentId) {
        return res.status(403).json({ message: "Forbidden: Not your issue" });
      }
    }

    // Secretary: can only update issues in their building
    if (role === "Secretary") {
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [currentId]);
      if (!secRows.length) return res.status(403).json({ message: "Secretary not found" });
      const secretaryBuilding = secRows[0].building_name;
      if (oldData.building_name !== secretaryBuilding) {
        return res.status(403).json({ message: "Forbidden: Issue not in your building" });
      }
    }

    // Handle uploaded images
    let images = [];
    if (req.files && req.files.length > 0) {
      for (let f of req.files) images.push(await resizeImage(f.path));
    }
    const imageData = images.length ? JSON.stringify(images) : null;

    // Update the issue
    await dbp.query(
      "UPDATE issues SET title=?, description=?, status=?, category=?, building_name=?, image=? WHERE issue_id=?",
      [
        title || oldData.title,
        description || oldData.description,
        status || oldData.status,
        category || oldData.category,
        building_name || oldData.building_name,
        imageData || oldData.image,
        req.params.id,
      ]
    );

    // Insert issue logs
    ["title", "description", "status", "category", "building_name", "image"].forEach(field => {
      const oldValue = oldData[field];
      const newValue = (field === "image" ? imageData : req.body[field]) || oldValue;
      if (oldValue !== newValue) {
        insertIssueLog(req.params.id, roleToLogType(role), currentId, `UPDATE:${field}`, oldValue, newValue);
      }
    });

    // 🔔 Notifications
    await notifyAllAdmins(`Issue #${req.params.id} was updated`);

    if (role === "Secretary") {
      createNotification(oldData.reporter_type, oldData.reporter_id, `Your issue #${req.params.id} was updated`);
    } else if (role === "User") {
      await notifySecretaryForBuilding(oldData.building_name, `Issue #${req.params.id} was updated by the reporter`);
    }

    res.json({ message: "Issue updated" });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

/* ======================== Feedback ======================== */
// ADD Feedback + notifications
app.post("/feedback", requireRole(["User", "Secretary"]), async (req, res) => {
  try {
    const { issue_id, feedback_text } = req.body;
    const { role, id } = req.currentUser;

    const [issueRows] = await dbp.query(
      "SELECT issue_id, building_name, reporter_type, reporter_id FROM issues WHERE issue_id=?",
      [issue_id]
    );
    if (!issueRows.length) return res.status(404).json({ message: "Issue not found" });
    const issue = issueRows[0];

    db.query(
      "INSERT INTO feedback (issue_id, giver_type, giver_id, feedback_text, created_at) VALUES (?,?,?,?, NOW())",
      [issue_id, role, id, feedback_text],
      async (err, result) => {
        if (err) return res.status(500).json(err);

        // 🔔 notify admins
        await notifyAllAdmins(`New feedback added on issue #${issue_id}`);

        // 🔔 notify opposite party
        if (role === "User") {
          await notifySecretaryForBuilding(issue.building_name, `User added feedback on issue #${issue_id}`);
        } else if (role === "Secretary") {
          createNotification(issue.reporter_type, issue.reporter_id, `Secretary added feedback on your issue #${issue_id}`);
        }

        res.json({ message: "Feedback added", feedback_id: result.insertId });
      }
    );
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// LIST feedback
app.get("/feedback", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query("SELECT * FROM feedback ORDER BY created_at DESC", (err, rows) =>
    err ? res.status(500).json(err) : res.json(rows)
  );
});

// GET single feedback (role-aware)
app.get("/feedback/:id", requireRole(["admin", "User", "Secretary"]), (req, res) => {
  const { role, id } = req.currentUser;
  let sql = "";
  let params = [];

  if (role === "admin") {
    sql = "SELECT * FROM feedback WHERE feedback_id=?";
    params = [req.params.id];
  } else {
    sql = "SELECT * FROM feedback WHERE feedback_id=? AND giver_type=? AND giver_id=?";
    params = [req.params.id, role, id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    if (!rows.length) return res.status(404).json({ message: "Feedback not found" });
    res.json(rows[0]);
  });
});

// UPDATE feedback + notify admins
app.put("/feedback/:id", requireRole(["User", "Secretary"]), (req, res) => {
  const { feedback_text } = req.body;
  const { role, id } = req.currentUser;

  db.query(
    "SELECT * FROM feedback WHERE feedback_id=? AND giver_type=? AND giver_id=?",
    [req.params.id, role, id],
    (err, rows) => {
      if (err) return res.status(500).json(err);
      if (!rows.length) return res.status(403).json({ message: "Forbidden" });

      const feedback = rows[0];

      db.query(
        "UPDATE feedback SET feedback_text=? WHERE feedback_id=?",
        [feedback_text, req.params.id],
        async (uErr) => {
          if (uErr) return res.status(500).json(uErr);

          await notifyAllAdmins(
            `Feedback #${req.params.id} on issue #${feedback.issue_id} was updated`
          );

          res.json({ message: "Feedback updated" });
        }
      );
    }
  );
});

// DELETE feedback + notify admins + opposite side
app.delete("/feedback/:id", requireRole(["User", "Secretary", "admin"]), async (req, res) => {
  try {
    const { role, id } = req.currentUser;

    if (role === "admin") {
      // Fetch for message context
      const [rows] = await dbp.query("SELECT issue_id FROM feedback WHERE feedback_id=?", [req.params.id]);
      if (!rows.length) return res.status(404).json({ message: "Feedback not found" });
      await dbp.query("DELETE FROM feedback WHERE feedback_id=?", [req.params.id]);
      await notifyAllAdmins(`Feedback #${req.params.id} on issue #${rows[0].issue_id} was deleted`);
      return res.json({ message: "Feedback deleted" });
    }

    const [rows] = await dbp.query(
      "SELECT * FROM feedback WHERE feedback_id=? AND giver_type=? AND giver_id=?",
      [req.params.id, role, id]
    );
    if (!rows.length) return res.status(403).json({ message: "Forbidden" });

    const feedback = rows[0];
    await dbp.query("DELETE FROM feedback WHERE feedback_id=?", [req.params.id]);

    await notifyAllAdmins(`Feedback #${req.params.id} on issue #${feedback.issue_id} was deleted`);

    // Notify opposite party
    const [issueRows] = await dbp.query(
      "SELECT building_name, reporter_type, reporter_id FROM issues WHERE issue_id=?",
      [feedback.issue_id]
    );
    if (issueRows.length) {
      const issue = issueRows[0];
      if (role === "User") {
        await notifySecretaryForBuilding(issue.building_name, `User deleted feedback on issue #${feedback.issue_id}`);
      } else if (role === "Secretary") {
        createNotification(issue.reporter_type, issue.reporter_id, `Secretary deleted feedback on your issue #${feedback.issue_id}`);
      }
    }

    res.json({ message: "Feedback deleted" });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

/* ======================== Issue Logs ======================== */
app.get("/issue-logs", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query("SELECT * FROM issue_logs ORDER BY created_at DESC", (err, rows) =>
    err ? res.status(500).json(err) : res.json(rows)
  );
});

/* ======================== Notifications ======================== */
app.get("/notifications", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  db.query(
    "SELECT * FROM notifications WHERE receiver_type=? AND receiver_id=? ORDER BY created_at DESC",
    [role, id],
    (err, rows) => {
      if (err) return res.status(500).json(err);
      res.json(rows);
    }
  );
});
// GET count of unread notifications
app.get("/notifications/unread/count", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;

  db.query(
    "SELECT COUNT(*) AS unreadCount FROM notifications WHERE receiver_type=? AND receiver_id=? AND is_read=0",
    [role, id],
    (err, rows) => {
      if (err) return res.status(500).json(err);
      res.json({ unreadCount: rows[0].unreadCount });
    }
  );
});

app.patch("/notifications/:id/read", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query(
    "UPDATE notifications SET is_read=1 WHERE notification_id=?",
    [req.params.id],
    (err) => (err ? res.status(500).json(err) : res.json({ message: "Marked as read" }))
  );
});

/* ======================== Report & Export ======================== */
const { Parser } = require("json2csv");

// Export issues report (CSV)
app.get("/export/issues", requireRole(["admin", "secretary", "user"]), async (req, res) => {
  try {
    const { role, id } = req.currentUser;
    let sql = "";
    let params = [];

    // Normalize role
    const userRole = role.toLowerCase();

    if (userRole === "admin") {
      // Admin: all issues
      sql = `
        SELECT i.issue_id, i.title, i.description, i.status, i.category, i.building_name, 
               CASE 
                 WHEN i.reporter_type='user' THEN u.uname
                 WHEN i.reporter_type='secretary' THEN s.sname
                 ELSE 'Admin'
               END AS reporter_name,
               i.created_at
        FROM issues i
        LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
        LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
        ORDER BY i.issue_id DESC
      `;
    } else if (userRole === "secretary") {
      // Secretary: only issues in their building
      sql = `
        SELECT i.issue_id, i.title, i.description, i.status, i.category, i.building_name, 
               CASE 
                 WHEN i.reporter_type='user' THEN u.uname
                 WHEN i.reporter_type='secretary' THEN s.sname
                 ELSE 'Admin'
               END AS reporter_name,
               i.created_at
        FROM issues i
        LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
        LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
        JOIN secretary sec ON i.building_name = sec.building_name
        WHERE sec.secretary_id=?
        ORDER BY i.issue_id DESC
      `;
      params = [id];
    } else if (userRole === "user") {
      // User: only their own issues
      sql = `
        SELECT i.issue_id, i.title, i.description, i.status, i.category, i.building_name, 
               u.uname AS reporter_name,
               i.created_at
        FROM issues i
        JOIN users u ON i.reporter_id=u.user_id
        WHERE i.reporter_type='user' AND i.reporter_id=?
        ORDER BY i.issue_id DESC
      `;
      params = [id];
    }

    const [rows] = await dbp.query(sql, params);

    if (!rows.length) return res.status(404).json({ message: "No issues to export" });

    const { Parser } = require("json2csv");
    const fields = ["issue_id", "title", "description", "status", "category", "building_name", "reporter_name", "created_at"];
    const parser = new Parser({ fields });
    const csv = parser.parse(rows);

    res.header("Content-Type", "text/csv");
    res.attachment(`issues_report_${userRole}_${Date.now()}.csv`);
    return res.send(csv);
  } catch (e) {
    console.error("Export error:", e);
    res.status(500).json({ message: "Server error", error: e });
  }
});

/* ======================== Start Server ======================== */
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));