// server.js
const express = require("express");
const mysql = require("mysql2");
const session = require("express-session");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const sharp = require("sharp");

const app = express();
const PORT = 5000;

/* ======================== Middleware ======================== */
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: "super-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: false,   // true only in production with https
    sameSite: "lax"
  }
}));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

/* ======================== DB Connection ======================== */
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "issue_tracking" // matches your dump
});
db.connect(err => {
  if (err) console.error("DB connection error:", err);
  else console.log("Connected to MySQL");
});

/* ======================== File Upload (Images) ======================== */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

const resizeImage = async (filePath) => {
  const outputFile = filePath.replace(/(\.\w+)$/, "_resized$1");
  await sharp(filePath).resize(800, 600, { fit: "inside" }).toFile(outputFile);
  fs.unlinkSync(filePath);
  return outputFile.replace(/^uploads[\\/]/, "uploads/");
};

/* ======================== Helpers ======================== */
const requireRole = (roles) => (req, res, next) => {
  const user = req.currentUser;
  if (!user || !roles.includes(user.role)) return res.status(403).json({ message: "Forbidden" });
  next();
};

// Map admin → User for issue_logs (since enum only supports User/Secretary)
const roleToLogType = (role) => (role === "Secretary" ? "Secretary" : "User");

const notify = (receiver_type, receiver_id, message, cb = () => {}) => {
  if (!["User", "Secretary"].includes(receiver_type)) return cb(null, null);
  db.query("INSERT INTO notifications (receiver_type, receiver_id, message) VALUES (?,?,?)", [receiver_type, receiver_id, message], cb);
};

app.use((req, res, next) => {
  req.currentUser = req.session.user || null;
  next();
});

/* ======================== Auth ======================== */
/* ======================== Auth ======================== */
const parseForm = multer().none(); // parse form-data without files

// Admin Login
/* ======================== Auth (fixed) ======================== */
// Remove parseForm / multer for auth completely.

app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ message: "Email and password are required" });

  // 1️⃣ Check Admin
  db.query(
    "SELECT admin_id AS id, admin_email AS email, admin_password AS password, 'admin' AS role FROM admin WHERE admin_email=? LIMIT 1",
    [email],
    (err, adminRows) => {
      if (err) return res.status(500).json({ message: "DB error", error: err });

      if (adminRows.length > 0) {
        const admin = adminRows[0];
        if (admin.password !== password)
          return res.status(401).json({ message: "Invalid email or password" });

        req.session.user = {
          role: "admin",
          id: admin.id,
          email: admin.email,
          name: admin.email.split("@")[0],
        };
        return res.json({ message: "Logged in as Admin", user: req.session.user });
      }

      // 2️⃣ Check Secretary
      db.query(
        "SELECT secretary_id AS id, semail AS email, spassword AS password, 'secretary' AS role, sname AS name FROM secretary WHERE semail=? LIMIT 1",
        [email],
        (err, secRows) => {
          if (err) return res.status(500).json({ message: "DB error", error: err });

          if (secRows.length > 0) {
            const secretary = secRows[0];
            if (secretary.password !== password)
              return res.status(401).json({ message: "Invalid email or password" });

            req.session.user = {
              role: "secretary",
              id: secretary.id,
              email: secretary.email,
              name: secretary.name,
            };
            return res.json({ message: "Logged in as Secretary", user: req.session.user });
          }

          // 3️⃣ Check User
          db.query(
            "SELECT user_id AS id, uemail AS email, upassword AS password, 'user' AS role, uname AS name FROM users WHERE uemail=? LIMIT 1",
            [email],
            (err, userRows) => {
              if (err) return res.status(500).json({ message: "DB error", error: err });

              if (userRows.length > 0) {
                const user = userRows[0];
                if (user.password !== password)
                  return res.status(401).json({ message: "Invalid email or password" });

                req.session.user = {
                  role: "user",
                  id: user.id,
                  email: user.email,
                  name: user.name,
                };
                return res.json({ message: "Logged in as User", user: req.session.user });
              }

              // ❌ Not found in any table
              return res.status(401).json({ message: "Invalid email or password" });
            }
          );
        }
      );
    }
  );
});


/* ======================== Secretary CRUD ======================== */
app.post("/secretaries", requireRole(["admin"]), (req, res) => {
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;
  db.query(
    "INSERT INTO secretary (sname, semail, spassword, role, wing, house_no, building_name) VALUES (?, ?, ?, 'Secretary', ?, ?, ?)",
    [sname, semail, spassword, wing, house_no, building_name],
    (err, result) => err ? res.status(500).json(err) : res.json({ message: "Secretary created", secretary_id: result.insertId })
  );
});
app.get("/secretaries", requireRole(["admin", "Secretary"]), (req, res) => {
  db.query("SELECT * FROM secretary", (err, rows) => err ? res.status(500).json(err) : res.json(rows));
});
app.put("/secretaries/:id", requireRole(["admin", "Secretary"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;
  if (role !== "admin" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query(
    "UPDATE secretary SET sname=?, semail=?, spassword=?, wing=?, house_no=?, building_name=? WHERE secretary_id=?",
    [sname, semail, spassword, wing, house_no, building_name, req.params.id],
    (err) => err ? res.status(500).json(err) : res.json({ message: "Secretary updated" })
  );
});
app.delete("/secretaries/:id", requireRole(["admin"]), (req, res) => {
  db.query("DELETE FROM secretary WHERE secretary_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "Secretary deleted" })
  );
});

/* ======================== Users CRUD (auto secretary_id) ======================== */
app.post("/users", requireRole(["admin", "Secretary"]), (req, res) => {
  const { uname, uemail, upassword, wing, house_no, building_name } = req.body;
  db.query("SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1", [building_name], (err, rows) => {
    if (err) return res.status(500).json(err);
    const secretary_id = rows.length ? rows[0].secretary_id : null;
    db.query(
      "INSERT INTO users (uname, uemail, upassword, role, wing, house_no, building_name, secretary_id) VALUES (?,?,?, 'User', ?,?,?,?)",
      [uname, uemail, upassword, wing, house_no, building_name, secretary_id],
      (iErr, result) => {
        if (iErr) return res.status(500).json(iErr);
        res.json({ message: "User created", user_id: result.insertId, secretary_id });
      }
    );
  });
});
app.get("/users", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  if (role === "User") {
    db.query("SELECT * FROM users WHERE user_id=?", [id], (err, rows) => err ? res.status(500).json(err) : res.json(rows));
  } else {
    db.query("SELECT * FROM users", (err, rows) => err ? res.status(500).json(err) : res.json(rows));
  }
});
app.put("/users/:id", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  const { uname, uemail, upassword, wing, house_no, building_name } = req.body;
  if (role === "User" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query("SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1", [building_name], (err, rows) => {
    if (err) return res.status(500).json(err);
    const secretary_id = rows.length ? rows[0].secretary_id : null;
    db.query(
      "UPDATE users SET uname=?, uemail=?, upassword=?, wing=?, house_no=?, building_name=?, secretary_id=? WHERE user_id=?",
      [uname, uemail, upassword, wing, house_no, building_name, secretary_id, req.params.id],
      (uErr) => uErr ? res.status(500).json(uErr) : res.json({ message: "User updated", secretary_id })
    );
  });
});
app.delete("/users/:id", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  if (role === "User" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query("DELETE FROM users WHERE user_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "User deleted" })
  );
});

/* ======================== Issues CRUD with Logs + Notifications ======================== */
const insertIssueLog = (issue_id, updated_by_type, updated_by_id, action, old_value, new_value, cb = () => {}) => {
  db.query(
    "INSERT INTO issue_logs (issue_id, updated_by_type, updated_by_id, action, old_value, new_value) VALUES (?,?,?,?,?,?)",
    [issue_id, updated_by_type, updated_by_id, action, old_value, new_value],
    cb
  );
};
const uploadMultiple = upload.array("images", 5);

app.post("/issues", requireRole(["admin", "Secretary", "User"]), upload.any(), async (req, res) => {
  try {
    const { title, description, status = "Pending", category, building_name } = req.body;
    const { role, id } = req.currentUser;

    let images = [];

    if (req.files && req.files.length > 0) {
      for (let f of req.files) {
        // resize each uploaded image
        const resized = await resizeImage(f.path);
        images.push(resized);
      }
    }

    const imageData = JSON.stringify(images);

    db.query(
      "INSERT INTO issues (reporter_type, reporter_id, category, title, description, building_name, image, status) VALUES (?,?,?,?,?,?,?,?)",
      [role === "admin" ? "admin" : role, id, category, title, description, building_name, imageData, status],
      (err, result) => {
        if (err) return res.status(500).json(err);

        // log creation
        ["title", "description", "status", "category", "building_name", "image"].forEach((field) => {
          const value = field === "image" ? imageData : req.body[field] || (field === "status" ? status : null);
          if (value) insertIssueLog(result.insertId, roleToLogType(role), id, `CREATE:${field}`, null, value);
        });

        res.json({ message: "Issue created", issue_id: result.insertId });
      }
    );
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error", error: e });
  }
});
// GET all issues (role based)
app.get("/issues", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;

  let sql = "";
  let params = [];

  if (role === "admin") {
    // Admins see everything
    sql = "SELECT * FROM issues";
  } else if (role === "Secretary") {
    // Secretaries see issues in their building(s)
    sql = `
      SELECT i.* 
      FROM issues i
      JOIN secretaries s ON i.building_name = s.building_name
      WHERE s.secretary_id = ?`;
    params = [id];
  } else if (role === "User") {
    // Users see only their own issues
    sql = "SELECT * FROM issues WHERE reporter_type='user' AND reporter_id=?";
    params = [id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

// GET single issue by ID
app.get("/issues/:id", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  const issueId = req.params.id;

  db.query("SELECT * FROM issues WHERE issue_id=?", [issueId], (err, rows) => {
    if (err) return res.status(500).json(err);
    if (!rows.length) return res.status(404).json({ message: "Issue not found" });

    const issue = rows[0];
    const ownerRole = issue.reporter_type === "Admin" ? "admin" : issue.reporter_type;

    // Permission check
    if (
      role === "admin" ||
      (role === "Secretary" && issue.building_name) || // secretary can view issues in their building
      (ownerRole === role && Number(issue.reporter_id) === Number(id))
    ) {
      return res.json(issue);
    } else {
      return res.status(403).json({ message: "Forbidden" });
    }
  });
});
// API: Count issues by status
app.get("/issues/stats", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  let sql = "";
  let params = [];

  if (role === "admin") {
    sql = `
      SELECT 
        COUNT(*) AS total,
        SUM(status='Pending') AS pending,
        SUM(status='In Progress') AS inProgress,
        SUM(status='Resolved') AS resolved
      FROM issues`;
  } else if (role === "Secretary") {
    sql = `
      SELECT 
        COUNT(*) AS total,
        SUM(status='Pending') AS pending,
        SUM(status='In Progress') AS inProgress,
        SUM(status='Resolved') AS resolved
      FROM issues i
      JOIN secretaries s ON i.building_name = s.building_name
      WHERE s.secretary_id=?`;
    params = [id];
  } else {
    sql = `
      SELECT 
        COUNT(*) AS total,
        SUM(status='Pending') AS pending,
        SUM(status='In Progress') AS inProgress,
        SUM(status='Resolved') AS resolved
      FROM issues 
      WHERE reporter_type='user' AND reporter_id=?`;
    params = [id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows[0]);
  });
});


app.put("/issues/:id", requireRole(["admin", "Secretary", "User"]), uploadMultiple, async (req, res) => {
  try {
    const { role, id } = req.currentUser;
    db.query("SELECT * FROM issues WHERE issue_id=?", [req.params.id], async (err, rows) => {
      if (err) return res.status(500).json(err);
      if (!rows.length) return res.status(404).json({ message: "Issue not found" });
      const issue = rows[0];
      const ownerRole = issue.reporter_type === "Admin" ? "admin" : issue.reporter_type;
      if (role !== "admin" && !(ownerRole === role && Number(issue.reporter_id) === Number(id))) return res.status(403).json({ message: "Forbidden" });
      let { title, description, status, category, building_name } = req.body;
      let images = [];
      if (req.files && req.files.length > 0) for (let f of req.files) images.push(await resizeImage(f.path));
      else { try { images = JSON.parse(issue.image); } catch { images = []; } }
      const updates = { title: title ?? issue.title, description: description ?? issue.description, status: status ?? issue.status, category: category ?? issue.category, building_name: building_name ?? issue.building_name, image: JSON.stringify(images) };
      db.query(
        "UPDATE issues SET title=?, description=?, status=?, category=?, building_name=?, image=? WHERE issue_id=?",
        [updates.title, updates.description, updates.status, updates.category, updates.building_name, updates.image, req.params.id],
        (uErr) => {
          if (uErr) return res.status(500).json(uErr);
          Object.keys(updates).forEach(field => {
            const oldVal = field === "image" ? issue.image : issue[field];
            const newVal = updates[field];
            if (oldVal != newVal) {
              insertIssueLog(issue.issue_id, roleToLogType(role), id, `UPDATE:${field}`, oldVal, newVal);
              if (field === "status") {
                notify(issue.reporter_type, issue.reporter_id, `Issue #${issue.issue_id} status changed to ${newVal}`);
              }
            }
          });
          res.json({ message: "Issue updated" });
        }
      );
    });
  } catch (e) { res.status(500).json(e); }
});

app.delete("/issues/:id", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  db.query("SELECT * FROM issues WHERE issue_id=?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json(err);
    if (!rows.length) return res.status(404).json({ message: "Issue not found" });
    const issue = rows[0];
    const ownerRole = issue.reporter_type === "Admin" ? "admin" : issue.reporter_type;
    if (role !== "admin" && !(ownerRole === role && Number(issue.reporter_id) === Number(id))) return res.status(403).json({ message: "Forbidden" });
    db.query("DELETE FROM issues WHERE issue_id=?", [req.params.id], (dErr) => {
      if (dErr) return res.status(500).json(dErr);
      insertIssueLog(issue.issue_id, roleToLogType(role), id, "DELETE", JSON.stringify(issue), null);
      res.json({ message: "Issue deleted" });
    });
  });
});

/* ======================== Feedback ======================== */
app.post("/feedback", requireRole(["User", "Secretary"]), (req, res) => {
  const { issue_id, feedback_text } = req.body;
  const { role, id } = req.currentUser;
  db.query(
    "INSERT INTO feedback (issue_id, giver_type, giver_id, feedback_text) VALUES (?,?,?,?)",
    [issue_id, role, id, feedback_text],
    (err, result) => err ? res.status(500).json(err) : res.json({ message: "Feedback added", feedback_id: result.insertId })
  );
});
app.get("/feedback", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query("SELECT * FROM feedback ORDER BY created_at DESC", (err, rows) => err ? res.status(500).json(err) : res.json(rows));
});

/* ======================== Issue Logs ======================== */
app.get("/issue-logs", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query("SELECT * FROM issue_logs ORDER BY created_at DESC", (err, rows) => err ? res.status(500).json(err) : res.json(rows));
});

/* ======================== Notifications ======================== */
app.get("/notifications", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  const { role, id } = req.currentUser;
  db.query("SELECT * FROM notifications WHERE receiver_type=? AND receiver_id=? ORDER BY created_at DESC", [role, id], (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});
app.patch("/notifications/:id/read", requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query("UPDATE notifications SET is_read=1 WHERE notification_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "Marked as read" })
  );
});

/* ======================== Start Server ======================== */
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));