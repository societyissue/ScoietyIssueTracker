const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const sharp = require("sharp");
const jwt = require("jsonwebtoken");
const { Parser } = require("json2csv");
const bcrypt = require("bcrypt");
const Exceljs = require("exceljs");

const saltRounds = 10;
const app = express();
const PORT = 5000;

/* ======================== JWT Config ======================== */
const JWT_SECRET = "super-secret-jwt-key";
const JWT_EXPIRES_IN = "8h";

const generateToken = (user) => {
  let payload = {};

  switch (user.role.toLowerCase()) {
    case "admin":
      payload = { id: user.id, email: user.email, role: "admin", name: user.name };
      break;
    case "secretary":
      payload = { id: user.id, email: user.email, role: "secretary", name: user.name, building_name: user.building_name };
      break;
    case "user":
      payload = { id: user.id, email: user.email, role: "user", name: user.name, building_name: user.building_name, secretary_id: user.secretary_id };
      break;
    default:
      throw new Error("Unknown role");
  }

  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
};

function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer "))
    return res.status(401).json({ message: "Authorization header missing or malformed" });

  const token = authHeader.split(" ")[1];

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      console.error("JWT verification error:", err);
      return res.status(403).json({ message: "Invalid or expired token" });
    }

    console.log("Decoded JWT payload:", decoded);

    req.user = decoded;
    req.currentUser = decoded;
    next();
  });
}

function requireRole(roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    if (!roles.includes(req.user.role))
      return res.status(403).json({ message: "Forbidden: Insufficient role" });
    next();
  };
}

async function generateExcel(issues) {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Issues Report");

  worksheet.columns = [
    { header: "Issue ID", key: "issue_id", width: 10 },
    { header: "Title", key: "title", width: 25 },
    { header: "Description", key: "description", width: 40 },
    { header: "Status", key: "status", width: 15 },
    { header: "Building", key: "building_name", width: 20 },
    { header: "Created At", key: "created_at", width: 20 },
  ];

  issues.forEach((issue) => worksheet.addRow(issue));
  worksheet.getRow(1).font = { bold: true };

  return await workbook.xlsx.writeBuffer();
}

/* ========= Utility function for CSV ========= */
function generateCSV(issues) {
  const parser = new Parser({
    fields: [
      "issue_id",
      "title",
      "description",
      "status",
      "building_name",
      "created_at",
    ],
  });
  return parser.parse(issues);
}

/* ========= Common handler ========= */
async function exportIssues(res, issues, role) {
  const format = res.req.query.format || "excel";

  if (!issues.length) {
    return res.status(404).json({ message: "No issues found" });
  }

  if (format === "csv") {
    const csv = generateCSV(issues);
    res.setHeader("Content-Disposition", `attachment; filename=${role}_issues_report.csv`);
    res.setHeader("Content-Type", "text/csv");
    res.send(csv);
  } else {
    const buffer = await generateExcel(issues);
    res.setHeader("Content-Disposition", `attachment; filename=${role}_issues_report.xlsx`);
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.send(buffer);
  }
}

/* ======================== Middleware ======================== */
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

/* ======================== DB Connection ======================== */
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "issue_tracking",
});
db.connect((err) => {
  if (err) console.error("DB connection error:", err);
  else console.log("Connected to MySQL");
});
const dbp = db.promise();

/* ======================== File Upload ======================== */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

const resizeImage = async (filePath) => {
  const smallDir = path.join(__dirname, "uploads-small");
  if (!fs.existsSync(smallDir)) fs.mkdirSync(smallDir);

  const fileName = path.basename(filePath);
  const outputFile = path.join(smallDir, fileName);

  await sharp(filePath).resize(800, 600, { fit: "inside" }).toFile(outputFile);
  fs.unlinkSync(filePath); // delete original

  return `uploads-small/${fileName}`;
};

/* ======================== Notifications Helpers ======================== */
const roleToLogType = (role) => (role === "secretary" ? "secretary" : role === "user" ? "user" : "Admin");

const createNotification = (receiverType, receiverId, message) => {
  db.query(
    "INSERT INTO notifications (receiver_type, receiver_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())",
    [receiverType, receiverId, message],
    (err) => { if (err) console.error("Notification error:", err); }
  );
};

async function notifyAllAdmins(message) {
  try {
    const [admins] = await dbp.query("SELECT admin_id FROM admin");
    admins.forEach((a) => createNotification("admin", a.admin_id, message));
  } catch (e) { console.error("notifyAllAdmins error:", e); }
}

async function notifySecretaryForBuilding(building_name, message) {
  try {
    const [secs] = await dbp.query("SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1", [building_name]);
    if (secs.length) createNotification("Secretary", secs[0].secretary_id, message);
  } catch (e) { console.error("notifySecretaryForBuilding error:", e); }
}

/* ======================== (Rest of your code) ======================== */

app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: "Email and password required" });

  db.query(
    "SELECT admin_id AS id, admin_email AS email, admin_password AS password FROM admin WHERE admin_email=? LIMIT 1",
    [email],
    async (err, adminRows) => {
      if (err) return res.status(500).json(err);
      if (adminRows.length && await bcrypt.compare(password, adminRows[0].password)) {
        const user = { id: adminRows[0].id, email: adminRows[0].email, role: "admin", name: adminRows[0].email.split("@")[0] };
        const token = generateToken(user);
        return res.json({ message: "Logged in as Admin", token, user });
      }

      db.query(
        "SELECT secretary_id AS id, semail AS email, spassword AS password, sname AS name, building_name FROM secretary WHERE semail=? LIMIT 1",
        [email],
        async (err, secRows) => {
          if (err) return res.status(500).json(err);
          if (secRows.length && await bcrypt.compare(password, secRows[0].password)) {
            const user = { id: secRows[0].id, email: secRows[0].email, role: "secretary", name: secRows[0].name, building_name: secRows[0].building_name };
            const token = generateToken(user);
            return res.json({ message: "Logged in as Secretary", token, user });
          }

          db.query(
            "SELECT user_id AS id, uemail AS email, upassword AS password, uname AS name, building_name, secretary_id FROM users WHERE uemail=? LIMIT 1",
            [email],
            async (err, userRows) => {
              if (err) return res.status(500).json(err);
              if (userRows.length && await bcrypt.compare(password, userRows[0].password)) {
                const user = { id: userRows[0].id, email: userRows[0].email, role: "user", name: userRows[0].name, building_name: userRows[0].building_name, secretary_id: userRows[0].secretary_id };
                const token = generateToken(user);
                return res.json({ message: "Logged in as User", token, user });
              }

              return res.status(401).json({ message: "Invalid email or password" });
            }
          );
        }
      );
    }
  );
});
app.get("/auth/me", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "No token provided" });

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: "Invalid token" });
    res.json({ id: decoded.id, name: decoded.name, role: decoded.role });
  });
});

/* ============ Admin profile ============ */
app.get(
  "/admin/profile",
  authenticateJWT,
  requireRole(["admin"]),
  async (req, res) => {
    try {
      const [rows] = await dbp.query(
        "SELECT admin_id, admin_email,admin_password FROM admin WHERE admin_id = ?",
        [req.user.id]
      );
      if (!rows.length) return res.status(404).json({ message: "Admin not found" });
      res.json(rows[0]);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// PUT Admin Profile (update)
app.put(
  "/admin/profile",
  authenticateJWT,
  requireRole(["admin"]),
  async (req, res) => {
    try {
      const { aemail, apassword } = req.body;
      const params = [];
      let query = "UPDATE admin SET ";

    
      if (aemail) { query += "admin_email = ?, "; params.push(aemail); }
      if (apassword) { 
        const hashed = await bcrypt.hash(apassword, SALT_ROUNDS);
        query += "admin_password = ?, "; 
        params.push(hashed);
      }

      query = query.slice(0, -2); // remove trailing comma
      query += " WHERE admin_id = ?";
      params.push(req.user.id);

      await dbp.query(query, params);
      res.json({ message: "Admin profile updated successfully" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

/* ============ Secretary profile ============ */
app.get(
  "/secretary/profile",
  authenticateJWT,
  requireRole(["secretary"]),
  async (req, res) => {
    try {
      const [rows] = await dbp.query(
        `SELECT secretary_id, sname, semail, building_name, wing, house_no 
         FROM secretary WHERE secretary_id = ?`,
        [req.user.id]
      );
      if (!rows.length) return res.status(404).json({ message: "Secretary not found" });
      res.json(rows[0]);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// PUT Secretary Profile (update)
app.put(
  "/secretary/profile",
  authenticateJWT,
  requireRole(["secretary"]),
  async (req, res) => {
    try {
      const { sname, semail, spassword, building_name, wing, house_no } = req.body;
      const params = [];
      let query = "UPDATE secretary SET ";

      if (sname) { query += "sname = ?, "; params.push(sname); }
      if (semail) { query += "semail = ?, "; params.push(semail); }
      if (spassword) { 
        const hashed = await bcrypt.hash(spassword, SALT_ROUNDS);
        query += "spassword = ?, "; 
        params.push(hashed);
      }
      if (building_name) { query += "building_name = ?, "; params.push(building_name); }
      if (wing) { query += "wing = ?, "; params.push(wing); }
      if (house_no) { query += "house_no = ?, "; params.push(house_no); }

      query = query.slice(0, -2);
      query += " WHERE secretary_id = ?";
      params.push(req.user.id);

      await dbp.query(query, params);
      res.json({ message: "Secretary profile updated successfully" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

/* ============ User profile ============ */
app.get(
  "/user/profile",
  authenticateJWT,
  requireRole(["user"]),
  async (req, res) => {
    try {
      const [rows] = await dbp.query(
        `SELECT u.user_id, u.uname, u.uemail, u.building_name, u.wing, u.house_no,
                u.secretary_id, s.sname AS secretary_name
         FROM users u
         LEFT JOIN secretary s
         ON u.secretary_id = s.secretary_id
         WHERE u.user_id = ?`,
        [req.user.id]
      );
      if (!rows.length) return res.status(404).json({ message: "User not found" });
      res.json(rows[0]);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// PUT User Profile (update)
app.put(
  "/user/profile",
  authenticateJWT,
  requireRole(["user"]),
  async (req, res) => {
    try {
      const { uname, uemail, upassword, building_name, wing, house_no } = req.body;
      const params = [];
      let query = "UPDATE users SET ";

      if (uname) { query += "uname = ?, "; params.push(uname); }
      if (uemail) { query += "uemail = ?, "; params.push(uemail); }
      if (upassword) { 
        const hashed = await bcrypt.hash(upassword, SALT_ROUNDS);
        query += "upassword = ?, "; 
        params.push(hashed);
      }
      if (wing) { query += "wing = ?, "; params.push(wing); }
      if (house_no) { query += "house_no = ?, "; params.push(house_no); }

      // If building changes, update building_name + secretary_id
      if (building_name) {
        const [secRows] = await dbp.query(
          "SELECT secretary_id FROM secretary WHERE building_name = ? LIMIT 1",
          [building_name]
        );
        const secretary_id = secRows.length ? secRows[0].secretary_id : null;
        query += "building_name = ?, secretary_id = ?, ";
        params.push(building_name, secretary_id);
      }

      query = query.slice(0, -2);
      query += " WHERE user_id = ?";
      params.push(req.user.id);

      await dbp.query(query, params);
      res.json({ message: "User profile updated successfully" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

/* ======================== Registration for User and Secretary ======================== */

app.post("/public/users", async (req, res) => {
  const { uname, uemail, upassword, wing, house_no, building_name, secretary_id } = req.body;

  if (!uname || !uemail || !upassword || !wing || !house_no || !building_name || !secretary_id) {
    return res.status(400).json({ message: "All fields are required" });
  }

  db.query("SELECT * FROM users WHERE uemail=?", [uemail], async (err, results) => {
    if (err) return res.status(500).json(err);
    if (results.length > 0) return res.status(400).json({ message: "Email already registered" });

    const hashedPassword = await bcrypt.hash(upassword, saltRounds);

    db.query(
      "INSERT INTO users (uname, uemail, upassword, role, wing, house_no, building_name, secretary_id) VALUES (?, ?, ?, 'user', ?, ?, ?, ?)",
      [uname, uemail, hashedPassword, wing, house_no, building_name, secretary_id],
      (err, result) => {
        if (err) return res.status(500).json(err);

        const token = jwt.sign(
          { id: result.insertId, email: uemail, role: "user", name: uname },
          JWT_SECRET,
          { expiresIn: JWT_EXPIRES_IN }
        );

        res.json({
          message: "User registered successfully",
          token,
          redirectTo: "/user/dashboard"
        });
      }
    );
  });
});

app.get("/public/secretaries/building", async (req, res) => {
  const buildingName = req.query.name;
  if (!buildingName) return res.status(400).json({ message: "Building name is required" });

  try {
    const [rows] = await dbp.query(
      "SELECT secretary_id, sname, building_name FROM secretary WHERE building_name = ?",
      [buildingName]
    );
    if (!rows.length) return res.status(404).json({ message: "No secretaries found for this building" });
    res.json(rows);
  } catch (err) {
    console.error("Error fetching secretaries by building:", err);
    res.status(500).json({ message: "Server error", error: err });
  }
});

app.post("/public/secretaries", async (req, res) => {
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;

  if (!sname || !semail || !spassword || !wing || !house_no || !building_name) {
    return res.status(400).json({ message: "All fields are required" });
  }

  db.query("SELECT * FROM secretary WHERE semail = ?", [semail], async (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });
    if (results.length > 0) return res.status(400).json({ message: "Email already registered" });

    const hashedPassword = await bcrypt.hash(spassword, saltRounds);

    db.query(
      "INSERT INTO secretary (sname, semail, spassword, wing, house_no, building_name, role) VALUES (?, ?, ?, ?, ?, ?, 'secretary')",
      [sname, semail, hashedPassword, wing, house_no, building_name],
      (err, result) => {
        if (err) return res.status(500).json({ message: "Database error" });

        const token = jwt.sign(
          { id: result.insertId, email: semail, role: "secretary", name: sname },
          JWT_SECRET,
          { expiresIn: JWT_EXPIRES_IN }
        );

        res.json({
          message: "Secretary registered successfully",
          token,
          redirectTo: "/secretary/dashboard"
        });
      }
    );
  });
});

/* ======================== Secretary CRUD ======================== */

app.post("/secretaries", authenticateJWT, requireRole(["admin"]), async (req, res) => {
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;

  const hashedPassword = await bcrypt.hash(spassword, saltRounds);

  db.query(
    "INSERT INTO secretary (sname, semail, spassword, role, wing, house_no, building_name) VALUES (?, ?, ?, 'secretary', ?, ?, ?)",
    [sname, semail, hashedPassword, wing, house_no, building_name],
    (err, result) =>
      err ? res.status(500).json(err) : res.json({ message: "Secretary created", secretary_id: result.insertId })
  );
});

app.get("/secretaries", authenticateJWT, requireRole(["admin", "secretary"]), (req, res) => {
  db.query("SELECT * FROM secretary", (err, rows) => (err ? res.status(500).json(err) : res.json(rows)));
});

app.get("/secretaries/:id", authenticateJWT, requireRole(["admin","secretary","user"]),(req, res) => {
  const secretaryId = req.params.id;

  const query = "SELECT secretary_id, sname, semail, wing, house_no, building_name FROM secretary WHERE secretary_id = ?";
  
  db.query(query, [secretaryId], (err, result) => {
    if (err) return res.status(500).json({ error: "Internal server error" });
    if (result.length === 0) return res.status(404).json({ error: "Secretary not found" });

    res.json(result[0]);
  });
});

app.put("/secretaries/:id", authenticateJWT, requireRole(["admin", "secretary"]), async (req, res) => {
  const { role, id: currentId } = req.currentUser;
  const { sname, semail, spassword, wing, house_no, building_name } = req.body;

  if (role !== "admin" && currentId != req.params.id) {
    return res.status(403).json({ message: "Forbidden" });
  }

  const hashedPassword = spassword ? await bcrypt.hash(spassword, saltRounds) : null;

  db.query(
    "UPDATE secretary SET sname=?, semail=?, spassword=?, wing=?, house_no=?, building_name=? WHERE secretary_id=?",
    [sname, semail, hashedPassword, wing, house_no, building_name, req.params.id],
    (err) => (err ? res.status(500).json(err) : res.json({ message: "Secretary updated" }))
  );
});

app.delete("/secretaries/:id", authenticateJWT, requireRole(["admin"]), (req, res) => {
  db.query("DELETE FROM secretary WHERE secretary_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "Secretary deleted" })
  );
});

app.get(
  "/secretary/dashboard-data",
  authenticateJWT,
  requireRole(["secretary"]), // lowercase role
  async (req, res) => {
    try {
      const secretaryId = req.currentUser?.id;
      if (!secretaryId) return res.status(401).json({ message: "Unauthorized" });

      // Get building name for this secretary
      const [secRows] = await dbp.query(
        "SELECT building_name FROM secretary WHERE secretary_id=?",
        [secretaryId]
      );
      if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
      const buildingName = secRows[0].building_name;

      // Get issue stats and recent issues for this building
      const [statsRows, issuesRows] = await Promise.all([
        dbp.query(
          `SELECT 
             COUNT(*) AS total,
             SUM(status='Pending') AS pending,
             SUM(status='In Progress') AS inProgress,
             SUM(status='Resolved') AS resolved
           FROM issues 
           WHERE building_name=? AND reporter_type='user'`,
          [buildingName]
        ),
        dbp.query(
          `SELECT i.*, u.uname AS reporter_name
           FROM issues i
           JOIN users u ON i.reporter_id=u.user_id
           WHERE i.building_name=? AND i.reporter_type='user'
           ORDER BY i.issue_id DESC`,
          [buildingName]
        ),
      ]);

      const stats = statsRows[0][0] || { total: 0, pending: 0, inProgress: 0, resolved: 0 };
      const issues = issuesRows[0] || [];

      res.json({ buildingName, stats, issues });
    } catch (err) {
      console.error("Secretary dashboard error:", err);
      res.status(500).json({ message: "Server error", error: err });
    }
  }
);

app.get(
  "/secretaries/:id",
  authenticateJWT,
  requireRole(["admin", "secretary"]),
  (req, res) => {
    const { id } = req.params;
    db.query("SELECT * FROM secretary WHERE secretary_id = ?", [id], (err, results) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (results.length === 0) return res.status(404).json({ error: "Secretary not found" });
      res.json(results[0]);
    });
  }
);

/* ======================== Users CRUD ======================== */
app.post("/users/add", authenticateJWT, requireRole(["admin", "secretary"]), async (req, res) => {
  const { uname, uemail, upassword, wing, house_no, building_name } = req.body;

  try {
    if (!upassword || !upassword.trim()) {
      return res.status(400).json({ error: "Password is required" });
    }

    const hashedPassword = await bcrypt.hash(upassword, saltRounds);

    // Case: Secretary creating user
    if (req.currentUser.role === "secretary") {
      const secretaryId = req.currentUser.id;

      db.query(
        "SELECT building_name FROM secretary WHERE secretary_id = ? LIMIT 1",
        [secretaryId],
        (err, rows) => {
          if (err) return res.status(500).json({ error: "Database error" });
          if (!rows.length) return res.status(404).json({ error: "Secretary not found" });

          const secBuilding = rows[0].building_name;

          db.query(
            "INSERT INTO users (uname, uemail, upassword, role, wing, house_no, building_name, secretary_id) VALUES (?,?,?, 'user', ?,?,?,?)",
            [uname, uemail, hashedPassword, wing, house_no, secBuilding, secretaryId],
            (iErr, result) =>
              iErr
                ? res.status(500).json(iErr)
                : res.json({ message: "User created", user_id: result.insertId, secretary_id: secretaryId })
          );
        }
      );
    }

    // Case: Admin creating user
    else if (req.currentUser.role === "admin") {
      if (!building_name) {
        return res.status(400).json({ error: "Building name is required for admin" });
      }

      db.query(
        "SELECT secretary_id FROM secretary WHERE building_name=? LIMIT 1",
        [building_name],
        (err, rows) => {
          if (err) return res.status(500).json(err);
          const secretary_id = rows.length ? rows[0].secretary_id : null;

          db.query(
            "INSERT INTO users (uname, uemail, upassword, role, wing, house_no, building_name, secretary_id) VALUES (?,?,?, 'user', ?,?,?,?)",
            [uname, uemail, hashedPassword, wing, house_no, building_name, secretary_id],
            (iErr, result) =>
              iErr
                ? res.status(500).json(iErr)
                : res.json({ message: "User created", user_id: result.insertId, secretary_id })
          );
        }
      );
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Secretary: Get users from their building
app.get("/secretary/users", authenticateJWT, requireRole(["secretary"]), (req, res) => {
  const secretaryId = req.currentUser.id;

  db.query(
    "SELECT building_name FROM secretary WHERE secretary_id = ? LIMIT 1",
    [secretaryId],
    (err, rows) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (!rows.length) return res.status(404).json({ error: "Secretary not found" });

      const buildingName = rows[0].building_name;

      db.query(
        "SELECT user_id, uname, uemail, wing, house_no FROM users WHERE building_name = ?",
        [buildingName],
        (uErr, users) => {
          if (uErr) return res.status(500).json({ error: "Database error" });
          res.json({ users });
        }
      );
    }
  );
});

app.get("/secretary/users", authenticateJWT, (req, res) => {
  if (!req.user || req.user.role !== "secretary") {
    return res.status(403).json({ message: "Access denied" });
  }

  const building = req.user.building_name;
  if (!building) return res.status(400).json({ message: "Secretary building missing" });

  const query = "SELECT user_id, uname, uemail, wing, house_no, building_name FROM users WHERE building_name = ?";
  db.query(query, [building], (err, results) => {
    if (err) {
      console.error("DB error:", err);
      return res.status(500).json({ message: "Database error" });
    }
    res.json({ users: results });
  });
});

// Get user by ID
app.get("/users/:id", authenticateJWT, requireRole(["admin", "secretary", "user"]), (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM users WHERE user_id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (!results.length) return res.status(404).json({ error: "User not found" });
    res.json(results[0]);
  });
});

// Get all users
app.get("/users", authenticateJWT, requireRole(["admin", "secretary", "user"]), async (req, res) => {
  const { role, id } = req.currentUser;

  try {
    if (role === "admin") {
      const [rows] = await dbp.query("SELECT * FROM users");
      return res.json(rows);
    }
    if (role === "secretary") {
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [id]);
      if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
      const building = secRows[0].building_name;
      const [userRows] = await dbp.query("SELECT * FROM users WHERE building_name=?", [building]);
      return res.json(userRows);
    }
    res.status(403).json({ message: "Forbidden" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error", error: err });
  }
});

app.put("/users/:id", authenticateJWT, requireRole(["admin", "secretary"]), async (req, res) => {
  const { uname, uemail, upassword, wing, house_no, building_name } = req.body;
  const userId = req.params.id;

  try {
    let hashedPassword = null;
    if (upassword && upassword.trim() !== "") {
      hashedPassword = await bcrypt.hash(upassword, saltRounds);
    }

    if (req.currentUser.role === "admin") {
      // ✅ Admin can update everything
      const updateQuery = `
        UPDATE users 
        SET uname=?, uemail=?, ${hashedPassword ? "upassword=?," : ""} wing=?, house_no=?, building_name=? 
        WHERE user_id=?`;

      const params = hashedPassword
        ? [uname, uemail, hashedPassword, wing, house_no, building_name, userId]
        : [uname, uemail, wing, house_no, building_name, userId];

      db.query(updateQuery, params, (err) => {
        if (err) return res.status(500).json({ message: "Database error", error: err });
        res.json({ message: "User updated successfully" });
      });

    } else if (req.currentUser.role === "secretary") {
      // ✅ Secretary can update only own building’s users, no building_name changes
      const secBuilding = req.currentUser.building_name;

      const updateQuery = `
        UPDATE users 
        SET uname=?, uemail=?, ${hashedPassword ? "upassword=?," : ""} wing=?, house_no=? 
        WHERE user_id=? AND building_name=?`;

      const params = hashedPassword
        ? [uname, uemail, hashedPassword, wing, house_no, userId, secBuilding]
        : [uname, uemail, wing, house_no, userId, secBuilding];

      db.query(updateQuery, params, (err, result) => {
        if (err) return res.status(500).json({ message: "Database error", error: err });
        if (result.affectedRows === 0) {
          return res.status(403).json({ message: "Not allowed to update this user" });
        }
        res.json({ message: "User updated successfully" });
      });
    }
  } catch (err) {
    res.status(500).json({ message: "Error updating user", error: err });
  }
});

// Delete user
app.delete("/users/:id", authenticateJWT, requireRole(["admin", "secretary", "user"]), (req, res) => {
  const { role, id: currentId } = req.currentUser;
  if (role === "user" && currentId != req.params.id) return res.status(403).json({ message: "Forbidden" });
  db.query("DELETE FROM users WHERE user_id=?", [req.params.id], (err) =>
    err ? res.status(500).json(err) : res.json({ message: "User deleted" })
  );
});

/* ======================== Issues CRUD ======================== */
const insertIssueLog = (issue_id, updated_by_type, updated_by_id, action, old_value, new_value, cb = () => {}) => {
  db.query(
    "INSERT INTO issue_logs (issue_id, updated_by_type, updated_by_id, action, old_value, new_value) VALUES (?,?,?,?,?,?)",
    [issue_id, updated_by_type, updated_by_id, action, old_value, new_value],
    cb
  );
};

// ======================= Report Issue API =======================
const uploadSingle = upload.single("image");  // Single file upload

app.post("/issues", authenticateJWT, uploadSingle, async (req, res) => {
  try {
    const { title, description, category } = req.body;
    const { id: reporter_id, role, building_name } = req.user;

    // Only users can report
    if (role !== "user") {
      return res.status(403).json({ message: "Only users can report issues" });
    }

    if (!title || !description || !category) {
      return res.status(400).json({ message: "Title, description, and category are required" });
    }

    const reporter_type = "User";
    const status = "Pending";

    let imagePath = null;
    if (req.file) {
      imagePath = req.file.filename;
    }

    const sql = `
      INSERT INTO issues 
        (reporter_type, reporter_id, category, title, description, building_name, image, status, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;

    db.query(
      sql,
      [reporter_type, reporter_id, category, title, description, building_name, imagePath, status],
      (err, result) => {
        if (err) {
          console.error("DB Insert Error:", err);
          return res.status(500).json({ message: "Database insert error", error: err });
        }

        res.status(201).json({
          message: "Issue inserted successfully",
          issue_id: result.insertId
        });
      }
    );

  } catch (error) {
    console.error("Server Error:", error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
});

// DELETE Issue (only Admin) + notify reporter
app.delete("/issues/:id", authenticateJWT, requireRole(["admin"]), async (req, res) => {
  try {
    const [rows] = await dbp.query("SELECT reporter_type, reporter_id FROM issues WHERE issue_id=?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: "Issue not found" });

    await dbp.query("DELETE FROM issues WHERE issue_id=?", [req.params.id]);

    const issue = rows[0];
    createNotification(issue.reporter_type, issue.reporter_id, `Your issue #${req.params.id} was deleted by Admin`);

    res.json({ message: "Issue deleted" });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// GET all issues (role-based) with reporter name
app.get("/issues", authenticateJWT, requireRole(["admin", "secretary", "user"]), (req, res) => {
  const { role, id } = req.currentUser;

  let sql = "";
  let params = [];

  if (role === "admin") {
    sql = `
      SELECT i.*, 
        CASE 
          WHEN i.reporter_type='user' THEN u.uname
          WHEN i.reporter_type='secretary' THEN s.sname
          ELSE 'Admin'
        END AS reporter_name
      FROM issues i
      LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
      LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
      ORDER BY i.issue_id DESC
    `;
  } else if (role === "secretary") {
    sql = `
      SELECT i.*, 
        CASE 
          WHEN i.reporter_type='user' THEN u.uname
          WHEN i.reporter_type='secretary' THEN s.sname
          ELSE 'Admin'
        END AS reporter_name
      FROM issues i
      LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
      LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
      JOIN secretary sec ON i.building_name = sec.building_name
      WHERE sec.secretary_id=?
      ORDER BY i.issue_id DESC
    `;
    params = [id];
  } else if (role === "user") {
    sql = `
      SELECT i.*, 
        CASE 
          WHEN i.reporter_type='user' THEN u.uname
          WHEN i.reporter_type='secretary' THEN s.sname
          ELSE 'Admin'
        END AS reporter_name
      FROM issues i
      LEFT JOIN users u ON i.reporter_type='user' AND i.reporter_id=u.user_id
      LEFT JOIN secretary s ON i.reporter_type='secretary' AND i.reporter_id=s.secretary_id
      WHERE i.reporter_type='user' AND i.reporter_id=?
      ORDER BY i.issue_id DESC
    `;
    params = [id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

// GET issues stats
app.get("/issues/stats", authenticateJWT, requireRole(["admin", "secretary", "user"]), (req, res) => {
  const { role, id } = req.currentUser;
  let sql = "";
  let params = [];

  if (role === "admin")
    sql = `SELECT COUNT(*) AS total, SUM(status='Pending') AS pending, SUM(status='In Progress') AS inProgress, SUM(status='Resolved') AS resolved FROM issues`;
  else if (role === "secretary") {
    sql = `SELECT COUNT(*) AS total, SUM(status='Pending') AS pending, SUM(status='In Progress') AS inProgress, SUM(status='Resolved') AS resolved FROM issues i JOIN secretary s ON i.building_name = s.building_name WHERE s.secretary_id=?`;
    params = [id];
  } else {
    sql = `SELECT COUNT(*) AS total, SUM(status='Pending') AS pending, SUM(status='In Progress') AS inProgress, SUM(status='Resolved') AS resolved FROM issues WHERE reporter_type='user' AND reporter_id=?`;
    params = [id];
  }

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    const data = rows[0] || {};
    res.json({
      total: data.total || 0,
      pending: data.pending || 0,
      inProgress: data.inProgress || 0,
      resolved: data.resolved || 0,
    });
  });
});

// UPDATE Issue (Secretary & User) + notifications
app.put("/issues/:id", authenticateJWT, requireRole(["secretary", "user"]), upload.any(), async (req, res) => {
  try {
    const { role, id: currentId } = req.currentUser;
    const { title, description, status, category, building_name } = req.body;

    const [oldRows] = await dbp.query("SELECT * FROM issues WHERE issue_id=?", [req.params.id]);
    if (!oldRows.length) return res.status(404).json({ message: "Issue not found" });
    const oldData = oldRows[0];

    if (role === "user" && (oldData.reporter_type !== "user" || oldData.reporter_id !== currentId))
      return res.status(403).json({ message: "Forbidden: Not your issue" });

    if (role === "secretary") {
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [currentId]);
      if (!secRows.length) return res.status(403).json({ message: "Secretary not found" });
      if (oldData.building_name !== secRows[0].building_name)
        return res.status(403).json({ message: "Forbidden: Issue not in your building" });
    }

    let images = [];
    if (req.files && req.files.length > 0) {
      for (let f of req.files) images.push(await resizeImage(f.path));
    }
    const imageData = images.length ? JSON.stringify(images) : null;

    await dbp.query(
      "UPDATE issues SET title=?, description=?, status=?, category=?, building_name=?, image=? WHERE issue_id=?",
      [
        title || oldData.title,
        description || oldData.description,
        status || oldData.status,
        category || oldData.category,
        building_name || oldData.building_name,
        imageData || oldData.image,
        req.params.id,
      ]
    );

    ["title", "description", "status", "category", "building_name", "image"].forEach((field) => {
      const oldValue = oldData[field];
      const newValue = (field === "image" ? imageData : req.body[field]) || oldValue;
      if (oldValue !== newValue) insertIssueLog(req.params.id, roleToLogType(role), currentId, `UPDATE:${field}`, oldValue, newValue);
    });

    await notifyAllAdmins(`Issue #${req.params.id} was updated`);

    if (role === "secretary") {
      createNotification(oldData.reporter_type, oldData.reporter_id, `Your issue #${req.params.id} was updated`);
    } else if (role === "user") {
      await notifySecretaryForBuilding(oldData.building_name, `Issue #${req.params.id} was updated by the reporter`);
    }

    res.json({ message: "Issue updated" });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

/* ======================== Feedback ======================== */
// ADD Feedback + notifications
app.post("/feedback", authenticateJWT, requireRole(["user", "secretary"]), async (req, res) => {
  try {
    const { issue_id, feedback_text } = req.body;
    const { role, id } = req.currentUser;

    const [issueRows] = await dbp.query(
      "SELECT issue_id, building_name, reporter_type, reporter_id FROM issues WHERE issue_id=?",
      [issue_id]
    );
    if (!issueRows.length) return res.status(404).json({ message: "Issue not found" });
    const issue = issueRows[0];

    db.query(
      "INSERT INTO feedback (issue_id, giver_type, giver_id, feedback_text, created_at) VALUES (?,?,?,?, NOW())",
      [issue_id, role, id, feedback_text],
      async (err, result) => {
        if (err) return res.status(500).json(err);

        await notifyAllAdmins(`New feedback added on issue #${issue_id}`);

        if (role === "user") {
          await notifySecretaryForBuilding(issue.building_name, `User added feedback on issue #${issue_id}`);
        } else if (role === "secretary") {
          createNotification(issue.reporter_type, issue.reporter_id, `Secretary added feedback on your issue #${issue_id}`);
        }

        res.json({ message: "Feedback added", feedback_id: result.insertId });
      }
    );
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// LIST feedback (role-based)
app.get("/feedback", authenticateJWT, requireRole(["admin", "secretary", "user"]), async (req, res) => {
  try {
    const { role, id } = req.currentUser;
    let sql = "";
    let params = [];

    if (role === "admin") {
      sql = "SELECT * FROM feedback ORDER BY created_at DESC";
    } else if (role === "secretary") {
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [id]);
      if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
      const building = secRows[0].building_name;

      sql = `
        SELECT f.* 
        FROM feedback f
        JOIN issues i ON f.issue_id=i.issue_id
        WHERE i.building_name=?
        ORDER BY f.created_at DESC
      `;
      params = [building];
    } else if (role === "user") {
      sql = "SELECT * FROM feedback WHERE giver_type='User' AND giver_id=? ORDER BY created_at DESC";
      params = [id];
    }

    const [rows] = await dbp.query(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// GET single feedback (role-based)
app.get("/feedback/:id", authenticateJWT, requireRole(["admin", "user", "secretary"]), async (req, res) => {
  try {
    const { role, id } = req.currentUser;
    let sql = "";
    let params = [];

    if (role === "admin") {
      sql = "SELECT * FROM feedback WHERE feedback_id=?";
      params = [req.params.id];
    } else if (role === "secretary") {
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [id]);
      if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
      const building = secRows[0].building_name;

      sql = `
        SELECT f.* 
        FROM feedback f
        JOIN issues i ON f.issue_id=i.issue_id
        WHERE f.feedback_id=? AND i.building_name=?
      `;
      params = [req.params.id, building];
    } else if (role === "user") {
      sql = "SELECT * FROM feedback WHERE feedback_id=? AND giver_type='User' AND giver_id=?";
      params = [req.params.id, id];
    }

    const [rows] = await dbp.query(sql, params);
    if (!rows.length) return res.status(404).json({ message: "Feedback not found" });
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// UPDATE feedback
app.put("/feedback/:id", authenticateJWT, requireRole(["user", "secretary"]), (req, res) => {
  const { feedback_text } = req.body;
  const { role, id } = req.currentUser;

  db.query(
    "SELECT * FROM feedback WHERE feedback_id=? AND giver_type=? AND giver_id=?",
    [req.params.id, role, id],
    (err, rows) => {
      if (err) return res.status(500).json(err);
      if (!rows.length) return res.status(403).json({ message: "Forbidden" });

      const feedback = rows[0];

      db.query(
        "UPDATE feedback SET feedback_text=? WHERE feedback_id=?",
        [feedback_text, req.params.id],
        async (uErr) => {
          if (uErr) return res.status(500).json(uErr);

          await notifyAllAdmins(`Feedback #${req.params.id} on issue #${feedback.issue_id} was updated`);
          res.json({ message: "Feedback updated" });
        }
      );
    }
  );
});

// DELETE feedback
app.delete("/feedback/:id", authenticateJWT, requireRole(["user", "secretary", "admin"]), async (req, res) => {
  try {
    const { role, id } = req.currentUser;

    if (role === "admin") {
      const [rows] = await dbp.query("SELECT issue_id FROM feedback WHERE feedback_id=?", [req.params.id]);
      if (!rows.length) return res.status(404).json({ message: "Feedback not found" });
      await dbp.query("DELETE FROM feedback WHERE feedback_id=?", [req.params.id]);
      await notifyAllAdmins(`Feedback #${req.params.id} on issue #${rows[0].issue_id} was deleted`);
      return res.json({ message: "Feedback deleted" });
    }

    const [rows] = await dbp.query(
      "SELECT * FROM feedback WHERE feedback_id=? AND giver_type=? AND giver_id=?",
      [req.params.id, role, id]
    );
    if (!rows.length) return res.status(403).json({ message: "Forbidden" });

    const feedback = rows[0];
    await dbp.query("DELETE FROM feedback WHERE feedback_id=?", [req.params.id]);

    await notifyAllAdmins(`Feedback #${req.params.id} on issue #${feedback.issue_id} was deleted`);

    const [issueRows] = await dbp.query(
      "SELECT building_name, reporter_type, reporter_id FROM issues WHERE issue_id=?",
      [feedback.issue_id]
    );
    if (issueRows.length) {
      const issue = issueRows[0];
      if (role === "user") {
        await notifySecretaryForBuilding(issue.building_name, `User deleted feedback on issue #${feedback.issue_id}`);
      } else if (role === "secretary") {
        createNotification(issue.reporter_type, issue.reporter_id, `Secretary deleted feedback on your issue #${feedback.issue_id}`);
      }
    }

    res.json({ message: "Feedback deleted" });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

// Issue Logs
app.get("/issue-logs", authenticateJWT, requireRole(["admin", "secretary", "user"]), (req, res) => {
  db.query("SELECT * FROM issue_logs ORDER BY created_at DESC", (err, rows) =>
    err ? res.status(500).json(err) : res.json(rows)
  );
});

// Notifications
app.get("/notifications", authenticateJWT, requireRole(["admin", "secretary", "user"]), async (req, res) => {
  try {
    const { role, id } = req.currentUser;
    let sql = "";
    let params = [];

    if (role === "admin") {
      sql = "SELECT * FROM notifications ORDER BY created_at DESC";
    } else if (role === "secretary") {
      // Secretary sees notifications for issues in their building
      const [secRows] = await dbp.query("SELECT building_name FROM secretary WHERE secretary_id=?", [id]);
      if (!secRows.length) return res.status(404).json({ message: "Secretary not found" });
      const building = secRows[0].building_name;

      sql = `
        SELECT n.* 
        FROM notifications n
        JOIN issues i ON n.issue_id=i.issue_id
        WHERE n.receiver_type='secretary' AND n.receiver_id=? AND i.building_name=?
        ORDER BY n.created_at DESC
      `;
      params = [id, building];
    } else if (role === "user") {
      sql = "SELECT * FROM notifications WHERE receiver_type='User' AND receiver_id=? ORDER BY created_at DESC";
      params = [id];
    }

    const [rows] = await dbp.query(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e });
  }
});

app.get("/notifications/unread/count", authenticateJWT, requireRole(["admin", "secretary", "user"]), (req, res) => {
  const { role, id } = req.currentUser;
  db.query(
    "SELECT COUNT(*) AS unreadCount FROM notifications WHERE receiver_type=? AND receiver_id=? AND is_read=0",
    [role, id],
    (err, rows) => (err ? res.status(500).json(err) : res.json({ unreadCount: rows[0].unreadCount }))
  );
});

app.patch("/notifications/:id/read", authenticateJWT, requireRole(["admin", "Secretary", "User"]), (req, res) => {
  db.query(
    "UPDATE notifications SET is_read=1 WHERE notification_id=?",
    [req.params.id],
    (err) => (err ? res.status(500).json(err) : res.json({ message: "Marked as read" }))
  );
});

/* ========= Admin export api ========= */
app.get(
  "/admin/export-issues",
  authenticateJWT,
  requireRole(["admin"]),
  async (req, res) => {
    try {
      const { building_name, status } = req.query;

      let query =
        "SELECT issue_id, title, description, status, building_name, created_at FROM issues WHERE 1=1";
      const params = [];

      if (building_name) {
        query += " AND building_name = ?";
        params.push(building_name);
      }
      if (status) {
        query += " AND status = ?";
        params.push(status);
      }

      const [issues] = await dbp.query(query, params);
      await exportIssues(res, issues, "admin");
    } catch (err) {
      console.error("Admin export error:", err);
      res.status(500).json({ message: "Failed to export issues" });
    }
  }
);

/* ========= Secretary export api ========= */
app.get(
  "/secretary/export-issues",
  authenticateJWT,
  requireRole(["secretary"]),
  async (req, res) => {
    try {
      const { status } = req.query;
      const buildingName = req.user.building_name;

      let query =
        "SELECT issue_id, title, description, status, building_name, created_at FROM issues WHERE building_name = ?";
      const params = [buildingName];

      if (status) {
        query += " AND status = ?";
        params.push(status);
      }

      const [issues] = await dbp.query(query, params);
      await exportIssues(res, issues, "secretary");
    } catch (err) {
      console.error("Secretary export error:", err);
      res.status(500).json({ message: "Failed to export issues" });
    }
  }
);

/* ========= User export api ========= */
app.get(
  "/user/export-issues",
  authenticateJWT,
  requireRole(["user"]),
  async (req, res) => {
    try {
      const { status } = req.query;
      const userId = req.user.user_id;

      let query =
        "SELECT issue_id, title, description, status, building_name, created_at FROM issues WHERE user_id = ?";
      const params = [userId];

      if (status) {
        query += " AND status = ?";
        params.push(status);
      }

      const [issues] = await dbp.query(query, params);
      await exportIssues(res, issues, "user");
    } catch (err) {
      console.error("User export error:", err);
      res.status(500).json({ message: "Failed to export issues" });
    }
  }
);

/* ======================== Start Server ======================== */
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));